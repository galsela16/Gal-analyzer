function safeOn(id,ev,fn,opt){var el=document.getElementById(id); if(el){el.addEventListener(ev,fn,opt);} return el;}
const FMIN=20, FMAX=20000;
let viewMin=20, viewMax=20000;
let curBpo=6;
let ISO=[], BANDS=0, R=1;
let peaks=[];
let avgBuf=[], snapCurve=null, lastV=[], lastRefV=[], lastBandDb=[], frozen=false;
let _lastRtaSmoothTime=0;
let refCurve=null;
let abA=null, abB=null, abView='off';
let sunMode=false;

// ---- TF Advanced Engine Variables ----
let tfDelayMs = 0;
let tfDelayReady = false;
let tfWorkflowVerified = false;
let tfDelayQualityText = '';
let tfWorkflowVerifying = false;
let tfWorkflowVerifyTimer = null;
let tfTraces=[];
const TF_TRACE_COLORS=['#38bdf8','#f59e0b','#e879f9','#50e68c','#f43f5e','#a78bfa'];
let tfDelaySamples = 0;
let delaySearchMs = 50;
let dlyDisplayUnit = 'ms';
let dlyDistanceOffsetMs = null;
let dlyDistanceKnownM = 1;
let dlyDistanceCalError = '';
let dlyLastPathResult = null;
let dlyLastSpeakerResult = null;
let showTfPhase = false;
let showTfCoh = false;
let tfSmoothA = 0.93;   // מיצוע TF: גבוה=יציב/איטי, נמוך=מהיר/רועד
let tfCohGate = 0.4;    // סף קוהרנטיות שמתחתיו לא מציגים פאזה
let phaseSub=null, phaseTop=null;  // צילומי פאזה: {ph:Float32Array, coh:Float32Array}
let xoverF=90, showXover=false;    // סמן תדר חיתוך
let alignRecommendation=null;

let TF_FFT_N = 16384;
let tfXr,tfXi,tfYr,tfYi,tfPxx,tfPyy,tfPxyRe,tfPxyIm,tfWin;
function configureTfFft(n){
  cancelTfWorkflowVerification();
  TF_FFT_N=Math.max(8192,Math.min(32768,parseInt(n,10)||16384));
  tfXr=new Float32Array(TF_FFT_N); tfXi=new Float32Array(TF_FFT_N);
  tfYr=new Float32Array(TF_FFT_N); tfYi=new Float32Array(TF_FFT_N);
  tfPxx=new Float32Array(TF_FFT_N/2); tfPyy=new Float32Array(TF_FFT_N/2);
  tfPxyRe=new Float32Array(TF_FFT_N/2); tfPxyIm=new Float32Array(TF_FFT_N/2);
  tfWin=new Float32Array(TF_FFT_N);
  for(let i=0;i<TF_FFT_N;i++) tfWin[i]=0.5*(1-Math.cos((2*Math.PI*i)/(TF_FFT_N-1)));
  tfWorkflowVerified=false;
  phaseSub=null; phaseTop=null; alignRecommendation=null;
}
configureTfFft(TF_FFT_N);

function buildBands(bpo){
  curBpo=bpo;
  ISO=[];
  const n=Math.max(2,Math.round(Math.log2(viewMax/viewMin)*bpo));
  for(let k=0;k<=n;k++) ISO.push(viewMin*Math.pow(2,k/bpo));
  BANDS=ISO.length;
  R=Math.pow(2,1/(2*bpo));
  peaks=new Array(BANDS).fill(0);
  avgBuf=new Array(BANDS).fill(NaN);
  lastV=new Array(BANDS).fill(0);
  lastRefV=new Array(BANDS).fill(0);
  lastBandDb=new Array(BANDS).fill(-120);
  snapCurve=null; frozen=false; _lastRtaSmoothTime=0;
  refCurve=null;
  { const rb=document.getElementById("refCurveBtn"); if(rb){ rb.classList.remove("on"); rb.textContent="שמור כ״לפני״"; } }
  const clr=document.getElementById('freezeBtn'); if(clr){clr.classList.remove('on');clr.textContent='הקפא';}
}
buildBands(6);

function escapeHtml(s){ return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

const cv = document.getElementById('cv');
const ctx = cv.getContext('2d');
const dot = document.getElementById('dot');
const idle = document.getElementById('idle');
const errBox = document.getElementById('err');
const peakHzEl = document.getElementById('peakHz');
const fbPanel = document.getElementById('fbPanel');
const meterEl = document.getElementById('meter');
const meterFill = document.getElementById('meterFill');
const meterPeak = document.getElementById('meterPeak');
const meterVal = document.getElementById('meterVal');

let audioCtx, analyser, analyserMeter, source, stream, raf;
let analyserRef=null, floatDataRef=null, chReceived=1;
let measChannel=0, refChannel=1;
let workletReady=false;
let floatData;
let timeData, timeDataMeter;
const GEQ=[20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,
           1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000];
let tfState='idle', tfSwap=false, tfMic=null, tfRef=null, tfFrames=0, tfResult=null, _tfCorr=0;
let running=false, mode='rta';
let peakHold=true, fbOn=true, avgOn=false;
let avgAlpha=0.90;
let _v3ToastTimer=null;
let floorDb=-85, ceilDb=-15;
let calib=0;
let fbProm=14;
let lvlPeak=-120, lvlPeakT=0;
let weightMode='Z';
let meterUnit='SPL';
let meterMode='rms';
let activeInId='';
let weightA=null, weightC=null;
let leqSumP=0, leqN=0, splMax=-120;
let dragging=false, dragX0=0, dragX1=0, cursorX=null, eqRtaRangeDrag=null;
let genType='pink', genOn=false, genGain=null, genSrc=null, genOsc=null;
let genDb=-34, genHz=1000, targetMode='flat';
let targetVisible=true;
let eqMinFreq=40, eqMaxFreq=16000;
let fftSize=16384;
let _pfx=null;

const _D2L_LO=-140, _D2L_STEP=0.05, _D2L_N=Math.round((0-_D2L_LO)/_D2L_STEP)+1;
const _d2l=new Float64Array(_D2L_N);
for(let i=0;i<_D2L_N;i++) _d2l[i]=Math.pow(10,(_D2L_LO+i*_D2L_STEP)*0.1);
function db2lin(db){
  if(db<=_D2L_LO) return 0;
  if(db>=0) return Math.pow(10,db*0.1);
  return _d2l[(db-_D2L_LO)*(1/_D2L_STEP)|0];
}
let _pfxRef=null;
let tfOverlay=false;
let genSweepDur=4, sweepTimer=null, sweepStartT=0;
let rt60State='idle', rt60Samples=[], rt60CutT=0, rtRange=10, rt60Timer=null, rt60ArmTimer=null, rt60CutTimer=null, rt60FinishTimer=null, rtLevel=-6;
let eqMarks=null;
let eqCurveData=null;
let eqCorrectionVisible=false;
let eqMode='graphic', lastEqCorr=null;
let cutOnly=false;
let tfMode='graphic';
const AREA_COLORS=['#2f9bff','#ffa53b','#ff5cc8','#50e68c'];
const AREA_NAMES=['צפון','דרום','מזרח','מערב'];
let areas=[];
let areaState='idle', areaAccum=null, areaFrames=0;
let measState='idle', measAccum=null, measFrames=0;
let eqPositions=[];
let micCalList=[], activeCalId=null, micCal=null;
const CAL_KEY='rta_miccals';
let specCanvas, specCtx;

let fbTrack=new Map();
let fbFrameCounter = 0;
let smoothedDbfs = -120;

function resize(){
  const r=cv.getBoundingClientRect();
  const MAXW=1440, MAXH=760;
  const dpr=Math.max(1, Math.min(window.devicePixelRatio||1, 2, MAXW/Math.max(1,r.width), MAXH/Math.max(1,r.height)));
  cv.width=Math.round(r.width*dpr); cv.height=Math.round(r.height*dpr);
  ctx.setTransform(dpr,0,0,dpr,0,0);
  
  const oldSpec=specCanvas;
  const nc=document.createElement('canvas');
  nc.width=Math.max(2,Math.floor(Math.min(r.width,MAXW)));
  nc.height=Math.max(2,Math.floor(Math.min(r.height,MAXH)));
  const nctx=nc.getContext('2d');
  nctx.fillStyle=sunMode ? '#f8fafc' : '#0d1117'; 
  nctx.fillRect(0,0,nc.width,nc.height);
  if(oldSpec){ try{ nctx.drawImage(oldSpec,0,0,nc.width,nc.height); }catch(_){} }
  specCanvas=nc; specCtx=nctx;
}
window.addEventListener('resize',resize);

safeOn('sunBtn', 'click', function(){
  sunMode = !sunMode;
  document.body.classList.toggle('sun-mode', sunMode);
  this.classList.toggle('on', sunMode);
  prefSet('rta_sunmode', sunMode ? '1' : '0');
  if(specCtx){
    specCtx.fillStyle = sunMode ? '#f8fafc' : '#0d1117';
    specCtx.fillRect(0,0,specCanvas.width,specCanvas.height);
  }
  if(eqCurveData){
    const ec=document.getElementById('eqCurveCanvas');
    if(ec) drawGEQ(ec,eqCurveData.freqs,eqCurveData.corr);
  }
  if(typeof drawTfPlot==='function') drawTfPlot();
  if(typeof v5SyncRail==='function') v5SyncRail();
});

safeOn('floor', 'input',e=>{
  floorDb=parseFloat(e.target.value);
  document.getElementById('floorVal').textContent=floorDb+'dB';
  prefSet('rta_floor', e.target.value);
});
safeOn('smooth', 'input',e=>{
  const v=parseFloat(e.target.value);
  document.getElementById('smoothVal').textContent=v.toFixed(2);
  // RTA smoothing is applied once, in linear power, with a real-time constant.
  // Keep Web Audio smoothing disabled so it is not applied a second time.
  if(analyser) analyser.smoothingTimeConstant=0;
  prefSet('rta_smooth', e.target.value);
});
safeOn('cal', 'input',e=>{
  calib=parseFloat(e.target.value);
  document.getElementById('calVal').textContent=(calib>=0?'+':'')+calib+'dB';
  prefSet('rta_cal', e.target.value);
  v3UpdateStatus();
});

safeOn('autoCalBtn', 'click', autoCal1kHz);

function autoCal1kHz(){
  if(!running || !analyser){ alert('קודם הפעל את המיקרופון.'); return; }
  const choice = prompt('בחר עוצמת כיול פיסטונפון (SPL):\n1 = 94 dB\n2 = 114 dB', '1');
  if(!choice) return;
  const targetSpl = choice === '2' ? 114 : 94;

  alert('חבר את המכייל למים/מיקרופון והפעל אותו על 1kHz.\nלחץ אישור כשהאות יציב.');

  analyser.getFloatFrequencyData(floatData);
  const nyq = audioCtx.sampleRate / 2, bins = floatData.length;
  const iLo = Math.floor(950 / nyq * bins), iHi = Math.ceil(1050 / nyq * bins);
  
  let peakVal = -999;
  for(let i=iLo; i<=iHi; i++){ if(floatData[i] > peakVal) peakVal = floatData[i]; }

  if(peakVal < -60){
    alert('לא זוהה אות 1kHz מספיק חזק (נקלט: '+peakVal.toFixed(1)+' dBFS).\nודא שהמכייל פועל ומחובר היטב.');
    return;
  }

  calib = Math.round(targetSpl - peakVal);
  const slider = document.getElementById('cal');
  slider.value = calib;
  document.getElementById('calVal').textContent = (calib>=0?'+':'')+calib+'dB';
  prefSet('rta_cal', calib);

  alert('✓ הכיול הושלם בהצלחה!\nנקלט אות ב: '+peakVal.toFixed(1)+' dBFS\nכיול SPL עודכן ל: +'+calib+' dB');
}

// ---- TF Controls: Auto-Delay, Phase, Coherence (floating bar only) ----

// Event Listeners for TF Quick Floating Bar
safeOn('qbAutoDelay', 'click', tfAutoDelay);
safeOn('qbCoh', 'click', function(){
  showTfCoh = !showTfCoh;
  this.classList.toggle('on', showTfCoh);
  const mainBtn = document.getElementById('tfCohToggleBtn');
  if(mainBtn) mainBtn.classList.toggle('on', showTfCoh);
});
safeOn('qbPhase', 'click', function(){
  showTfPhase = !showTfPhase;
  this.classList.toggle('on', showTfPhase);
  const mainBtn = document.getElementById('tfPhaseToggleBtn');
  if(mainBtn) mainBtn.classList.toggle('on', showTfPhase);
});
safeOn('tfAutoDelayBtn','click',tfAutoDelay);
safeOn('v52AutoDelayBtn','click',tfAutoDelay);
safeOn('phSyncBtn','click',tfAutoDelay);
safeOn('tfCohToggleBtn','click',function(){
  showTfCoh=!showTfCoh; this.classList.toggle('on',showTfCoh);
  const q=document.getElementById('qbCoh'); if(q) q.classList.toggle('on',showTfCoh);
});
safeOn('tfPhaseToggleBtn','click',function(){
  showTfPhase=!showTfPhase; this.classList.toggle('on',showTfPhase);
  const q=document.getElementById('qbPhase'); if(q) q.classList.toggle('on',showTfPhase);
});


function tfAutoDelay(event){
  const globalBtn=document.getElementById('v52AutoDelayBtn');
  if(!running || !analyserRef){ v3Toast('הפעל כרטיס קול סטריאו עם MIC 1 ו-REF 2'); return; }
  const trigger=event&&event.currentTarget?event.currentTarget:globalBtn;
  pickSource(()=>{
    cancelTfWorkflowVerification();
    tfDelayReady=false;tfWorkflowVerified=false;tfDelayQualityText='';
    clearSubTopSnapshots('סנכרון TF מתבצע…');
    syncSubTopWorkflowUi();
    syncTfWorkflowUi('<b>שלב 1:</b> מבצע שלוש בדיקות סנכרון…');
    runDelayCapture(trigger||globalBtn,(res,silent)=>{
    if(!res || !res.reliable){
      resetTfAutoDelay();
      const msg=silent==='mic'?'אין אות במיקרופון'
        :silent==='ref'?'אין אות ב־Reference'
        :res&&res.validChecks?'הסנכרון לא יציב — '+res.validChecks+'/3 בדיקות התאימו':'לא נמצא דיליי ברור — נסה Sweep או Pink Noise';
      v3Toast(msg); return;
    }
    tfDelayMs=res.ms; tfDelaySamples=res.samples; tfDelayReady=true;
    tfDelayQualityText='· '+res.validChecks+'/3 בדיקות · פיזור '+res.spreadMs.toFixed(2)+'ms';
    clearSubTopSnapshots('סנכרון TF השתנה — מדוד שוב סאב וטופ.');
    syncTfWorkflowUi();
    if(globalBtn){globalBtn.classList.remove('on');globalBtn.classList.add('has-result');globalBtn.textContent=`TF ${tfDelayMs.toFixed(2)} ms`;}
    v3Toast(`סנכרון TF יציב: ${tfDelayMs.toFixed(2)} ms`);
  },{maxDelayMs:delaySearchMs,mode:'tf'});
  },3800);
}

function resetTfAutoDelay(){
  cancelTfWorkflowVerification();
  tfDelayMs=0;tfDelaySamples=0;tfDelayReady=false;tfWorkflowVerified=false;tfDelayQualityText='';
  clearSubTopSnapshots('סנכרון TF אופס — סנכרן ואז מדוד שוב סאב וטופ.');
  syncTfWorkflowUi();
  const globalBtn=document.getElementById('v52AutoDelayBtn');if(globalBtn){globalBtn.classList.remove('on','has-result');globalBtn.textContent='⏱ סנכרון TF';}
}

safeOn('fbSens', 'input',e=>{
  fbProm = 26 - parseFloat(e.target.value);
  document.getElementById('fbSensVal').textContent = fbProm>=15?'נמוכה':fbProm>=10?'בינונית':'גבוהה';
  prefSet('rta_fbSens', e.target.value);
});
safeOn('peakBtn', 'click',function(){
  peakHold=!peakHold; this.classList.toggle('on',peakHold); peaks.fill(0);
});
safeOn('fbBtn', 'click',function(){
  fbOn=!fbOn; this.classList.toggle('on',fbOn); fbTrack.clear(); fbPanel.innerHTML='';
});
safeOn('avgBtn', 'click',function(){
  avgOn=!avgOn; this.classList.toggle('on',avgOn); avgBuf.fill(NaN); _lastRtaSmoothTime=0;
});
safeOn('freezeBtn', 'click',function(){
  frozen=!frozen;
  if(frozen){ snapCurve=lastV.slice(); this.classList.add('on'); this.textContent='הפשר תצוגה'; }
  else { snapCurve=null; this.classList.remove('on'); this.textContent='הקפא'; }
});
safeOn('resetPeakBtn','click',()=>{
  peaks.fill(0);
  v3Toast('Peaks אופסו');
});
document.querySelectorAll('#avgSpeedSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#avgSpeedSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on');
  avgAlpha=Math.max(0.5,Math.min(0.995,parseFloat(this.dataset.a)||0.90));
  prefSet('rta_avg_alpha', avgAlpha);
  avgBuf.fill(NaN); _lastRtaSmoothTime=0;
  v3Toast('מהירות מיצוע עודכנה');
}));
safeOn('pngBtn', 'click',exportPNG);
safeOn('csvBtn', 'click',exportCSV);

function stamp(){ const d=new Date(); const p=n=>(''+n).padStart(2,'0');
  return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds()); }
function download(name, blobUrl){
  const a=document.createElement('a'); a.href=blobUrl; a.download=name;
  document.body.appendChild(a); a.click(); a.remove();
}
function exportPNG(){
  const W=cv.clientWidth,H=cv.clientHeight,dpr=Math.min(window.devicePixelRatio||1,2);
  const off=document.createElement('canvas'); off.width=W*dpr; off.height=H*dpr;
  const o=off.getContext('2d'); o.scale(dpr,dpr);
  o.fillStyle=sunMode ? '#f8fafc' : '#0d1117'; 
  o.fillRect(0,0,W,H);
  o.drawImage(cv,0,0,W,H);
  download('rta_'+stamp()+'.png', off.toDataURL('image/png'));
}
function exportCSV(){
  let rows='freq_hz,level_db\n';
  for(let b=0;b<BANDS;b++) rows+=Math.round(ISO[b])+','+lastBandDb[b].toFixed(1)+'\n';
  download('rta_'+stamp()+'.csv', URL.createObjectURL(new Blob([rows],{type:'text/csv'})));
}

safeOn('exportJsonBtn', 'click', exportSessionJson);
safeOn('importJsonBtn', 'click', ()=> document.getElementById('jsonFileInput').click());
safeOn('jsonFileInput', 'change', importSessionJson);

function exportSessionJson(){
  const data = {
    version: 'v5.5.1-safe-sweep-delay',
    timestamp: new Date().toISOString(),
    saves: saves,
    eqPositions: eqPositions.map(p=>({name:p.name, db:Array.from(p.db)})),
    areas: areas.map(a=>({name:a.name, color:a.color, db:Array.from(a.db), show:a.show})),
    dlySpeakers: dlySpeakers,
    dlyAnchor: dlyAnchor,
    micCalList: micCalList,
    activeCalId: activeCalId,
    settings: {
      calib, floorDb, curBpo, fftSize, targetMode, targetVisible, weightMode, sunMode, eqMinFreq, eqMaxFreq
    }
  };
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], {type: 'application/json'});
  download('gal_session_'+stamp()+'.json', URL.createObjectURL(blob));
}

function importSessionJson(e){
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(evt){
    try {
      const data = JSON.parse(evt.target.result);
      if(!data || typeof data !== 'object'){ throw new Error('קובץ לא תקין'); }
      
      if(data.saves) saves = data.saves;
      if(data.eqPositions) eqPositions = data.eqPositions.map(p=>({name:p.name, db:Float32Array.from(p.db)}));
      if(data.areas) areas = data.areas.map(a=>({name:a.name, color:a.color, db:Float32Array.from(a.db), show:a.show!==false}));
      if(data.dlySpeakers) dlySpeakers = data.dlySpeakers;
      if(data.dlyAnchor!==undefined) dlyAnchor = data.dlyAnchor;
      if(data.micCalList) micCalList = data.micCalList;
      if(data.activeCalId!==undefined) activeCalId = data.activeCalId;
      
      if(data.settings){
        const s = data.settings;
        if(s.calib!==undefined){ calib = s.calib; document.getElementById('cal').value = calib; document.getElementById('calVal').textContent=(calib>=0?'+':'')+calib+'dB'; }
        if(s.floorDb!==undefined){ floorDb = s.floorDb; document.getElementById('floor').value = floorDb; document.getElementById('floorVal').textContent=floorDb+'dB'; }
        if(s.targetMode) setTarget(s.targetMode);
        if(s.targetVisible!==undefined){ targetVisible=!!s.targetVisible; prefSet('rta_target_visible',targetVisible?'1':'0'); if(typeof v5SyncTargetToggle==='function')v5SyncTargetToggle(); }
        if(s.eqMinFreq!==undefined||s.eqMaxFreq!==undefined) setEqCorrectionRange(s.eqMinFreq, s.eqMaxFreq, false);
        if(s.sunMode!==undefined){ sunMode = s.sunMode; document.body.classList.toggle('sun-mode', sunMode); document.getElementById('sunBtn').classList.toggle('on', sunMode); }
      }

      persistSaves();
      saveCalStore();
      deriveActiveCal();
      renderSaveList();
      renderEqList();
      renderAreaList();
      renderDlySpk();
      if(eqPositions.length) computeAndShow();
      alert('✓ הסשן נטען בהצלחה!');
    } catch(err) {
      alert('שגיאה שטעינת הקובץ: ' + err.message);
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}
safeOn('wgtBtn', 'click',function(){
  weightMode = weightMode==='Z'?'A':weightMode==='A'?'C':'Z';
  this.textContent='dB'+weightMode;
  this.classList.toggle('on', weightMode!=='Z');
  document.getElementById('wLbl').textContent=weightMode;
  leqSumP=0; leqN=0; splMax=-120;
  prefSet('rta_wgt', weightMode);
});
safeOn('leqBtn', 'click',()=>{ leqSumP=0; leqN=0; splMax=-120; });
document.querySelectorAll('#unitSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#unitSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); meterUnit=this.dataset.u;
  v3UpdateStatus();
}));
safeOn('inSel', 'change',e=>{ userPickedIn = e.target.value!==''; switchInput(e.target.value); });

function freqForX(px){
  const W=cv.clientWidth;
  const lmin=Math.log(ISO[0]), lmax=Math.log(ISO[BANDS-1]);
  return Math.exp(lmin + Math.max(0,Math.min(1,px/W))*(lmax-lmin));
}
function applyZoom(xa,xb){
  let fa=freqForX(Math.min(xa,xb)), fb=freqForX(Math.max(xa,xb));
  if(fb/fa < 1.2) return;
  viewMin=Math.max(FMIN,fa); viewMax=Math.min(FMAX,fb);
  buildBands(curBpo);
  document.getElementById('zoomBtn').style.display='block';
}
function resetZoom(){
  viewMin=FMIN; viewMax=FMAX; buildBands(curBpo);
  document.getElementById('zoomBtn').style.display='none';
}
function eqRtaRangeX(f){
  const lo=ISO[0],hi=ISO[BANDS-1],W=cv.clientWidth;
  return Math.log(Math.max(lo,Math.min(hi,f))/lo)/Math.log(hi/lo)*W;
}
function eqRtaRangeFreq(px){
  const raw=freqForX(px);
  return GEQ.reduce((best,f)=>Math.abs(Math.log(f/raw))<Math.abs(Math.log(best/raw))?f:best,GEQ[0]);
}
function eqRangeWorkspaceOpen(){
  return !!((eqPanel&&eqPanel.classList.contains('open'))||(tfPanel&&tfPanel.classList.contains('open')));
}
cv.addEventListener('pointerdown',e=>{
  if(!running||mode!=='rta') return;
  if(eqRangeWorkspaceOpen()){
    const dl=Math.abs(e.offsetX-eqRtaRangeX(eqMinFreq)),dh=Math.abs(e.offsetX-eqRtaRangeX(eqMaxFreq));
    if(Math.min(dl,dh)<=28){eqRtaRangeDrag=dl<=dh?'min':'max';try{cv.setPointerCapture(e.pointerId);}catch(_){}e.preventDefault();return;}
  }
  dragging=true; dragX0=dragX1=e.offsetX;
  try{cv.setPointerCapture(e.pointerId);}catch(_){}
});
cv.addEventListener('pointermove',e=>{
  cursorX=e.offsetX;
  if(eqRtaRangeDrag){const f=eqRtaRangeFreq(e.offsetX);setEqCorrectionRange(eqRtaRangeDrag==='min'?f:eqMinFreq,eqRtaRangeDrag==='max'?f:eqMaxFreq,false);cv.style.cursor='ew-resize';return;}
  if(dragging)dragX1=e.offsetX;
  if(eqRangeWorkspaceOpen()){const near=Math.min(Math.abs(e.offsetX-eqRtaRangeX(eqMinFreq)),Math.abs(e.offsetX-eqRtaRangeX(eqMaxFreq)))<=28;cv.style.cursor=near?'ew-resize':'crosshair';}
});
cv.addEventListener('pointerleave',()=>{ cursorX=null; });
cv.addEventListener('pointerup',e=>{
  if(eqRtaRangeDrag){eqRtaRangeDrag=null;setEqCorrectionRange(eqMinFreq,eqMaxFreq,true);return;}
  if(!dragging) return; dragging=false;
  if(Math.abs(dragX1-dragX0)>20) applyZoom(dragX0,dragX1);
});
cv.addEventListener('pointercancel',()=>{dragging=false;eqRtaRangeDrag=null;});
cv.addEventListener('dblclick',()=>{ if(running) resetZoom(); });
safeOn('zoomBtn', 'click',resetZoom);

function makeNoiseBuffer(type){
  const len=Math.floor(audioCtx.sampleRate*2);
  const buf=audioCtx.createBuffer(1,len,audioCtx.sampleRate);
  const d=buf.getChannelData(0);
  if(type==='white'){
    for(let i=0;i<len;i++) d[i]=Math.random()*2-1;
  } else {
    let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0;
    for(let i=0;i<len;i++){
      const w=Math.random()*2-1;
      b0=0.99886*b0+w*0.0555179; b1=0.99332*b1+w*0.0750759;
      b2=0.96900*b2+w*0.1538520; b3=0.86650*b3+w*0.3104856;
      b4=0.55000*b4+w*0.5329522; b5=-0.7616*b5-w*0.0168980;
      d[i]=(b0+b1+b2+b3+b4+b5+b6+w*0.5362)*0.11; b6=w*0.115926;
    }
  }
  return buf;
}
function genStop(){
  if(genGain){ try{genGain.gain.cancelScheduledValues(audioCtx.currentTime);
    genGain.gain.setTargetAtTime(0,audioCtx.currentTime,0.05);}catch(_){} }
  if(sweepTimer){ clearTimeout(sweepTimer); sweepTimer=null; }
  const g=genGain, s=genSrc, o=genOsc;
  setTimeout(()=>{
    try{ if(s) s.stop(); }catch(_){}
    try{ if(o) o.stop(); }catch(_){}
    try{ if(g) g.disconnect(); }catch(_){}
  },250);
  genSrc=null; genOsc=null; genGain=null; genOn=false;
  const btn=document.getElementById('genOnBtn'); if(btn){btn.classList.remove('on'); btn.textContent='▶ הפעל אות';}
  syncInlineGenBtns();
}
function scheduleSweepCycle(){
  if(!genOn || genType!=='sweep' || !genOsc) return;
  const t=audioCtx.currentTime;
  sweepStartT=t;
  try{
    genOsc.frequency.cancelScheduledValues(t);
    genOsc.frequency.setValueAtTime(20, t);
    genOsc.frequency.exponentialRampToValueAtTime(20000, t+genSweepDur);
  }catch(_){}
  sweepTimer=setTimeout(scheduleSweepCycle, genSweepDur*1000);
}
function genStart(){
  if(!running||!audioCtx){ alert('קודם הפעל את המיקרופון (כדי שהאודיו יהיה פעיל).'); return; }
  if(audioCtx.state==='suspended') audioCtx.resume();
  genStop();
  genGain=audioCtx.createGain(); genGain.gain.value=0;
  if(genType==='sine' || genType==='sweep'){
    genOsc=audioCtx.createOscillator(); genOsc.type='sine';
    genOsc.frequency.value = genType==='sine'? genHz : 20;
    genOsc.connect(genGain); genOsc.start();
  } else {
    genSrc=audioCtx.createBufferSource(); genSrc.buffer=makeNoiseBuffer(genType);
    genSrc.loop=true; genSrc.connect(genGain); genSrc.start();
  }
  genGain.connect(audioCtx.destination);
  const target=Math.pow(10,genDb/20);
  genGain.gain.setTargetAtTime(target,audioCtx.currentTime,0.15);
  genOn=true;
  if(genType==='sweep') scheduleSweepCycle();
  syncInlineGenBtns();
  const btn=document.getElementById('genOnBtn'); if(btn){btn.classList.add('on'); btn.textContent='⏹ עצור אות';}
}

function syncInlineGenBtns(){
  ['eqGenToggleBtn', 'areaGenToggleBtn'].forEach(id=>{
    const b = document.getElementById(id);
    if(b){
      b.classList.toggle('on', genOn && genType==='pink');
      b.textContent = (genOn && genType==='pink') ? '⏹ עצור רעש' : '▶ רעש ורוד';
    }
  });
}

function genApplyLevel(){
  if(genGain){ genGain.gain.setTargetAtTime(Math.pow(10,genDb/20),audioCtx.currentTime,0.1); }
}

const genPanel=document.getElementById('genPanel');
const v53Stage=document.getElementById('stage');
if(genPanel&&v53Stage)v53Stage.appendChild(genPanel);
safeOn('genBtn', 'click',function(){
  const open=genPanel.classList.toggle('open');
  this.classList.toggle('on',open);
  v53SetGeneratorDock(open);
});
function v53SetGeneratorDock(open){
  const stage=document.getElementById('stage');
  const quick=document.getElementById('v52GenBtn');
  const header=document.getElementById('v5GenAction');
  if(!stage||!genPanel)return;
  genPanel.classList.toggle('open',!!open);
  stage.classList.toggle('v53-gen-open',!!open);
  if(quick)quick.classList.toggle('on',!!open);
  if(header)header.classList.toggle('on',!!open);
  const legacy=document.getElementById('genBtn');if(legacy)legacy.classList.toggle('on',!!open);
  if(open){
    if(typeof v52SetIo==='function'&&v52IoOpen)v52SetIo(false);
    requestAnimationFrame(()=>stage.style.setProperty('--v53-gen-h',Math.ceil(genPanel.getBoundingClientRect().height)+'px'));
  }
  setTimeout(()=>{resize();},0);
}

document.querySelectorAll('#genType button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#genType button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); genType=this.dataset.t;
  document.getElementById('genFreqWrap').style.display = genType==='sine'?'flex':'none';
  document.getElementById('genSweepWrap').style.display = genType==='sweep'?'flex':'none';
  if(genOn) genStart();
}));
safeOn('genSweep', 'input',e=>{
  genSweepDur=parseFloat(e.target.value);
  document.getElementById('genSweepVal').textContent=genSweepDur.toFixed(1)+'ש\'';
});
safeOn('genLvl', 'input',e=>{
  genDb=parseFloat(e.target.value);
  const el=document.getElementById('genLvlVal'); el.textContent=genDb+'dB';
  el.style.color = genDb>=-16 ? 'var(--hot)' : (genDb>=-24?'var(--warn)':'var(--accent)');
  genApplyLevel();
});
function applyGenHz(hz, from){
  hz=Math.max(20,Math.min(20000, hz||0));
  genHz=hz;
  const slider=document.getElementById('genFreq'), num=document.getElementById('genFreqNum');
  if(from!=='slider') slider.value=Math.min(20000,hz);
  if(from!=='num') num.value=Math.round(hz);
  document.getElementById('genFreqVal').textContent=(genHz>=1000?(genHz/1000).toFixed(genHz%1000?2:1)+'k':genHz)+'Hz';
  if(genOsc) genOsc.frequency.setTargetAtTime(genHz,audioCtx.currentTime,0.02);
}
safeOn('genFreq', 'input',e=>applyGenHz(parseFloat(e.target.value),'slider'));
safeOn('genFreqNum', 'input',e=>applyGenHz(parseFloat(e.target.value),'num'));
safeOn('genOnBtn', 'click',()=>{ genOn?genStop():genStart(); });

['eqGenToggleBtn', 'areaGenToggleBtn'].forEach(id=>{
  const el = document.getElementById(id);
  if(el){
    el.addEventListener('click', function(){
      if(genOn && genType === 'pink'){
        genStop();
      } else {
        genType = 'pink';
        setGenTypeUI('pink');
        genStart();
      }
    });
  }
});

function setTarget(mode){
  targetMode=mode;
  prefSet('rta_target', mode);
  document.querySelectorAll('.tgtSeg button').forEach(b=>b.classList.toggle('on', b.dataset.t===mode));
  if(eqPositions.length) computeAndShow(true);
  if(areas.length) suggestAreaEQ();
  if(typeof tfFrames!=='undefined' && tfFrames) tfCompute();
}
document.querySelectorAll('.tgtSeg button').forEach(b=>b.addEventListener('click',function(){ setTarget(this.dataset.t); }));
function setCutOnly(v){
  cutOnly=v;
  document.querySelectorAll('#cutOnlySeg button, #areaCutSeg button, #geqCutMode button').forEach(b=>b.classList.toggle('on', (b.dataset.co==='1')===v));
  if(eqPositions.length) computeAndShow(true);
  if(areas.length) suggestAreaEQ();
  if(typeof tfFrames!=='undefined' && tfFrames) tfCompute();
}
function setEqCorrectionRange(minFreq,maxFreq,recompute=true){
  const values=GEQ.slice();
  let lo=Number(minFreq),hi=Number(maxFreq);
  if(!Number.isFinite(lo))lo=eqMinFreq;
  if(!Number.isFinite(hi))hi=eqMaxFreq;
  lo=values.reduce((best,f)=>Math.abs(f-lo)<Math.abs(best-lo)?f:best,values[0]);
  hi=values.reduce((best,f)=>Math.abs(f-hi)<Math.abs(best-hi)?f:best,values[values.length-1]);
  if(lo>=hi){
    const li=values.indexOf(lo);hi=values[Math.min(values.length-1,li+1)];
    if(lo>=hi)lo=values[Math.max(0,values.indexOf(hi)-1)];
  }
  eqMinFreq=lo;eqMaxFreq=hi;
  ['eqRangeMin','eqDockRangeMin'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=String(lo);});
  ['eqRangeMax','eqDockRangeMax'].forEach(id=>{const el=document.getElementById(id);if(el)el.value=String(hi);});
  const label=document.getElementById('eqRangeLabel');if(label)label.textContent=fLabel(lo)+'Hz – '+fLabel(hi)+'Hz';
  prefSet('rta_eq_min',lo);prefSet('rta_eq_max',hi);
  if(recompute){
    if(eqPositions.length)computeAndShow(true);
    if(areas.length)suggestAreaEQ();
    if(tfFrames)tfCompute();
  }
}
safeOn('eqRangeMin','change',e=>setEqCorrectionRange(e.target.value,eqMaxFreq));
safeOn('eqRangeMax','change',e=>setEqCorrectionRange(eqMinFreq,e.target.value));
safeOn('eqDockRangeMin','change',e=>setEqCorrectionRange(e.target.value,eqMaxFreq));
safeOn('eqDockRangeMax','change',e=>setEqCorrectionRange(eqMinFreq,e.target.value));
document.querySelectorAll('#cutOnlySeg button, #areaCutSeg button, #geqCutMode button').forEach(b=>b.addEventListener('click',function(event){
  if(this.closest('#geqCutMode')){
    event.preventDefault();
    event.stopPropagation();
  }
  setCutOnly(this.dataset.co==='1');
}));

document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',function(){
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));
  this.classList.add('on');
  const p=this.dataset.p;
  document.querySelectorAll('.tabpage').forEach(pg=>pg.classList.toggle('active', pg.dataset.page===p));
}));

const eqPanel=document.getElementById('eqPanel');
const savePanel=document.getElementById('savePanel');
let tfPanel=document.getElementById('tfPanel');
safeOn('eqClose', 'click',closeModals);
safeOn('eqBtn', 'click',()=>{ showModal(eqPanel); updateEqUI(); });
safeOn('tfBtn', 'click',()=>{ showModal(tfPanel); if(typeof tfResult!=='undefined' && tfResult) renderTFList(); });
safeOn('measBtn','click',function(){
  const r=document.getElementById('measRow'); if(!r) return;
  const show = r.style.display==='none';
  r.style.display = show?'flex':'none';
  this.classList.toggle('on',show);
});

document.querySelectorAll('.respModeSeg button').forEach(b=>b.addEventListener('click',function(){
  if(this.dataset.rm==='dual'){ showModal(tfPanel); if(typeof tfResult!=='undefined' && tfResult) renderTFList(); }
  else { showModal(eqPanel); updateEqUI(); }
}));
document.querySelectorAll('#eqModeSwitchA button').forEach(b=>b.addEventListener('click',function(){
  if(this.dataset.go==='area'){ openAreas(); }
}));

safeOn('eqMeasBtn', 'click',()=>pickSource(measurePosition,5000));
function setEqMode(m){
  eqMode=m;
  document.querySelectorAll('#eqModeSeg button, #areaModeSeg button').forEach(b=>b.classList.toggle('on', b.dataset.m===m));
  if(lastEqCorr) renderEqResult();
  if(areas.length) suggestAreaEQ();
}
document.querySelectorAll('#eqModeSeg button, #areaModeSeg button').forEach(b=>b.addEventListener('click',function(){ setEqMode(this.dataset.m); }));
document.querySelectorAll('#tfModeSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#tfModeSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); tfMode=this.dataset.m; if(tfResult) renderTFList();
}));
safeOn('eqResetBtn', 'click',()=>{ eqPositions=[]; eqMarks=null;
  { const cr=document.getElementById('combResult'); if(cr){ cr.style.display='none'; cr.innerHTML=''; } } document.getElementById('eqList').innerHTML=''; document.getElementById('eqPosList').innerHTML=''; updateEqUI(); });
safeOn('combBtn', 'click',()=>runCombCheck('combResult'));

function updateEqUI(){
  const meas = measState==='measuring';
  document.getElementById('eqSub').textContent = meas ? 'מודד… החזק יציב' : ('מיקומים שנמדדו: '+eqPositions.length);
  document.getElementById('eqMeasBtn').textContent = meas ? 'מודד…' : (eqPositions.length?'מדוד מיקום נוסף':'מדוד מיקום (5ש\')');
  document.getElementById('eqMeasBtn').style.opacity = meas?0.5:1;
}

function targetDb(f){
  if(targetMode==='house') return Math.max(-5,Math.min(6, -1.0*Math.log2(f/250)));
  return 0;
}

function clampCorrBand(f, raw){
  const maxBoost = cutOnly ? 0 : (f>500?1.5:3);
  const maxCut   = f<160?-6:-4;
  return Math.max(maxCut, Math.min(maxBoost, raw));
}
function eqOffset(resp, rel){
  const values=[];
  for(let k=0;k<GEQ.length;k++) if(rel[k]&&GEQ[k]>=200&&GEQ[k]<=4000) values.push(resp[k]-targetDb(GEQ[k]));
  if(!values.length)return 0;
  values.sort((a,b)=>a-b);
  const mid=values.length>>1;
  return values.length%2?values[mid]:(values[mid-1]+values[mid])/2;
}
function smoothEqResponse(resp){
  let out=resp.slice();
  for(let pass=0;pass<2;pass++) out=out.map((v,k)=>{
    if(k===0||k===out.length-1)return v;
    return out[k-1]*.25+v*.5+out[k+1]*.25;
  });
  return out;
}
function buildCorr(resp, rel){
  const shaped=smoothEqResponse(resp);
  const off=eqOffset(shaped, rel);
  return GEQ.map((f,k)=>{
    if(!rel[k])return null;
    let raw=-(shaped[k]-targetDb(f)-off)*.75;
    if(Math.abs(raw)<.75)raw=0;
    return clampCorrBand(f,raw);
  });
}

function relByLevel(resp){
  const mid=resp.filter((v,k)=>GEQ[k]>=125&&GEQ[k]<=8000&&Number.isFinite(v));
  const sorted=mid.slice().sort((a,b)=>a-b);
  const reference=sorted.length?sorted[Math.floor(sorted.length/2)]:Math.max(...resp);
  return GEQ.map((f,k)=> Number.isFinite(resp[k])&&resp[k]>reference-35&&f>=eqMinFreq&&f<=eqMaxFreq);
}

function corrGridHtml(corr, rel){
  let html='<div class="tfGrid">';
  let shown=0;
  for(let k=0;k<GEQ.length;k++){
    const f=GEQ[k], fStr=f>=1000?(f/1000)+'k':f+'Hz', v=corr[k];
    const hide = v==null || (rel && !rel[k]) || Math.abs(v)<0.5;
    if(hide) continue;
    shown++;
    const cls=v<0?'cut':(v>0?'boost':''), sign=v>0?'+':'';
    html+=`<div class="tfItem ${cls}"><span class="f">${fStr}</span><span class="g">${sign}${v.toFixed(1)} dB</span></div>`;
  }
  if(!shown)html+='<div class="tfItem off"><span class="f">אין תיקון משמעותי</span><span class="g">מאוזן</span></div>';
  return html+'</div>';
}
function corrParamHtml(corr){
  const list=paramFromCorr(corr);
  if(!list.length) return '<div class="sub">מאוזן 👌</div>';
  return '<div class="sub" style="margin-bottom:6px">פתרון מיטבי · '+list.length+'/6 מסנני Bell</div>'+list.map(s=>{
    const f=s.f>=1000?(s.f/1000).toFixed(2)+'kHz':Math.round(s.f)+'Hz';
    const g=(s.gain>0?'+':'')+s.gain.toFixed(1)+'dB';
    return '<div class="eqRow '+s.type+'"><span class="f">'+f+'</span><span class="g">'+g+'</span><span class="q">Q '+s.q.toFixed(1)+'</span></div>';
  }).join('');
}
function showGeqDock(title,expanded){
  const dock=document.getElementById('geqDock'); if(!dock) return;
  const wasVisible=getComputedStyle(dock).display!=='none';
  const keepExpanded=expanded===true||(expanded==null&&wasVisible&&!dock.classList.contains('collapsed'));
  eqCorrectionVisible=true;
  dock.style.display='block';dock.classList.toggle('collapsed',!keepExpanded);
  const toggle=document.getElementById('geqDockToggle');if(toggle)toggle.textContent=keepExpanded?'הסתר פירוט':'הצג פירוט';
  syncGeqBtn();
  const t=document.getElementById('geqDockTitle'); if(t&&title) t.textContent=title;
}
function latestEqWorkspace(){
  if(eqCurveData&&eqCurveData.freqs&&eqCurveData.corr)return {data:eqCurveData,title:document.getElementById('geqDockTitle')?.textContent||'תיקון EQ'};
  if(tfResult&&tfResult.corr)return {data:{freqs:GEQ.slice(),corr:tfResult.corr.slice()},title:'תיקון EQ · דו־ערוצי'};
  if(lastEqCorr)return {data:{freqs:GEQ.slice(),corr:lastEqCorr.slice()},title:'תיקון EQ · חד־ערוצי'};
  return null;
}
function openLatestEqWorkspace(){
  const latest=latestEqWorkspace();
  if(!latest){v3Toast('עדיין אין תוצאת EQ — בצע מדידה קודם');return false;}
  eqCurveData={freqs:latest.data.freqs.slice(),corr:latest.data.corr.slice()};
  showGeqDock(latest.title,true);
  const dock=document.getElementById('geqDock');if(dock){dock.style.display='block';dock.classList.remove('collapsed');}
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    const canvas=document.getElementById('eqCurveCanvas');if(canvas)drawGEQ(canvas,eqCurveData.freqs,eqCurveData.corr);
    syncGeqBtn();
  }));
  return true;
}
window.openLatestEqWorkspaceFromRail=function(event){
  if(event){event.preventDefault();event.stopPropagation();}
  const dock=document.getElementById('geqDock');
  if(eqCorrectionVisible&&dock&&getComputedStyle(dock).display!=='none'){
    hideGeqDock();v3Toast('תצוגת ה-EQ הוסתרה');return false;
  }
  openLatestEqWorkspace();
  return false;
};
function hideGeqDock(){ eqCorrectionVisible=false;const d=document.getElementById('geqDock'); if(d) d.style.display='none'; syncGeqBtn(); }
function syncGeqBtn(){
  const legacy=document.getElementById('geqShowBtn'),rail=document.getElementById('v5EqWorkspace'),d=document.getElementById('geqDock');
  const visible=!!(eqCorrectionVisible&&d&&getComputedStyle(d).display!=='none');
  if(legacy)legacy.classList.toggle('on',visible);
  if(rail){rail.classList.toggle('on',visible);rail.textContent=visible?'EQ · הסתר תיקונים':'EQ · תצוגת תיקונים';rail.setAttribute('aria-pressed',visible?'true':'false');}
}
safeOn('geqShowBtn', 'click',function(){
  const d=document.getElementById('geqDock');
  if(eqCorrectionVisible&&d&&getComputedStyle(d).display!=='none') hideGeqDock();
  else openLatestEqWorkspace();
});
safeOn('geqDockToggle', 'click',function(){
  const d=document.getElementById('geqDock');
  d.classList.toggle('collapsed');
  this.textContent = d.classList.contains('collapsed') ? 'הצג פירוט' : 'הסתר פירוט';
  if(!d.classList.contains('collapsed') && eqCurveData) drawGEQ(document.getElementById('eqCurveCanvas'), eqCurveData.freqs, eqCurveData.corr);
});
function drawGEQ(c, freqs, corr){
  if(c && c.parentElement && c.parentElement.classList.contains('collapsed')) return;
  c._geqData={freqs,corr};
  if(c.id==='eqCurveCanvas'&&!c._geqHoverReady){
    c._geqHoverReady=true;c._geqHover=-1;
    const rangeFromPointer=e=>{
      const data=c._geqData;if(!data)return null;
      const rect=c.getBoundingClientRect(),left=36,right=14,W=rect.width;
      const fMin=Math.max(20,data.freqs[0]),fMax=data.freqs[data.freqs.length-1];
      const ratio=Math.max(0,Math.min(1,(e.clientX-rect.left-left)/Math.max(1,W-left-right)));
      const raw=fMin*Math.pow(fMax/fMin,ratio);
      return GEQ.reduce((best,f)=>Math.abs(Math.log(f/raw))<Math.abs(Math.log(best/raw))?f:best,GEQ[0]);
    };
    c.addEventListener('pointerdown',e=>{
      const data=c._geqData;if(!data)return;
      const rect=c.getBoundingClientRect(),left=36,right=14,W=rect.width,fMin=Math.max(20,data.freqs[0]),fMax=data.freqs[data.freqs.length-1];
      const fx=f=>left+(Math.log(f/fMin)/Math.log(fMax/fMin))*Math.max(1,W-left-right);
      const mx=e.clientX-rect.left,dl=Math.abs(mx-fx(eqMinFreq)),dh=Math.abs(mx-fx(eqMaxFreq));
      if(Math.min(dl,dh)<=24){c._eqRangeDrag=dl<=dh?'min':'max';c.setPointerCapture?.(e.pointerId);e.preventDefault();}
    });
    c.addEventListener('pointermove',e=>{
      const data=c._geqData;if(!data)return;
      if(c._eqRangeDrag){const f=rangeFromPointer(e);if(f!=null)setEqCorrectionRange(c._eqRangeDrag==='min'?f:eqMinFreq,c._eqRangeDrag==='max'?f:eqMaxFreq);return;}
      const rect=c.getBoundingClientRect(),mx=e.clientX-rect.left,my=e.clientY-rect.top;
      const W=rect.width,H=132,left=36,right=14,top=17,bot=H-25,mid=(top+bot)/2,range=9;
      const fMin=Math.max(20,data.freqs[0]),fMax=data.freqs[data.freqs.length-1],plotW=Math.max(1,W-left-right),plotH=bot-top;
      const fx=f=>left+(Math.log(f/fMin)/Math.log(fMax/fMin))*plotW;
      const fy=db=>mid-Math.max(-range,Math.min(range,db))*(plotH/2/range);
      let nearest=-1,best=Infinity;
      data.freqs.forEach((f,k)=>{const v=data.corr[k];if(v==null||!Number.isFinite(v))return;const d=Math.hypot(mx-fx(f),my-fy(v));if(d<best){best=d;nearest=k;}});
      const next=best<=18?nearest:-1;if(next!==c._geqHover){c._geqHover=next;drawGEQ(c,data.freqs,data.corr);}
    });
    const endRangeDrag=()=>{c._eqRangeDrag=null;};
    c.addEventListener('pointerup',endRangeDrag);c.addEventListener('pointercancel',endRangeDrag);
    c.addEventListener('pointerleave',()=>{if(c._eqRangeDrag)return;const data=c._geqData;if(c._geqHover!==-1&&data){c._geqHover=-1;drawGEQ(c,data.freqs,data.corr);}});
  }
  if(c && c.id==='eqCurveCanvas'){
    const values=document.getElementById('geqValues');
    if(values){
      const actionable=[];
      for(let k=0;k<freqs.length;k++){
        const v=corr[k];if(v==null||!Number.isFinite(v)||Math.abs(v)<0.5)continue;
        const f=freqs[k]>=1000?((freqs[k]/1000)%1?(freqs[k]/1000).toFixed(2):(freqs[k]/1000).toFixed(0))+'kHz':(freqs[k]%1?freqs[k].toFixed(1):Math.round(freqs[k]))+'Hz';
        actionable.push({f,v,cls:v<0?'cut':'boost'});
      }
      actionable.sort((a,b)=>Math.abs(b.v)-Math.abs(a.v));
      const card=a=>'<div class="eqAction '+a.cls+'"><span class="freq">'+a.f+'</span><span class="hint">'+(a.v<0?'להנמיך':'להגביר')+'</span><b class="gain">'+(a.v>0?'+':'')+a.v.toFixed(1)+' dB</b></div>';
      if(!actionable.length) values.innerHTML='<span class="geqValue neutral">אין תיקון משמעותי — התגובה מאוזנת</span>';
      else{
        const primary=actionable.slice(0,6), extra=actionable.slice(6);
        values.innerHTML='<div class="eqActionHead"><strong>מה לתקן עכשיו</strong><span>'+actionable.length+' פסים משמעותיים · לפי סדר עדיפות</span></div><div class="eqActionGrid">'+primary.map(card).join('')+'</div>'+(extra.length?'<details class="eqActionMore"><summary>הצג עוד '+extra.length+' תיקונים קטנים</summary><div class="eqActionGrid">'+extra.map(card).join('')+'</div></details>':'');
      }
    }
  }
  const x=c.getContext('2d');
  const dpr=Math.min(window.devicePixelRatio||1,2);
  const CW=c.clientWidth||360, H=132;
  c.width=Math.round(CW*dpr); c.height=Math.round(H*dpr);
  x.setTransform(dpr,0,0,dpr,0,0);
  const W=CW;
  x.clearRect(0,0,W,H);
  const left=36,right=14,top=17,bot=H-25,mid=(top+bot)/2,range=9;
  const plotW=Math.max(1,W-left-right),plotH=bot-top;
  const fMin=Math.max(20,freqs[0]),fMax=freqs[freqs.length-1];
  const fx=f=>left+(Math.log(f/fMin)/Math.log(fMax/fMin))*plotW;
  const fy=db=>mid-Math.max(-range,Math.min(range,db))*(plotH/2/range);

  x.fillStyle=sunMode ? '#ffffff' : '#09131b';
  x.fillRect(0,0,W,H);
  const rangeLo=fx(Math.max(fMin,eqMinFreq)),rangeHi=fx(Math.min(fMax,eqMaxFreq));
  x.fillStyle=sunMode?'rgba(100,116,139,.13)':'rgba(2,8,14,.52)';
  if(rangeLo>left)x.fillRect(left,top,rangeLo-left,plotH);
  if(rangeHi<W-right)x.fillRect(rangeHi,top,W-right-rangeHi,plotH);
  x.font='9px monospace';x.textAlign='right';
  [-6,0,6].forEach(db=>{const yy=fy(db);x.strokeStyle=db===0?(sunMode?'rgba(15,23,42,.38)':'rgba(132,172,205,.55)'):(sunMode?'rgba(15,23,42,.10)':'rgba(132,172,205,.14)');x.setLineDash(db===0?[]:[3,4]);x.beginPath();x.moveTo(left,yy);x.lineTo(W-right,yy);x.stroke();x.fillStyle=sunMode?'#64748b':'#8093a3';x.fillText((db>0?'+':'')+db+' dB',left-5,yy+3);});
  x.setLineDash([]);
  [31.5,63,125,250,500,1000,2000,4000,8000,16000].filter(f=>f>=fMin&&f<=fMax).forEach(f=>{const xx=fx(f);x.strokeStyle=sunMode?'rgba(15,23,42,.08)':'rgba(132,172,205,.10)';x.beginPath();x.moveTo(xx,top);x.lineTo(xx,bot);x.stroke();x.textAlign='center';x.fillStyle=sunMode?'#64748b':'#8093a3';x.fillText(f>=1000?(f/1000)+'k':String(f),xx,H-8);});

  const points=[];for(let k=0;k<freqs.length;k++){const v=corr[k];if(v!=null&&Number.isFinite(v))points.push({x:fx(freqs[k]),y:fy(v),v,k});}
  if(points.length){
    const grad=x.createLinearGradient(0,top,0,bot);grad.addColorStop(0,'rgba(80,230,140,.18)');grad.addColorStop(.5,'rgba(62,166,255,.04)');grad.addColorStop(1,'rgba(255,90,120,.20)');
    x.beginPath();x.moveTo(points[0].x,mid);points.forEach(p=>x.lineTo(p.x,p.y));x.lineTo(points[points.length-1].x,mid);x.closePath();x.fillStyle=grad;x.fill();
    x.beginPath();points.forEach((p,i)=>i?x.lineTo(p.x,p.y):x.moveTo(p.x,p.y));x.strokeStyle=sunMode?'#087cc1':'#55b9f3';x.lineWidth=2.2;x.lineJoin='round';x.lineCap='round';x.stroke();
    points.forEach(p=>{x.beginPath();x.arc(p.x,p.y,2.5,0,Math.PI*2);x.fillStyle=p.v>.4?'#50e68c':p.v<-.4?'#ff5a78':'#9fb0c2';x.fill();});
    if(c.id==='eqCurveCanvas'&&c._geqHover>=0){
      const p=points.find(point=>point.k===c._geqHover);
      if(p){
        const f=freqs[p.k],fLabel=f>=1000?((f/1000)%1?(f/1000).toFixed(2):(f/1000).toFixed(0))+' kHz':(f%1?f.toFixed(1):Math.round(f))+' Hz';
        const value=(p.v>0?'+':'')+p.v.toFixed(1)+' dB',action=p.v<-.05?'להנמיך':p.v>.05?'להגביר':'ללא שינוי';
        x.beginPath();x.arc(p.x,p.y,5,0,Math.PI*2);x.fillStyle=p.v<-.05?'#ff5a78':p.v>.05?'#50e68c':'#d5dee6';x.fill();x.strokeStyle='#fff';x.lineWidth=1.5;x.stroke();
        x.font='700 10px monospace';const label=fLabel+'  ·  '+value+'  ·  '+action,tw=x.measureText(label).width+18,th=25;
        let tx=Math.max(4,Math.min(W-tw-4,p.x-tw/2)),ty=p.y-th-10;if(ty<3)ty=p.y+10;
        x.fillStyle=sunMode?'rgba(255,255,255,.97)':'rgba(5,14,21,.96)';x.fillRect(tx,ty,tw,th);
        x.strokeStyle=p.v<-.05?'#ff5a78':p.v>.05?'#50e68c':'#8292a0';x.lineWidth=1;x.strokeRect(tx+.5,ty+.5,tw-1,th-1);
        x.fillStyle=sunMode?'#0f172a':'#eef5fa';x.textAlign='center';x.fillText(label,tx+tw/2,ty+16);
      }
    }
  }
  if(c.id==='eqCurveCanvas'){
    const handle=(xx,label,side,color)=>{
      x.save();x.strokeStyle=color;x.lineWidth=3;x.setLineDash([]);x.beginPath();x.moveTo(xx,top);x.lineTo(xx,bot);x.stroke();
      x.font='800 10px monospace';const bw=Math.max(62,x.measureText(label).width+12),bh=18,bx=side==='min'?xx:xx-bw;
      x.fillStyle=color;x.fillRect(bx,top,bw,bh);x.fillStyle='#06111a';x.textAlign='center';x.fillText(label,bx+bw/2,top+12);
      x.beginPath();x.moveTo(xx,top+bh);x.lineTo(xx+(side==='min'?11:-11),top+bh);x.lineTo(xx,top+bh+11);x.closePath();x.fillStyle=color;x.fill();x.restore();
    };
    handle(rangeLo,'HPF '+fLabel(eqMinFreq)+'Hz','min','#35d0ff');
    handle(rangeHi,'LPF '+fLabel(eqMaxFreq)+'Hz','max','#ffb020');
  }
  let worst=null;
  for(let k=0;k<freqs.length;k++){ const v=corr[k]; if(v==null) continue; if(!worst||Math.abs(v)>Math.abs(worst.v)) worst={v,k}; }
  if(worst && Math.abs(worst.v)>=0.5){
    const f=freqs[worst.k];
    x.textAlign='right';x.font='600 9px monospace';x.fillStyle=worst.v>0?'#50c878':'#ff6b83';
    x.fillText('תיקון מרבי: '+(f>=1000?(f/1000).toFixed(1)+'k':Math.round(f))+'Hz  '+(worst.v>0?'+':'')+worst.v.toFixed(1)+'dB',W-right,11);
  }
}
function micCalAt(f){
  if(!micCal||!micCal.f.length) return 0;
  const F=micCal.f, G=micCal.g;
  if(f<=F[0]) return G[0]; if(f>=F[F.length-1]) return G[G.length-1];
  let i=1; while(i<F.length && F[i]<f) i++;
  const t=(Math.log(f)-Math.log(F[i-1]))/(Math.log(F[i])-Math.log(F[i-1]));
  return G[i-1]+(G[i]-G[i-1])*t;
}
function loadCalStore(){
  try{
    const raw=localStorage.getItem(CAL_KEY);
    if(raw){ const o=JSON.parse(raw); micCalList=o.list||[]; activeCalId=o.active||null; }
  }catch(_){ micCalList=[]; activeCalId=null; }
  deriveActiveCal();
}
function saveCalStore(){
  try{ localStorage.setItem(CAL_KEY, JSON.stringify({list:micCalList, active:activeCalId})); }catch(_){}
}
function deriveActiveCal(){
  const c=micCalList.find(x=>x.id===activeCalId);
  micCal = c ? {f:c.f, g:c.g} : null;
  const nm = c ? ('כיול פעיל: '+c.name) : 'כיול פעיל: ללא';
  const el=document.getElementById('eqCalName'); if(el) el.textContent=nm;
}

function renderCalList(){
  const box=document.getElementById('calList');
  let html='<div class="calRow'+(activeCalId===null?' on':'')+'" data-id=""><span class="nm">ללא כיול</span></div>';
  html+=micCalList.map(c=>'<div class="calRow'+(c.id===activeCalId?' on':'')+'" data-id="'+c.id+'">'+
    '<span class="nm" title="'+escapeHtml(c.name)+'">'+escapeHtml(c.name)+'</span><span class="sub">'+c.f.length+' נק\'</span><span class="del" data-del="'+c.id+'" title="מחק">🗑</span></div>').join('');
  box.innerHTML=html;
  box.querySelectorAll('.calRow').forEach(row=>row.addEventListener('click',e=>{
    if(e.target.dataset.del!==undefined) return;
    activeCalId = row.dataset.id || null;
    deriveActiveCal(); saveCalStore(); renderCalList();
    if(eqPositions.length) computeAndShow();
  }));
  box.querySelectorAll('.del').forEach(d=>d.addEventListener('click',e=>{
    e.stopPropagation();
    const id=d.dataset.del;
    const c=micCalList.find(x=>x.id===id);
    if(!confirm('למחוק את הכיול "'+(c?c.name:'')+'"?')) return;
    micCalList=micCalList.filter(c=>c.id!==id);
    if(activeCalId===id) activeCalId=null;
    deriveActiveCal(); saveCalStore(); renderCalList();
  }));
}

function parseCalText(text, fname){
  text=String(text||'').replace(/^\uFEFF/,'');
  const F=[],G=[];
  const lineRe=/^([+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)[\s,;]+([+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/;
  text.split(/\r?\n/).forEach(line=>{
    const m=line.trim().match(lineRe);
    if(m){ const f=parseFloat(m[1]), g=parseFloat(m[2]);
      if(isFinite(f)&&isFinite(g)&&f>0&&f<200000) { F.push(f); G.push(g); } }
  });
  if(F.length>1){
    const pts=F.map((f,i)=>[f,G[i]]).sort((a,b)=>a[0]-b[0]);
    const F2=[],G2=[];
    for(const [f,g] of pts){
      if(F2.length && Math.abs(f-F2[F2.length-1])<1e-9){ G2[G2.length-1]=(G2[G2.length-1]+g)/2; continue; }
      F2.push(f); G2.push(g);
    }
    const id='c'+Date.now();
    micCalList.push({id, name:(fname||'כיול').replace(/\.[^.]+$/,''), f:F2, g:G2});
    activeCalId=id; deriveActiveCal(); saveCalStore(); renderCalList();
    if(eqPositions.length) computeAndShow();
    return true;
  }
  return false;
}
async function addCalFromFile(file){
  try{
    let text=null;
    if(file.text){ text=await file.text(); }
    if(text==null){ text=await new Promise((res,rej)=>{ const r=new FileReader();
      r.onload=()=>res(r.result); r.onerror=()=>rej(r.error); r.readAsText(file); }); }
    if(!parseCalText(text, file.name)){
      alert('לא זיהיתי נתוני כיול בקובץ.\nהפורמט הצפוי: כל שורה = תדר [רווח/טאב/פסיק] dB. לדוגמה: 1000  -1.5');
    }
  }catch(err){
    alert('לא הצלחתי לקרוא את הקובץ.\nאם הוא ב־iCloud — הורד אותו מקומית קודם, ונסה קובץ בסיומת .txt / .cal / .frd.');
  }
}
const calPanel=document.getElementById('calPanel');
safeOn('calBtn', 'click',()=>{ renderCalList(); showModal(calPanel); });
safeOn('calClose', 'click',closeModals);
safeOn('calAdd', 'change',e=>{ if(e.target.files[0]) addCalFromFile(e.target.files[0]); e.target.value=''; });
safeOn('calPasteBtn', 'click',()=>{
  const t=document.getElementById('calPaste').value;
  if(!t.trim()){ alert('הדבק קודם את תוכן הקובץ.'); return; }
  if(parseCalText(t,'כיול מודבק')) document.getElementById('calPaste').value='';
  else alert('לא זיהיתי נתונים. כל שורה צריכה להיות: תדר [רווח/טאב] dB.');
});
calPanel.addEventListener('dragover',e=>{ e.preventDefault(); calPanel.style.borderColor='var(--accent)'; });
calPanel.addEventListener('dragleave',()=>{ calPanel.style.borderColor=''; });
calPanel.addEventListener('drop',e=>{ e.preventDefault(); calPanel.style.borderColor='';
  const f=e.dataTransfer.files[0]; if(f) addCalFromFile(f); });
safeOn('calResetBtn', 'click',()=>{
  if(!micCalList.length){ return; }
  if(!confirm('לאפס ולמחוק את כל קבצי הכיולים?')) return;
  micCalList=[]; activeCalId=null; deriveActiveCal(); saveCalStore(); renderCalList();
});

var alignOn=false;
const modalBg=document.getElementById('modalBg');
const guidePanel=document.getElementById('guidePanel');
const measureDockIds=['rtPanel','eqPanel','tfPanel','areaPanel','dlyPanel'];
const stageEl=document.getElementById('stage');
function dockAdvanced(id, parentLevels=0, block=false){
  let e=document.getElementById(id); if(!e) return;
  while(parentLevels-->0 && e.parentElement) e=e.parentElement;
  e.classList.add('dockAdvanced'); if(block)e.classList.add('block');
}
function setupMeasureDocks(){
  measureDockIds.forEach(id=>{
    const p=document.getElementById(id); if(!p)return;
    p.classList.add('measureDock'); if(stageEl) stageEl.appendChild(p);
    const close=p.querySelector('[id$="Close"]'); if(close){close.classList.add('dockClose');close.textContent='✕';close.title='סגור';}
    const more=document.createElement('button');more.className='dockMoreBtn';more.type='button';more.textContent='עוד ▾';
    more.addEventListener('click',()=>{
      // The TF workspace must always be inspectable in the field. Before a
      // result exists, its result section explains the next measurement step.
      p.classList.toggle('expanded');
      more.textContent=p.classList.contains('expanded')?'פחות ▴':'עוד ▾';
      if(p.id==='tfPanel' && p.classList.contains('expanded')) renderTFList();
      setTimeout(updateMeasureDockHeight,0);
    });
    if(close && close.parentElement){
      close.parentElement.insertBefore(more,close);
    } else {
      p.appendChild(more);
    }
  });
  // heavy/advanced sections stay hidden until "עוד"
  ['tfCanvas','tfModeSeg','tfGeqList','tfInfo','eqPosList','eqList','combResult','areaList','areaEqCanvas','areaEqList','areaCombResult','rtCanvas'].forEach(id=>dockAdvanced(id,0,true));
  ['tfSmooth','tfCohGate'].forEach(id=>dockAdvanced(id,1));
  // TF starts as a compact live workspace. Deep diagnostics and less-frequent
  // actions move behind "עוד", leaving most of the screen to the graph.
  dockAdvanced('tfCorrFill',2);
  dockAdvanced('tfUtilityBtns');
  ['eqModeSwitchA','eqModeSeg','cutOnlySeg','areaModeSeg','areaCutSeg','dlyCountSeg','rtLevel','rtRange'].forEach(id=>dockAdvanced(id,1));
  dockAdvanced('tfModeSeg',0);
  dockAdvanced('tfTargetCtrl',0);
  // area EQ button is advanced
  dockAdvanced('areaEqBtn');
}
function updateMeasureDockHeight(){
  const open=measureDockIds.map(id=>document.getElementById(id)).find(p=>p&&p.classList.contains('open'));
  if(open){stageEl.style.setProperty('--measure-h',open.offsetHeight+'px');stageEl.classList.add('measure-open');}
  else{stageEl.style.setProperty('--measure-h','0px');stageEl.classList.remove('measure-open');}
  if(typeof resize==='function')resize();
  if(typeof v5SyncRail==='function')v5SyncRail();
}
setupMeasureDocks();
['calPanel','savePanel'].forEach(id=>{const p=document.getElementById(id);if(p)modalBg.appendChild(p);});
function showModal(p){
  if(!p) return;
  setAlign(false); closeModals(); p.classList.add('open');
  if(p.classList.contains('measureDock')){modalBg.classList.remove('show');setTimeout(updateMeasureDockHeight,0);}
  else modalBg.classList.add('show');
}
function abortRT60(){
  if(rt60State==='idle'&&!rt60Timer&&!rt60ArmTimer&&!rt60CutTimer&&!rt60FinishTimer)return;
  rt60State='idle';
  if(rt60Timer){ clearInterval(rt60Timer); rt60Timer=null; }
  if(rt60ArmTimer){clearTimeout(rt60ArmTimer);rt60ArmTimer=null;}
  if(rt60CutTimer){clearTimeout(rt60CutTimer);rt60CutTimer=null;}
  if(rt60FinishTimer){clearTimeout(rt60FinishTimer);rt60FinishTimer=null;}
  if(analyser) analyser.smoothingTimeConstant=parseFloat(document.getElementById('smooth').value);
  genStop();
  if(rtStatus) rtStatus.textContent='המדידה בוטלה.';
}
function closeModals(){
  abortRT60();
  ['rtPanel','eqPanel','calPanel','tfPanel','areaPanel','dlyPanel','savePanel','guidePanel'].forEach(id=>{const p=document.getElementById(id);if(p){p.classList.remove('open','expanded');const m=p.querySelector('.dockMoreBtn');if(m)m.textContent='עוד ▾';}});
  modalBg.classList.remove('show');
  if(typeof updateMeasureDockHeight==='function') updateMeasureDockHeight();
}
modalBg.addEventListener('click',e=>{ if(e.target===modalBg) closeModals(); });
document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeModals(); });
safeOn('guideBtn','click',()=>showModal(guidePanel));
safeOn('guideClose','click',closeModals);

const areaPanel=document.getElementById('areaPanel');
document.querySelectorAll('#eqModeSwitchB button').forEach(b=>b.addEventListener('click',function(){
  if(this.dataset.go==='avg'){ showModal(eqPanel); updateEqUI(); }
}));
function openAreas(){
  renderAreaList();
  document.querySelectorAll('#areaModeSeg button').forEach(b=>b.classList.toggle('on', b.dataset.m===eqMode));
  document.querySelectorAll('#areaCutSeg button').forEach(b=>b.classList.toggle('on', (b.dataset.co==='1')===cutOnly));
  showModal(areaPanel);
}
safeOn('areaClose', 'click',closeModals);
safeOn('areaMeasBtn', 'click',()=>pickSource(measureArea,5000));
let pendingMeasureFn=null, pendingDur=5000, pendingSourceOptions=null;
const srcOverlay=document.getElementById('srcOverlay');
function pickSource(fn, dur, options){
  if(!running){ alert('קודם הפעל את המיקרופון.'); return; }
  pendingMeasureFn=fn;pendingDur=dur||5000;pendingSourceOptions=options||{};
  const allowed=Array.isArray(pendingSourceOptions.allowed)?pendingSourceOptions.allowed:['pink','sweep','external'];
  const title=document.querySelector('#srcBox .srcTitle');if(title)title.textContent=pendingSourceOptions.title||'איזה אות להשמיע למדידה?';
  document.querySelectorAll('#srcBox button[data-src]').forEach(btn=>{btn.style.display=btn.dataset.src==='cancel'||allowed.includes(btn.dataset.src)?'':'none';});
  srcOverlay.classList.add('show');
}
srcOverlay.addEventListener('click',e=>{ if(e.target===srcOverlay){srcOverlay.classList.remove('show');pendingMeasureFn=null;pendingSourceOptions=null;} });
document.querySelectorAll('#srcBox button').forEach(b=>b.addEventListener('click',function(){
  srcOverlay.classList.remove('show');
  const src=this.dataset.src,fn=pendingMeasureFn,dur=pendingDur;pendingMeasureFn=null;pendingSourceOptions=null;
  if(src==='cancel'||!fn) return;
  runWithSource(src,fn,dur);
}));
function setGenTypeUI(kind){
  document.querySelectorAll('#genType button').forEach(x=>x.classList.toggle('on', x.dataset.t===kind));
  document.getElementById('genFreqWrap').style.display='none';
  document.getElementById('genSweepWrap').style.display = kind==='sweep'?'flex':'none';
}
function runWithSource(kind, measureFn, durMs){
  durMs=durMs||5000;
  if(kind==='sweep') durMs=Math.max(durMs, genSweepDur*1000+600);
  if(kind==='external'){ measureFn(); return; }
  const prevOn=genOn, prevType=genType;
  genType=kind; setGenTypeUI(kind); genStart();
  setTimeout(measureFn, 450);
  setTimeout(()=>{
    if(prevOn){ genType=prevType; setGenTypeUI(prevType); genStart(); }
    else genStop();
  }, 450+durMs+300);
}

safeOn('areaCombBtn', 'click',()=>runCombCheck('areaCombResult'));
safeOn('areaResetBtn', 'click',()=>{
  areas=[];
  { const cr=document.getElementById('areaCombResult'); if(cr){ cr.style.display='none'; cr.innerHTML=''; } }
  const ac=document.getElementById('areaEqCanvas'); if(ac) ac.style.display='none';
  const al=document.getElementById('areaEqList'); if(al) al.innerHTML='';
  eqMarks=null; eqCurveData=null; hideGeqDock();
  renderAreaList();
});
safeOn('areaEqBtn', 'click',suggestAreaEQ);
function suggestAreaEQ(){
  if(!areas.length){ alert('מדוד לפחות אזור אחד.'); return; }
  const n=GEQ.length;
  const avg=new Array(n);
  for(let k=0;k<n;k++){ let p=0; areas.forEach(a=>p+=db2lin(a.db[k])); avg[k]=10*Math.log10(p/areas.length+1e-12); }
  const resp=avg.map((d,k)=> d - (micCal?micCalAt(GEQ[k]):0));
  const rel=relByLevel(resp);
  const corr=buildCorr(resp, rel);
  eqMarks=[]; for(let k=0;k<n;k++){ if(corr[k]!=null && Math.abs(corr[k])>=1.0) eqMarks.push({f:GEQ[k],gain:corr[k],type:corr[k]<0?'cut':'boost'}); }
  eqCurveData={freqs:GEQ.slice(), corr:corr.slice()};

  const cv2=document.getElementById('areaEqCanvas'); cv2.style.display='block'; drawGEQ(cv2,GEQ,corr);

  const head = '<div class="sub" style="margin-bottom:6px; color:var(--text); font-weight:600;">ממוצע ' + areas.length + ' אזורים · יעד ' + (targetMode==='house'?'House':'שטוח') + ':</div>';
  document.getElementById('areaEqList').innerHTML = head + (eqMode==='param' ? corrParamHtml(corr) : corrGridHtml(corr, null));
}

function updateAreaMeasBtn(){
  const b=document.getElementById('areaMeasBtn'), meas=areaState==='measuring';
  b.textContent = meas?'מודד… החזק יציב':'מדוד אזור חדש (5ש\')'; b.style.opacity=meas?.5:1;
}
function measureArea(){
  if(!running){ alert('קודם הפעל את המיקרופון.'); return; }
  if(areas.length>=4){ alert('הגעת ל־4 אזורים — מחק אחד כדי להוסיף.'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  unfreezeForMeasure();
  const srcData = floatData;
  areaAccum=new Float64Array(srcData.length); areaFrames=0; areaState='measuring';
  updateAreaMeasBtn();
  setTimeout(()=>{
    const bins=areaAccum.length, nyq=audioCtx.sampleRate/2, R6=Math.pow(2,1/6);
    const db=GEQ.map(fc=>10*Math.log10(binOverlapLinearPower(areaAccum,fc/R6,fc*R6,nyq,areaFrames)+1e-12));
    const idx=areas.length;
    areas.push({name:AREA_NAMES[idx], color:AREA_COLORS[idx], db, show:true});
    areaState='idle'; updateAreaMeasBtn(); renderAreaList();
  },5000);
}
function renderAreaList(){
  const box=document.getElementById('areaList');
  if(!areas.length){ box.innerHTML='<div class="sub">אין אזורים עדיין — מדוד את הראשון.</div>'; return; }
  box.innerHTML=areas.map((a,i)=>
    '<div class="areaRow"><span class="dot" style="background:'+a.color+'"></span>'+
    '<span class="nm">'+a.name+'</span>'+
    '<button data-show="'+i+'" class="'+(a.show?'on':'')+'">'+(a.show?'מוצג':'מוסתר')+'</button>'+
    '<button data-del="'+i+'">מחק</button></div>').join('');
  box.querySelectorAll('[data-show]').forEach(b=>b.addEventListener('click',()=>{
    const i=+b.dataset.show; areas[i].show=!areas[i].show; renderAreaList();
  }));
  box.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',()=>{
    areas.splice(+b.dataset.del,1);
    areas.forEach((a,i)=>{ a.color=AREA_COLORS[i]; if(AREA_NAMES.includes(a.name)) a.name=AREA_NAMES[i]; });
    renderAreaList();
  }));
}

tfPanel=document.getElementById('tfPanel');
safeOn('tfClose', 'click',closeModals);
safeOn('tfSwapBtn', 'click',function(){ tfSwap=!tfSwap; resetTfAutoDelay(); resetDistanceCalibration(); this.classList.toggle('on',tfSwap); });
function setTfOverlay(on){
  tfOverlay=on;
  const a=document.getElementById('tfOverlayBtn'), b=document.getElementById('tfOverlayHdr');
  if(a) a.classList.toggle('on',on);
  if(b) b.classList.toggle('on',on);
}
safeOn('tfOverlayBtn', 'click',()=>setTfOverlay(!tfOverlay));
safeOn('tfMeasBtn', 'click',()=>pickSource(tfMeasure,6000));
safeOn('tfCsvBtn', 'click',tfExportCsv);

function tfWorkflowSignalPresent(data){
  if(!data||!data.length)return false;
  let peak=-120;
  for(let i=0;i<data.length;i+=8)if(data[i]>peak)peak=data[i];
  return peak>-85;
}
function evaluateTfVerification(coherence,gate,signalsOk){
  if(!signalsOk)return {ok:false,passing:0,checked:0,mean:0,reason:'אין מספיק אות בשני הערוצים'};
  const values=(coherence||[]).filter(Number.isFinite),checked=values.length;
  const passing=values.filter(c=>c>=Math.max(.4,gate)).length;
  const required=Math.max(3,Math.ceil(checked*.3));
  const mean=checked?values.reduce((sum,c)=>sum+c,0)/checked:0;
  const ok=checked>=3&&passing>=required;
  return {ok,passing,checked,mean,reason:ok?'':'קוהרנטיות נמוכה מדי בטווח המדידה'};
}
function tfWorkflowQuality(){
  if(!running||!analyserRef||!audioCtx)return {ok:false,reason:'אין מדידה דו־ערוצית פעילה'};
  const signalsOk=tfWorkflowSignalPresent(floatData)&&tfWorkflowSignalPresent(floatDataRef);
  const snap=tfCurrentSnapshot();
  if(!snap)return {ok:false,reason:'עדיין אין נתוני TF'};
  const coherence=[];
  const lo=Math.max(31.5,eqMinFreq),hi=Math.min(16000,eqMaxFreq),gate=Math.max(.4,tfCohGate);
  for(const f of GEQ){
    if(f<lo||f>hi)continue;
    const k=Math.min(snap.coh.length-1,Math.max(1,Math.round(f*TF_FFT_N/snap.sr)));
    const c=snap.coh[k];
    if(Number.isFinite(c))coherence.push(c);
  }
  return evaluateTfVerification(coherence,gate,signalsOk);
}
function setTfPhaseAndCoherence(on){
  showTfPhase=on;showTfCoh=on;
  const phase=document.getElementById('tfPhaseToggleBtn'),coh=document.getElementById('tfCohToggleBtn');
  const qPhase=document.getElementById('qbPhase'),qCoh=document.getElementById('qbCoh');
  if(phase)phase.classList.toggle('on',on);if(coh)coh.classList.toggle('on',on);
  if(qPhase)qPhase.classList.toggle('on',on);if(qCoh)qCoh.classList.toggle('on',on);
}
function syncTfWorkflowUi(message,tone){
  const busy=measureBusy();
  const sync=document.getElementById('tfAutoDelayBtn');
  const verify=document.getElementById('tfVerifyBtn');
  const trace=document.getElementById('tfTraceBtn');
  const eq=document.getElementById('tfMeasBtn');
  const info=document.getElementById('tfDelayInfo');
  if(sync){sync.classList.toggle('on',tfDelayReady);sync.textContent=tfDelayReady?'✓ 1 · TF '+tfDelayMs.toFixed(2)+'ms':'1 · סנכרון TF';sync.disabled=busy;}
  if(verify){verify.classList.toggle('on',tfWorkflowVerified);verify.textContent=tfWorkflowVerifying?'2 · מאמת…':tfWorkflowVerified?'✓ 2 · TF אומת':'2 · אימות TF';verify.disabled=busy||!tfDelayReady;}
  if(trace)trace.disabled=busy||!tfWorkflowVerified;
  if(eq)eq.disabled=busy||!tfWorkflowVerified;
  if(info){
    info.classList.remove('ready','warn');
    if(tone)info.classList.add(tone);
    if(message)info.innerHTML=message;
    else if(!tfDelayReady)info.innerHTML='<b>שלב 1:</b> הפעל אות רחב־פס ובצע סנכרון TF';
    else if(!tfWorkflowVerified)info.innerHTML='<b>✓ TF '+tfDelayMs.toFixed(2)+'ms</b> '+tfDelayQualityText+' · <b>שלב 2:</b> אמת פאזה וקוהרנטיות';
    else {info.classList.add('ready');info.innerHTML='<b>✓ TF מוכן</b> · בחר לכידת Trace או מדידת EQ';}
  }
}
function cancelTfWorkflowVerification(){
  if(tfWorkflowVerifyTimer){clearTimeout(tfWorkflowVerifyTimer);tfWorkflowVerifyTimer=null;}
  tfWorkflowVerifying=false;
}
function verifyTfWorkflow(){
  if(!tfDelayReady){v3Toast('תחילה בצע סנכרון TF');return;}
  if(measureBusy()){v3Toast('מדידה אחרת פעילה — המתן לסיומה');return;}
  setTfPhaseAndCoherence(true);
  tfWorkflowVerified=false;tfWorkflowVerifying=true;
  tfPxx.fill(0);tfPyy.fill(0);tfPxyRe.fill(0);tfPxyIm.fill(0);
  syncTfWorkflowUi('<b>שלב 2:</b> אוסף נתוני פאזה וקוהרנטיות במשך 2 שניות…');
  tfWorkflowVerifyTimer=setTimeout(()=>{
    tfWorkflowVerifyTimer=null;tfWorkflowVerifying=false;
    const q=tfWorkflowQuality();
    tfWorkflowVerified=!!q.ok;
    if(q.ok){
      syncTfWorkflowUi('<b>✓ שלב 2 הושלם</b> · '+q.passing+'/'+q.checked+' תחומים עברו סף קוהרנטיות · בחר Trace או EQ','ready');
      v3Toast('TF אומת — אפשר ללכוד Trace או למדוד EQ');
    }else{
      syncTfWorkflowUi('<b>שלב 2 לא עבר:</b> '+q.reason+' · בדוק רמות, ניתוב ו־Reference ונסה שוב','warn');
      v3Toast(q.reason);
    }
  },2000);
}
safeOn('tfVerifyBtn','click',()=>pickSource(verifyTfWorkflow,3000));


function tfCurrentSnapshot(){
  if(!analyserRef || !audioCtx) return null;
  computeComplexTf();
  const n=TF_FFT_N/2, mag=new Float32Array(n), ph=new Float32Array(n), coh=new Float32Array(n);
  const vals=[];
  for(let k=1;k<n;k++){
    const pxx=tfPxx[k], pyy=tfPyy[k], ps=tfPxyRe[k]*tfPxyRe[k]+tfPxyIm[k]*tfPxyIm[k];
    const c=Math.max(0,Math.min(1,ps/(pxx*pyy+1e-20)));
    const m=10*Math.log10((pyy+1e-20)/(pxx+1e-20));
    mag[k]=m; ph[k]=Math.atan2(tfPxyIm[k],tfPxyRe[k]); coh[k]=c;
    const f=k*audioCtx.sampleRate/TF_FFT_N;
    if(c>=Math.max(.55,tfCohGate) && f>=200 && f<=5000 && Number.isFinite(m)) vals.push(m);
  }
  vals.sort((a,b)=>a-b);
  const offset=vals.length?vals[Math.floor(vals.length/2)]:0;
  return {mag,ph,coh,offset,sr:audioCtx.sampleRate,delayMs:tfDelayMs,t:Date.now()};
}
function renderTfTraceLegend(){
  const el=document.getElementById('tfTraceLegend');
  if(el) el.innerHTML=tfTraces.filter(t=>t.type!=='rta').map((t,i)=>'<span><i style="background:'+t.color+'"></i>'+escapeHtml(t.name)+'</span>').join('');
  if(typeof v5RenderTraceRail==='function') v5RenderTraceRail();
}
function captureTfTrace(){
  if(!running||!analyserRef){ alert('הפעל כרטיס קול סטריאו (מיק + רפרנס).'); return; }
  if(!tfDelayReady||!tfWorkflowVerified){ alert('תחילה השלם סנכרון ואימות TF.'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  const s=tfCurrentSnapshot(); if(!s) return;
  const idx=tfTraces.length+1;
  s.type='tf'; s.visible=true; s.name='TF '+idx; s.color=TF_TRACE_COLORS[(idx-1)%TF_TRACE_COLORS.length];
  tfTraces.push(s); if(tfTraces.length>6) tfTraces.shift();
  renderTfTraceLegend(); v3Toast('נלכד '+s.name);
}
function captureWorkspaceTrace(){
  if(!running){v3Toast('הפעל Audio קודם');return;}
  if(v5WorkspaceMode==='tf'&&analyserRef){captureTfTrace();return;}
  const idx=tfTraces.length+1;
  tfTraces.push({type:'rta',visible:true,name:(mode==='spec'?'Waterfall ':'RTA ')+idx,color:TF_TRACE_COLORS[(idx-1)%TF_TRACE_COLORS.length],values:lastV.slice(),bands:BANDS,t:Date.now()});
  if(tfTraces.length>6)tfTraces.shift();
  renderTfTraceLegend();v3Toast('נלכד Trace להשוואה');
}
safeOn('tfTraceBtn','click',captureTfTrace);
safeOn('tfTraceClearBtn','click',()=>{tfTraces=[];renderTfTraceLegend();v3Toast('Traces נוקו');});

function tfMagY(db,plotH){ const range=18; return plotH/2 - Math.max(-range,Math.min(range,db))/range*(plotH*.46); }
function tfHasReferenceSignal(){
  if(!floatDataRef || !floatDataRef.length) return false;
  let peak=-120;
  // A sparse scan is enough to distinguish an actual reference feed from the
  // browser's silent floor, without adding work to every audio frame.
  for(let i=0;i<floatDataRef.length;i+=8) if(floatDataRef[i]>peak) peak=floatDataRef[i];
  return peak>-85;
}
function tfDrawMagnitudeView(W,plotH,nyquist){
  const live=tfCurrentSnapshot(); if(!live) return;
  // TF grid: 0 dB center, ±6/12/18 dB
  ctx.save();
  ctx.font='10px monospace'; ctx.textAlign='left';
  [-18,-12,-6,0,6,12,18].forEach(db=>{
    const y=tfMagY(db,plotH); ctx.strokeStyle=db===0?'rgba(62,166,255,.50)':'rgba(120,135,155,.18)';
    ctx.lineWidth=db===0?1.4:1; ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();
    ctx.fillStyle=sunMode?'#475569':'#8b97a5'; ctx.fillText((db>0?'+':'')+db+'dB',4,y-3);
  });
  const drawSnap=(snap,color,width,alpha)=>{
    ctx.beginPath(); let pen=false;
    for(let px=0;px<=W;px+=2){
      const f=freqForX(px), k=Math.min(snap.mag.length-1,Math.max(1,Math.round(f/snap.sr*TF_FFT_N)));
      const c=snap.coh[k]; if(c<tfCohGate){pen=false;continue;}
      const y=tfMagY(snap.mag[k]-snap.offset,plotH);
      pen?ctx.lineTo(px,y):ctx.moveTo(px,y); pen=true;
    }
    ctx.strokeStyle=color;ctx.globalAlpha=alpha;ctx.lineWidth=width;ctx.lineJoin='round';ctx.stroke();ctx.globalAlpha=1;
  };
  tfTraces.filter(t=>t.type!=='rta'&&t.visible!==false).forEach(t=>drawSnap(t,t.color,1.4,.72));
  drawSnap(live,'rgb('+accentRgb.join(',')+')',2.3,1);
  ctx.fillStyle=sunMode?'#0f172a':'#e6edf3';ctx.font='600 11px monospace';ctx.fillText('TF MAG · relative',8,14);
  ctx.restore();
}

function tfDrawDualLiveView(W,plotH){
  if(!lastV.length || !lastRefV.length) return;
  const bw=W/BANDS;
  const drawCurve=(values,color,fill)=>{
    const points=values.map((v,b)=>({x:b*bw+bw/2,y:plotH-Math.max(0,Math.min(1,v))*plotH}));
    if(!points.length)return;
    ctx.beginPath();ctx.moveTo(points[0].x,plotH);points.forEach(p=>ctx.lineTo(p.x,p.y));ctx.lineTo(points[points.length-1].x,plotH);ctx.closePath();ctx.fillStyle=fill;ctx.fill();
    ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle=color;ctx.lineWidth=2.4;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();
  };
  ctx.save();
  drawCurve(lastRefV,'#f59e0b','rgba(245,158,11,.075)');
  drawCurve(lastV,'#38bdf8','rgba(56,189,248,.11)');
  ctx.font='700 11px monospace';ctx.textAlign='left';
  const micLevel=Number.isFinite(v52MeasDbfs)?v52MeasDbfs:smoothedDbfs;
  const refLevel=Number.isFinite(v52RefDbfs)?v52RefDbfs:-120;
  const legendX=50;
  ctx.fillStyle=sunMode?'rgba(255,255,255,.92)':'rgba(7,16,24,.86)';ctx.fillRect(legendX,8,258,40);
  ctx.strokeStyle=sunMode?'#cbd5e1':'#294052';ctx.strokeRect(legendX,8,258,40);
  ctx.fillStyle='#38bdf8';ctx.fillText('● MIC 1  '+micLevel.toFixed(1)+' dBFS',legendX+9,24);
  ctx.fillStyle='#f59e0b';ctx.fillText('● REF 2  '+refLevel.toFixed(1)+' dBFS',legendX+9,41);
  ctx.textAlign='right';ctx.font='9px monospace';ctx.fillStyle=sunMode?'#64748b':'#8193a2';
  ctx.fillText(ceilDb+' dBFS',W-7,13);ctx.fillText(Math.round((ceilDb+floorDb)/2)+' dBFS',W-7,plotH/2);ctx.fillText(floorDb+' dBFS',W-7,plotH-5);
  ctx.restore();
}

function detectComb(){
  if(!floatData || !audioCtx) return null;
  const bins=floatData.length, nyq=audioCtx.sampleRate/2;
  const loF=200, hiF=8000, M=600;
  const grid=new Float64Array(M);
  for(let i=0;i<M;i++){ const f=loF+(hiF-loF)*i/(M-1); const b=Math.round(f/nyq*bins); grid[i]=floatData[Math.max(0,Math.min(bins-1,b))]; }
  const W=25, rip=new Float64Array(M);
  for(let i=0;i<M;i++){ let s=0,c=0; for(let j=-W;j<=W;j++){const k=i+j; if(k>=0&&k<M){s+=grid[k];c++;}} rip[i]=grid[i]-s/c; }
  let mean=0; for(let i=0;i<M;i++) mean+=rip[i]; mean/=M; for(let i=0;i<M;i++) rip[i]-=mean;
  let norm=0; for(let i=0;i<M;i++) norm+=rip[i]*rip[i];
  if(norm<1e-9) return null;
  let best={lag:0,val:0};
  for(let lag=4;lag<M/2;lag++){ let s=0; for(let i=0;i<M-lag;i++) s+=rip[i]*rip[i+lag]; const v=s/norm; if(v>best.val) best={lag,val:v}; }
  const dfPerPoint=(hiF-loF)/(M-1);
  const spacingHz=best.lag*dfPerPoint;
  const delayMs=spacingHz>0?1000/spacingHz:0;
  let depth=0; for(let i=0;i<M;i++) depth+=rip[i]*rip[i]; depth=Math.sqrt(depth/M)*2;
  const inRange = delayMs>=1.4 && delayMs<=6.5;
  return {spacingHz, delayMs, strength:best.val, depth, inRange};
}
function runCombCheck(resultId){
  const el=document.getElementById(resultId||'combResult'); if(!el) return;
  el.style.display='block';
  const r=detectComb();
  if(!r){ el.innerHTML='<span style="color:var(--dim)">אין מספיק אות. נגן רעש ורוד ונסה שוב.</span>'; return; }
  const detected = r.strength>0.28 && r.depth>1.5;
  if(detected && r.inRange){
    const dist=r.delayMs/1000*343;
    el.innerHTML='⚠ <b style="color:var(--warn)">זוהה ביטול (comb)</b><br>'+
      '<span style="font-size:11px;color:var(--dim)">מרווח ~'+Math.round(r.spacingHz)+'Hz → הפרש זמן ~'+r.delayMs.toFixed(2)+'ms (~'+dist.toFixed(2)+'מ\').<br>'+
      'מקור אפשרי: החזר מקיר/רצפה או שני רמקולים לא מיושרים.</span>';
  } else if(detected){
    el.innerHTML='⚠ <b style="color:var(--warn)">נראות אדוות בתגובה</b><br>'+
      '<span style="font-size:11px;color:var(--dim)">הפרש הזמן מחוץ לטווח שניתן למדוד כאן בוודאות (1.5–6ms).<br>'+
      'למדידת הפרש זמן מדויק השתמש בכלי הדיליי.</span>';
  } else {
    el.innerHTML='<b style="color:#39d98a">✓ לא זוהה ביטול משמעותי</b><br><span style="font-size:11px;color:var(--dim)">התגובה חלקה יחסית.</span>';
  }
}
function updateTfLevels(){
  if(!floatDataRef || !analyserRef) return;
  analyser.getFloatTimeDomainData(timeData);
  if(!timeDataRef || timeDataRef.length!==analyserRef.fftSize) timeDataRef=new Float32Array(analyserRef.fftSize);
  analyserRef.getFloatTimeDomainData(timeDataRef);
  setGainEl(document.getElementById('tfMicFill'), document.getElementById('tfMicDb'), levelDb(timeData,2048));
  setGainEl(document.getElementById('tfRefFill'), document.getElementById('tfRefDb'), levelDb(timeDataRef,2048));
  document.getElementById('tfL1').textContent = tfSwap?"כניסה 1 → רפרנס":"כניסה 1 → מיק'";
  document.getElementById('tfL2').textContent = tfSwap?"כניסה 2 → מיק'":"כניסה 2 → רפרנס";
  
  const N=1024, maxLag=Math.min(4800, timeDataRef.length-N-1);
  const oa=timeData.length-N;
  let bestAbs=0, r=0, bestLag=0, bestVa=0, bestVb=0;
  let _cVa=0, _cVb=0;
  const corrAt=(ob)=>{
    let sa=0,sb=0,saa=0,sbb=0,sab=0;
    for(let i=0;i<N;i++){ const x=timeData[oa+i], y=timeDataRef[ob+i]; sa+=x;sb+=y;saa+=x*x;sbb+=y*y;sab+=x*y; }
    const cov=sab-sa*sb/N, va=saa-sa*sa/N, vb=sbb-sb*sb/N, den=Math.sqrt(va*vb);
    _cVa=va; _cVb=vb;
    return den>1e-9 ? cov/den : 0;
  };
  for(let lag=0; lag<=maxLag; lag+=4){
    const ob=timeDataRef.length-N-lag; if(ob<0) break;
    const c=corrAt(ob); if(Math.abs(c)>bestAbs){ bestAbs=Math.abs(c); r=c; bestLag=lag; bestVa=_cVa; bestVb=_cVb; }
  }
  for(let lag=Math.max(0,bestLag-6); lag<=Math.min(maxLag,bestLag+6); lag++){
    const ob=timeDataRef.length-N-lag; if(ob<0) continue;
    const c=corrAt(ob); if(Math.abs(c)>bestAbs){ bestAbs=Math.abs(c); r=c; bestVa=_cVa; bestVb=_cVb; }
  }
  _tfCorr += ((r||0)-_tfCorr)*0.15;
  const fill=document.getElementById('tfCorrFill'), marker=document.getElementById('tfCorrMarker'), val=document.getElementById('tfCorrVal'), tip=document.getElementById('tfCorrTip');
  if(fill){
    const w=Math.abs(_tfCorr)*50;
    fill.style.width=w+'%';
    if(_tfCorr>=0){ fill.style.left='50%'; fill.style.right='auto'; } else { fill.style.right='50%'; fill.style.left='auto'; }
    const col=_tfCorr>0.4?'#39d98a':_tfCorr<-0.2?'var(--hot)':'var(--warn)';
    fill.style.background=col;
    if(marker) marker.style.left=((_tfCorr+1)*50)+'%';
    if(val){ val.textContent=(_tfCorr>=0?'+':'')+_tfCorr.toFixed(2); val.style.color=col; }
    if(tip){
      tip.style.color=col;
      tip.textContent = bestVa<1e-6||bestVb<1e-6 ? 'אין מספיק אות בשני הערוצים' : _tfCorr<-0.2?'⚠ חשד לפולריות הפוכה' : _tfCorr>0.75?'מצוין · התאמה חזקה' : _tfCorr>0.4?'טוב · קיימת התאמה' : 'התאמה חלשה';
    }
  }
}
function tfMeasure(){
  if(!running||!analyserRef){ alert('הפעל מיקרופון עם כרטיס קול (input סטריאו).'); return; }
  if(!tfDelayReady||!tfWorkflowVerified){ alert('תחילה השלם סנכרון ואימות TF.'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  unfreezeForMeasure();
  const bins=floatData.length;
  tfPxx.fill(0);tfPyy.fill(0);tfPxyRe.fill(0);tfPxyIm.fill(0);
  tfMic=new Float64Array(bins); tfRef=new Float64Array(bins); tfFrames=0; tfState='measuring';
  const btn=document.getElementById('tfMeasBtn'); btn.textContent='מודד EQ…'; btn.style.opacity=.5;
  syncTfWorkflowUi();
  setTimeout(()=>{
    tfState='idle'; btn.textContent='3ב · מדוד EQ שוב'; btn.style.opacity=1;
    tfCompute();
    syncTfWorkflowUi();
  },6000);
}
function tfBandCoherence(fc,halfWidthRatio,sr){
  const lo=fc/halfWidthRatio,hi=fc*halfWidthRatio,n=tfPxx.length;
  const first=Math.max(1,Math.floor(lo/sr*TF_FFT_N)),last=Math.min(n-1,Math.ceil(hi/sr*TF_FFT_N));
  let weighted=0,weight=0;
  for(let k=first;k<=last;k++){
    const w=tfPxx[k]*tfPyy[k];if(w<=1e-20)continue;
    weighted+=tfPxyRe[k]*tfPxyRe[k]+tfPxyIm[k]*tfPxyIm[k];weight+=w;
  }
  return Math.max(0,Math.min(1,weighted/(weight+1e-20)));
}
function tfCompute(){
  if(!tfFrames){ return; }
  const bins=tfMic.length, nyq=audioCtx.sampleRate/2, R6=Math.pow(2,1/6);
  const H=[], refB=[],coh=[]; let refMax=-999;
  for(let k=0;k<GEQ.length;k++){
    const fc=GEQ[k];
    const pm=binOverlapLinearPower(tfMic,fc/R6,fc*R6,nyq,tfFrames);
    const pr=binOverlapLinearPower(tfRef,fc/R6,fc*R6,nyq,tfFrames);
    const micDb=10*Math.log10(pm+1e-12);
    refB[k]=10*Math.log10(pr+1e-12);
    H[k]=micDb-refB[k];
    coh[k]=tfBandCoherence(fc,R6,audioCtx.sampleRate);
    refMax=Math.max(refMax,refB[k]);
  }
  if(micCal){ for(let k=0;k<GEQ.length;k++) H[k]-=micCalAt(GEQ[k]); }
  const rel=GEQ.map((f,k)=> refB[k]>refMax-25 && coh[k]>=tfCohGate && f>=eqMinFreq && f<=eqMaxFreq);
  const on=rel.filter(Boolean).length;
  const corr=buildCorr(H, rel);
  tfResult={corr,H,rel,coh};
  document.getElementById('tfInfo').textContent = on? 'מוצגים רק פסים שעברו גם סף Reference וגם קוהרנטיות '+tfCohGate.toFixed(2)+'.' :
    'אין פסים אמינים — בדוק Reference, סנכרון TF, קוהרנטיות או החלפת ערוצים.';
  renderTFList();
}

function renderTFList(){
  const box = document.getElementById('tfGeqList');
  const cv2 = document.getElementById('tfCanvas');
  if(!tfResult){
    box.innerHTML='<div class="sub" style="padding:9px 10px;border:1px solid var(--line);border-radius:4px;background:var(--panel-2)">עדיין אין תוצאת TF. אפשר לכוון כאן Phase, Coh, Delay ועקומת יעד; לתוצאת תגובה מלאה ודא שערוץ 2 מקבל Reference ולחץ “מדוד EQ”.</div>';
    cv2.style.display = 'none';
    return;
  }
  
  showGeqDock('תיקון EQ · דו־ערוצי');
  drawGEQ(document.getElementById('eqCurveCanvas'), GEQ, tfResult.corr);
  cv2.style.display='none';
  eqCurveData = { freqs: GEQ.slice(), corr: tfResult.corr.slice() };

  if(tfMode==='param'){
    const head='<div class="sub" style="margin-bottom:6px;color:var(--text);font-weight:600;">EQ פרמטרי · אופטימיזציית 6 Bands (יעד '+(targetMode==='house'?'House':'שטוח')+'):</div>';
    box.innerHTML = head + corrParamHtml(tfResult.corr);
    return;
  }
  const head='<div class="sub" style="margin-bottom:6px; color:var(--text); font-weight:600;">ערכי תיקון לגרפיק-EQ (31 פסים):</div>';
  box.innerHTML = head + corrGridHtml(tfResult.corr, tfResult.rel);
}

function tfExportCsv(){
  if(!tfResult){ alert('קודם מדוד.'); return; }
  let rows='freq_hz,geq_correction_db,measured_db\n';
  GEQ.forEach((f,k)=> rows+=f+','+(tfResult.corr[k]==null?'':tfResult.corr[k].toFixed(1))+','+tfResult.H[k].toFixed(1)+'\n');
  download('tf_geq_'+stamp()+'.csv', URL.createObjectURL(new Blob([rows],{type:'text/csv'})));
}

const dlyPanel=document.getElementById('dlyPanel');
safeOn('dlyBtn', 'click',()=>{
  showModal(dlyPanel);
  if(running && !workletReady){
    const st=document.getElementById('dlyStatus');
    if(st){ st.innerHTML='<span style="color:var(--warn)">⚠ מנוע ההקלטה לא נטען — מדידת דיליי לא תעבוד. פתח את האתר דרך שרת/HTTPS (לא כקובץ מקומי).</span>'; }
  }
});
safeOn('dlyClose', 'click',closeModals);
function resetDelay(){
  dlyState='idle';
  dlyLastPathResult=null;dlyLastSpeakerResult=null;
  dlySpeakers.forEach((s,i)=>{ s.ms=null;s.confidence=0;s.spreadMs=null;s.name=dlyName(i); });
  dlyAnchor=0;
  resetDistanceCalibration();
  const st=document.getElementById('dlyStatus'); if(st){delete st.dataset.delayResult;st.textContent='—';}
  renderDlySpk();
}
safeOn('dlyReset', 'click',resetDelay);
safeOn('dlyMeasBtn', 'click',()=>pickSource(measureDelay,3800));

function syncDelayRangeUi(){
  document.querySelectorAll('[data-delay-range] button').forEach(b=>b.classList.toggle('on',Number(b.dataset.ms)===delaySearchMs));
}
document.querySelectorAll('[data-delay-range] button').forEach(b=>b.addEventListener('click',function(){
  delaySearchMs=Math.max(20,Math.min(100,Number(this.dataset.ms)||50));
  syncDelayRangeUi();
}));
syncDelayRangeUi();

function delayMsToMeters(ms){ return Number(ms)*343/1000; }
function validateDistanceCalibration(pathMs,knownM,toleranceMs=.25){
  const path=Number(pathMs),known=Number(knownM),tolerance=Math.max(0,Number(toleranceMs)||0);
  if(!Number.isFinite(path)||path<0||!Number.isFinite(known)||known<=0){
    return {ok:false,reason:'נתוני הכיול אינם תקינים'};
  }
  const acousticMs=known/343*1000;
  const rawOffsetMs=path-acousticMs;
  const measuredMaxM=delayMsToMeters(path);
  if(rawOffsetMs < -tolerance){
    return {ok:false,reason:'המרחק שהוזן גדול מזמן ההגעה שנמדד',pathMs:path,knownM:known,acousticMs,rawOffsetMs,measuredMaxM};
  }
  return {ok:true,pathMs:path,knownM:known,acousticMs,rawOffsetMs,offsetMs:Math.max(0,rawOffsetMs),measuredMaxM,clamped:rawOffsetMs<0};
}
function calibratedDistanceMeters(pathMs,offsetMs){
  if(pathMs==null||pathMs===''||offsetMs==null||offsetMs==='')return null;
  if(!Number.isFinite(Number(pathMs))||!Number.isFinite(Number(offsetMs)))return null;
  if(Number(offsetMs)<0)return null;
  return Math.max(0,delayMsToMeters(Number(pathMs)-Number(offsetMs)));
}
function delayDisplayValue(pathMs,unit,offsetMs){
  if(unit==='m'){
    const distance=calibratedDistanceMeters(pathMs,offsetMs);
    return distance==null?null:{value:distance,unit:'m'};
  }
  const value=Number(pathMs);
  return Number.isFinite(value)?{value,unit:'ms'}:null;
}
function updateDlyUnitUi(){
  document.querySelectorAll('#dlyUnitSeg button').forEach(b=>b.classList.toggle('on',b.dataset.unit===dlyDisplayUnit));
  const cal=document.getElementById('dlyDistanceCal');
  if(cal){cal.classList.toggle('show',dlyDisplayUnit==='m');cal.classList.toggle('calibrated',Number.isFinite(dlyDistanceOffsetMs));cal.classList.toggle('invalid',!!dlyDistanceCalError);}
  const state=document.getElementById('dlyDistanceCalState');
  if(state){
    state.innerHTML=Number.isFinite(dlyDistanceOffsetMs)
      ? '<span style="color:#42d57b">✓ מכויל</span> · מרחק ייחוס '+dlyDistanceKnownM.toFixed(1)+'m · קיזוז מערכת '+dlyDistanceOffsetMs.toFixed(2)+'ms'
      : dlyDistanceCalError
        ? '<span style="color:var(--hot)">✕ הכיול נדחה</span> · '+dlyDistanceCalError
        : 'למרחק אמיתי צריך לכייל פעם אחת מול מרחק ידוע.';
  }
  const info=document.getElementById('dlyInfo');
  if(info)info.textContent=dlyDisplayUnit==='m'
    ? (Number.isFinite(dlyDistanceOffsetMs)?'מרחק משוער לאחר הפחתת זמן המערכת. החלפת רמקול, DSP, ניתוב או כרטיס מחייבת כיול מחדש.':dlyDistanceCalError?'הכיול לא נשמר. תקן את המרחק הידוע ובצע מדידה מחדש.':'הצב את המיקרופון במרחק מדוד מהרמקול וכייל לפני הצגת מטרים.')
    : 'הזמן המוחלט כולל את כל שרשרת המדידה ואינו מרחק פיזי. לכיוון רמקולים השתמש רק ב־Δ מול העוגן.';
  if(typeof renderDlySpk==='function')renderDlySpk();
}
function resetDistanceCalibration(errorMessage=''){
  dlyDistanceOffsetMs=null;
  dlyDistanceCalError=errorMessage;
  updateDlyUnitUi();
}
document.querySelectorAll('#dlyUnitSeg button').forEach(b=>b.addEventListener('click',function(){
  dlyDisplayUnit=this.dataset.unit==='m'?'m':'ms';updateDlyUnitUi();
  const st=document.getElementById('dlyStatus');
  if(st&&st.dataset.delayResult==='path'&&dlyLastPathResult)renderDelayPathResult(dlyLastPathResult);
  else if(st&&st.dataset.delayResult==='speaker'&&dlyLastSpeakerResult)renderSpeakerMeasurementStatus(dlyLastSpeakerResult.index,dlyLastSpeakerResult.result);
  else if(st&&dlyDisplayUnit==='m'&&!Number.isFinite(dlyDistanceOffsetMs))st.textContent='כדי למדוד מרחק: הצב את המיקרופון במרחק ידוע ולחץ “כייל מרחק”.';
}));

function fft(re,im,inv){
  const n=re.length;
  for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit;
    if(i<j){ const tr=re[i];re[i]=re[j];re[j]=tr; const ti=im[i];im[i]=im[j];im[j]=ti; } }
  for(let len=2;len<=n;len<<=1){
    const ang=(inv?2:-2)*Math.PI/len, wr=Math.cos(ang), wi=Math.sin(ang);
    for(let i=0;i<n;i+=len){ let cwr=1,cwi=0;
      for(let k=0;k<len/2;k++){
        const a=i+k, b=i+k+len/2;
        const vr=re[b]*cwr-im[b]*cwi, vi=re[b]*cwi+im[b]*cwr;
        re[b]=re[a]-vr; im[b]=im[a]-vi; re[a]+=vr; im[a]+=vi;
        const t=cwr*wr-cwi*wi; cwi=cwr*wi+cwi*wr; cwr=t;
      }
    }
  }
  if(inv){ for(let i=0;i<n;i++){ re[i]/=n; im[i]/=n; } }
}

let dlyState='idle', timeDataRef=null;
document.querySelectorAll('#meterModeSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#meterModeSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); meterMode=this.dataset.m;
}));
function levelDb(buf,n){
  const len=buf.length; n=n||len; const start=Math.max(0,len-n);
  if(meterMode==='peak'){ let m=0; for(let i=start;i<len;i++){ const a=Math.abs(buf[i]); if(a>m)m=a; } return 20*Math.log10(m+1e-9); }
  let s=0; for(let i=start;i<len;i++){ const v=buf[i]; s+=v*v; } return 20*Math.log10(Math.sqrt(s/(len-start))+1e-9);
}
function gainClass(db){
  if(db>=-1) return ['clip','קליפ!'];
  if(db>=-8) return ['hi','חזק ('+db.toFixed(0)+')'];
  if(db>=-40) return ['ok','טוב ('+db.toFixed(0)+')'];
  return ['lo','חלש ('+db.toFixed(0)+')'];
}
function setGainEl(fill,lbl,db){
  let s=db;
  if(fill){
    s=fill._sdb; if(s==null||!isFinite(s)) s=db;
    s += (db>s ? 0.55 : 0.035) * (db - s);
    fill._sdb=s;
    fill.style.width=Math.max(2,Math.min(100,(s+60)/60*100))+'%';
  }
  const [cls,txt]=gainClass(s);
  if(fill) fill.className='fill '+cls;
  if(lbl){ lbl.className='gainLbl '+cls; lbl.textContent=txt; }
}
function setGain(id, db){ setGainEl(document.getElementById(id+'Fill'), document.getElementById(id+'Gain'), db); }

function delayChecksHtml(res){
  const checks=res&&Array.isArray(res.checks)?res.checks:[];
  let html='<span class="delayChecks" title="שלוש בדיקות יציבות">';
  for(let i=0;i<3;i++)html+='<i class="'+(checks[i]&&checks[i].reliable?'ok':'bad')+'"></i>';
  return html+'</span>';
}
function delayFailureText(res,silent){
  if(silent==='mic')return 'המיקרופון לא קלט אות — בדוק גיין וחיבור.';
  if(silent==='ref')return 'כניסה 2 (Reference) שקטה — בדוק את הניתוב מהמיקסר.';
  if(res&&res.validChecks)return 'התוצאה לא יציבה: רק '+res.validChecks+' מתוך 3 בדיקות התאימו. נסה Sweep, העלה רמה או השתק החזרות קרובות.';
  return 'לא נמצא זמן הגעה ברור — ודא ששני הערוצים מקבלים אותו אות רחב־פס.';
}
function dlyPathResultHtml(ms){
  const displayed=delayDisplayValue(ms,dlyDisplayUnit,dlyDistanceOffsetMs);
  if(dlyDisplayUnit==='m'&&displayed){
    return 'מרחק אקוסטי משוער: <b>'+displayed.value.toFixed(2)+' מטר</b><br><span style="font-size:11px;color:var(--dim)">לאחר הפחתת קיזוז המערכת המכויל</span>';
  }
  if(dlyDisplayUnit==='m'){
    return '<span style="color:var(--warn)">לא ניתן להציג מרחק לפני כיול מול מרחק ידוע</span>';
  }
  return 'זמן נתיב כולל: <b>'+ms.toFixed(2)+' ms</b>';
}
function renderDelayPathResult(res){
  const st=document.getElementById('dlyStatus');
  const ms=res.ms;
  const spread=dlyDisplayUnit==='m'
    ? (Number.isFinite(dlyDistanceOffsetMs)?delayMsToMeters(res.spreadMs).toFixed(2)+'m':'—')
    : res.spreadMs.toFixed(2)+'ms';
  const quality='יציב '+res.validChecks+'/3 · אמינות '+Math.round(res.confidence*100)+'% · פיזור '+spread;
  const alternativeValues=res.alternatives&&res.alternatives.length
    ? res.alternatives.map(v=>{
        const displayed=delayDisplayValue(v,dlyDisplayUnit,dlyDistanceOffsetMs);
        return displayed?(displayed.unit==='m'?'≈'+displayed.value.toFixed(2)+'m':(v>=0?'+':'')+displayed.value.toFixed(1)+'ms'):null;
      }).filter(Boolean).join(', ')
    : '';
  const alternatives=alternativeValues?'<br>פסגות חלופיות: '+alternativeValues:'';
  st.innerHTML=dlyPathResultHtml(ms)+' '+delayChecksHtml(res)+'<br><span style="font-size:11px;color:var(--dim)">'+quality+(dlyDisplayUnit==='ms'?' · לא ממירים את המספר הזה למרחק':'')+alternatives+'</span>';
  st.dataset.delayResult='path';
}
function measureDelay(){ runDelayCapture(document.getElementById('dlyMeasBtn'), (res, silent)=>{
  const st=document.getElementById('dlyStatus');
  dlyLastSpeakerResult=null;
  if(!res||!res.reliable){ dlyLastPathResult=null;delete st.dataset.delayResult;st.textContent=delayFailureText(res,silent); return; }
  dlyLastPathResult=res;
  renderDelayPathResult(res);
},{maxDelayMs:delaySearchMs,mode:'arrival'}); }
function delayChunkSize(sr,maxDelayMs){
  const required=Math.ceil(sr*Math.max(2,Math.min(100,Number(maxDelayMs)||50))/1000);
  let n=8192; while(n/2-2<required&&n<65536)n*=2; return n;
}
function runDelayCapture(btn, cb, options){
  options=options||{};
  if(!running||!analyserRef||!source){ alert('צריך כרטיס קול עם input סטריאו (מיק\'+רפרנס).'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  unfreezeForMeasure();
  dlyState='measuring';
  const prevTxt=btn?btn.textContent:''; if(btn){btn.textContent='בודק 1 · 2 · 3…';btn.style.opacity=.5;btn.disabled=true;}
  const sr=audioCtx.sampleRate;
  const maxDelayMs=Math.max(20,Math.min(100,Number(options.maxDelayMs)||delaySearchMs));
  const minCapture=delayChunkSize(sr,maxDelayMs)*3/sr+.35;
  const captureSec = (genOn && genType==='sweep') ? Math.min(10,Math.max(3.2,minCapture,genSweepDur+0.6)) : Math.max(3.2,minCapture);
  const want=Math.floor(sr*captureSec);
  const mic=new Float32Array(want), ref=new Float32Array(want); let pos=0;
  let workletNode;
  try {
    workletNode = new AudioWorkletNode(audioCtx, 'recorder-worklet');
  } catch(e) {
    alert('AudioWorklet לא נטען. פתח את האתר דרך שרת (למשל Live Server ב-VSCode) ולא כקובץ מתיקייה.');
    dlyState='idle'; if(btn){btn.textContent=prevTxt;btn.style.opacity=1;btn.disabled=false;}
    return;
  }

  const mute=audioCtx.createGain(); mute.gain.value=0;
  source.connect(workletNode); workletNode.connect(mute); mute.connect(audioCtx.destination);
  
  workletNode.port.onmessage = e => {
    if (pos >= want) return;
    const c0 = e.data.mic, c1 = e.data.ref;
    const len = Math.min(c0.length, want - pos);
    for(let i=0; i<len; i++) { mic[pos]=c0[i]; ref[pos]=c1[i]; pos++; }
  };
  workletNode.port.postMessage({ cmd: 'start', micChannel:measChannel, refChannel:refChannel });

  setTimeout(()=>{
    workletNode.port.postMessage({ cmd: 'stop' });
    // Give the worklet one message turn to flush its last partial block before
    // disconnecting and analysing the complete capture.
    setTimeout(()=>{
      try{ source.disconnect(workletNode); }catch(_){} try{ workletNode.disconnect(); }catch(_){} try{ mute.disconnect(); }catch(_){}
      dlyState='idle'; if(btn){btn.textContent=prevTxt;btn.style.opacity=1;btn.disabled=false;}
      const m = tfSwap? ref: mic, r = tfSwap? mic: ref;
      const rmsOf=(a)=>{ let s=0; for(let i=0;i<a.length;i++) s+=a[i]*a[i]; return Math.sqrt(s/a.length); };
      const micRms=rmsOf(m), refRms=rmsOf(r);
      if(micRms<1e-4 || refRms<1e-4){ cb(null, micRms<1e-4?'mic':'ref'); return; }
      // Tell the estimator what kind of excitation it is looking at. A swept
      // sine is narrowband inside any short analysis chunk, so it must be
      // correlated across the whole capture instead of per-chunk. Pink/white
      // noise stays on the proven per-chunk path; anything else ('auto') tries
      // the chunk path first and falls back to full-capture correlation.
      const signalType=(genOn&&genType==='sweep')?'sweep'
        :(genOn&&(genType==='pink'||genType==='white'))?'noise':'auto';
      cb(computeStableDelay(r, m, sr, {maxDelayMs, signalType}));
    },60);
  }, captureSec*1000+100);
}

safeOn('dlyLoopbackBtn','click',function(){
  if(!confirm('בדיקת חיבור דורשת שאותו אות בדיוק יגיע לשתי הכניסות.\nחבר/נתב את אותו Reference ל־MIC 1 ול־REF 2, ואז המשך.'))return;
  const btn=this,st=document.getElementById('dlyStatus');
  dlyLastPathResult=null;dlyLastSpeakerResult=null;delete st.dataset.delayResult;
  pickSource(()=>runDelayCapture(btn,(res,silent)=>{
    if(!res||!res.reliable){st.textContent=delayFailureText(res,silent);return;}
    const ok=Math.abs(res.ms)<=.30;
    st.innerHTML=(ok?'✓ החיבור מסונכרן':'⚠ קיים הפרש בין הכניסות')+': <b>'+res.ms.toFixed(2)+' ms</b> '+delayChecksHtml(res)+'<br><span style="font-size:11px;color:'+(ok?'var(--dim)':'var(--warn)')+'">'+(ok?'אפשר להמשיך למדידת רמקולים.':'בדוק עיבוד, ניתוב או פלאגינים באחד הערוצים לפני מדידת שטח.')+'</span>';
  },{maxDelayMs:20,mode:'loopback'}),3800);
});

safeOn('dlyDistanceCalBtn','click',function(){
  const input=document.getElementById('dlyKnownDistance');
  const known=Number(input&&input.value);
  const btn=this,st=document.getElementById('dlyStatus');
  dlyLastPathResult=null;dlyLastSpeakerResult=null;delete st.dataset.delayResult;
  if(!Number.isFinite(known)||known<.2||known>20){
    resetDistanceCalibration('הזן מרחק ידוע בין 0.2 ל־20 מטר');
    st.innerHTML='<span style="color:var(--hot)">✕ הכיול לא התחיל:</span> הזן מרחק ידוע תקין בין 0.2 ל־20 מטר.';
    return;
  }
  if(input)input.value=known.toFixed(1);
  resetDistanceCalibration();
  st.textContent='הצב את המיקרופון בדיוק '+known.toFixed(1)+' מטר מהרמקול והשאר את אותו ניתוב.';
  pickSource(()=>runDelayCapture(btn,(res,silent)=>{
    if(!res||!res.reliable){st.textContent=delayFailureText(res,silent);return;}
    const check=validateDistanceCalibration(res.ms,known);
    if(!check.ok){
      const measured=Number.isFinite(check.measuredMaxM)?check.measuredMaxM.toFixed(2):'—';
      const reason='הוזנו '+known.toFixed(1)+'m, אך זמן ההגעה '+res.ms.toFixed(2)+'ms מתאים לכל היותר לכ־'+measured+'m';
      resetDistanceCalibration(reason);
      dlyDisplayUnit='m';updateDlyUnitUi();
      st.innerHTML='<span style="color:var(--hot)">✕ הכיול נדחה ולא נשמר.</span> '+reason+'.<br><span style="font-size:11px;color:var(--dim)">בדוק את המרחק מהמרכז האקוסטי של הרמקול והפעל כיול מחדש.</span>';
      return;
    }
    dlyDistanceKnownM=known;
    dlyDistanceOffsetMs=check.offsetMs;
    dlyDistanceCalError='';
    dlyDisplayUnit='m';
    updateDlyUnitUi();
    const clampNote=check.clamped?' · סטייה של '+Math.abs(check.rawOffsetMs).toFixed(2)+'ms נוטרלה בתחום הסבילות':'';
    st.innerHTML='✓ כיול מרחק נשמר לסשן: <b>'+known.toFixed(1)+'m</b> '+delayChecksHtml(res)+'<br><span style="font-size:11px;color:var(--dim)">נמדדו '+res.ms.toFixed(2)+'ms · זמן אקוסטי צפוי '+check.acousticMs.toFixed(2)+'ms · קיזוז מערכת '+dlyDistanceOffsetMs.toFixed(2)+'ms'+clampNote+'.</span>';
  },{maxDelayMs:delaySearchMs,mode:'distance-calibration'}),3800);
});

const DLY_NAMES=['Top','Sub','FF'];
function dlyName(i){ return DLY_NAMES[i] || ('רמקול '+(i+1)); }
let dlySpeakers=[{name:dlyName(0),ms:null,confidence:0,spreadMs:null},{name:dlyName(1),ms:null,confidence:0,spreadMs:null}];
let dlyAnchor=0;
function setDlyCount(n){
  const cur=dlySpeakers.length;
  if(n>cur){ for(let i=cur;i<n;i++) dlySpeakers.push({name:dlyName(i),ms:null,confidence:0,spreadMs:null}); }
  else if(n<cur){ dlySpeakers=dlySpeakers.slice(0,n); if(dlyAnchor>=n) dlyAnchor=0; }
  renderDlySpk();
}
function renderDlySpk(){
  const box=document.getElementById('dlySpk'); if(!box) return;
  box.innerHTML=dlySpeakers.map((s,i)=>{
    let add='—';
    if(s.ms!=null && dlySpeakers[dlyAnchor] && dlySpeakers[dlyAnchor].ms!=null){
      if(i===dlyAnchor) add='<span style="color:var(--accent)">עוגן · יעד</span>';
      else{ const d=dlySpeakers[dlyAnchor].ms - s.ms;
        const equivalentM=delayMsToMeters(Math.abs(d));
        if(Math.abs(d)<=.05)add='<b style="color:var(--accent)">✓ מיושר לעוגן</b>';
        else if(d>0)add=dlyDisplayUnit==='m'
          ? '<b style="color:var(--accent)">דיליי שקול +'+equivalentM.toFixed(2)+'m</b>'
          : '<b style="color:var(--accent)">הוסף '+d.toFixed(2)+' ms</b>';
        else add=dlyDisplayUnit==='m'
          ? '<span style="color:var(--warn)">מאוחר ב־'+equivalentM.toFixed(2)+'m<br>בחר אותו כעוגן</span>'
          : '<span style="color:var(--warn)">מאוחר ב־'+Math.abs(d).toFixed(2)+'ms<br>בחר אותו כעוגן</span>'; }
    }
    const distance=s.ms==null?null:calibratedDistanceMeters(s.ms,dlyDistanceOffsetMs);
    const time=s.ms==null?'טרם נמדד'
      :dlyDisplayUnit==='m'
        ?(distance==null?'נדרש כיול מטרים':'≈ '+distance.toFixed(2)+' m')
        :'נתיב '+s.ms.toFixed(2)+' ms'+(s.spreadMs!=null?' · ±'+(s.spreadMs/2).toFixed(2):'');
    return '<div class="dlySpeakerRow '+(i===dlyAnchor?'anchor':'')+'">'+
      '<span class="dlyAnchor" data-a="'+i+'" title="בחר כעוגן">'+(i===dlyAnchor?'●':'○')+'</span>'+
      '<input class="posName" data-i="'+i+'" value="'+escapeHtml(s.name||dlyName(i))+'">'+
      '<span class="dlyTime">'+time+'</span>'+
      '<button class="toggle dlyMeasOne" data-i="'+i+'">מדוד</button>'+
      '<span class="dlyDelta">'+add+'</span>'+
      '</div>';
  }).join('');
  box.querySelectorAll('.dlyAnchor').forEach(a=>a.addEventListener('click',function(){ dlyAnchor=+this.dataset.a; renderDlySpk(); }));
  box.querySelectorAll('.posName').forEach(inp=>inp.addEventListener('change',function(){ const i=+this.dataset.i; if(dlySpeakers[i]) dlySpeakers[i].name=this.value; }));
  box.querySelectorAll('.dlyMeasOne').forEach(b=>b.addEventListener('click',function(){
    const i=+this.dataset.i, btn=this;
    const status=document.getElementById('dlyStatus');dlyLastPathResult=null;dlyLastSpeakerResult=null;if(status)delete status.dataset.delayResult;
    pickSource(()=>runDelayCapture(btn,(res,silent)=>{
      if(res==null){ btn.textContent='נכשל'; setTimeout(()=>btn.textContent='מדוד',1500); return; }
      if(!res.reliable){ btn.textContent='לא יציב'; const st=document.getElementById('dlyStatus');if(st)st.textContent=delayFailureText(res,silent);setTimeout(()=>btn.textContent='מדוד',1800); return; }
      dlySpeakers[i].ms=res.ms;dlySpeakers[i].confidence=res.confidence;dlySpeakers[i].spreadMs=res.spreadMs;
      dlyLastSpeakerResult={index:i,result:res};renderSpeakerMeasurementStatus(i,res);
      renderDlySpk();
    },{maxDelayMs:delaySearchMs,mode:'speaker'}),3800);
  }));
}
function renderSpeakerMeasurementStatus(i,res){
  const st=document.getElementById('dlyStatus');if(!st||!res)return;
  const displayed=delayDisplayValue(res.ms,dlyDisplayUnit,dlyDistanceOffsetMs);
  const value=displayed?(displayed.unit==='m'?displayed.value.toFixed(2)+'m':displayed.value.toFixed(2)+'ms'):'נשמר · נדרש כיול להצגת מטרים';
  st.innerHTML='✓ '+escapeHtml((dlySpeakers[i]&&dlySpeakers[i].name)||dlyName(i))+' נשמר: <b>'+value+'</b> '+delayChecksHtml(res)+' · עכשיו מדוד את הרמקול הבא בלי להזיז את המיקרופון.';
  st.dataset.delayResult='speaker';
}
document.querySelectorAll('#dlyCountSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#dlyCountSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); setDlyCount(+this.dataset.n);
}));
renderDlySpk();
updateDlyUnitUi();

function computeDelay(ref, mic, sr, options){
  options=options||{};
  const L = Math.min(ref.length, mic.length);
  const maxDelayMs=Math.max(2,Math.min(100,Number(options.maxDelayMs)||50));
  const chunkSize=delayChunkSize(sr,maxDelayMs);
  const hopSize=chunkSize/2;
  const maxLag=Math.min(Math.floor(sr*maxDelayMs/1000),chunkSize/2-2);
  if(L < chunkSize) return null;

  const numChunks = Math.floor((L - chunkSize) / hopSize) + 1;
  if(numChunks < 1) return null;

  const avgCorr = new Float64Array(chunkSize);
  const xr = new Float64Array(chunkSize);
  const xi = new Float64Array(chunkSize);
  const yr = new Float64Array(chunkSize);
  const yi = new Float64Array(chunkSize);

  const win = new Float32Array(chunkSize);
  for(let i = 0; i < chunkSize; i++){
    win[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (chunkSize - 1)));
  }

  const chunkLags=[];
  let activeBinSum=0;
  let validChunks = 0;
  for(let c = 0; c < numChunks; c++){
    const offset = c * hopSize;
    let eRef = 0, eMic = 0;

    for(let i = 0; i < chunkSize; i++){
      const rVal = ref[offset + i] * win[i];
      const mVal = mic[offset + i] * win[i];
      xr[i] = rVal; xi[i] = 0;
      yr[i] = mVal; yi[i] = 0;
      eRef += rVal * rVal;
      eMic += mVal * mVal;
    }

    if(eRef < 1e-7 || eMic < 1e-7) continue;

    fft(xr, xi, false);
    fft(yr, yi, false);

    let crossMax=0;
    for(let k=1;k<chunkSize/2;k++){
      const f=k*sr/chunkSize;if(f<25||f>8000)continue;
      const cr=yr[k]*xr[k]+yi[k]*xi[k],ci=yi[k]*xr[k]-yr[k]*xi[k];
      crossMax=Math.max(crossMax,Math.hypot(cr,ci));
    }
    let activeBins=0;
    // GCC-PHAT with a useful acoustic band. Reject DC/subsonic content and
    // down-weight the noisy top octave; both otherwise create false cycle locks.
    for(let k = 0; k < chunkSize; k++){
      const signedK=k<=chunkSize/2?k:k-chunkSize;
      const f=Math.abs(signedK)*sr/chunkSize;
      const cr = yr[k] * xr[k] + yi[k] * xi[k];
      const ci = yi[k] * xr[k] - yr[k] * xi[k];
      const mag = Math.hypot(cr, ci) + 1e-9;
      if(k>0&&k<chunkSize/2&&f>=25&&f<=8000&&mag>=crossMax*.08)activeBins++;
      let w=0;
      if(f>=25&&f<=8000){
        const low=Math.min(1,(f-25)/35);
        const high=Math.min(1,(8000-f)/2000);
        w=Math.max(0,Math.min(low,high));
      }
      xr[k]=w*cr/mag;
      xi[k]=w*ci/mag;
    }
    fft(xr,xi,true);
    let localBest=-Infinity,localLag=0;
    for(let lag=-maxLag;lag<=maxLag;lag++){
      const idx=lag<0?chunkSize+lag:lag;
      const v=xr[idx];
      avgCorr[idx]+=v;
      if(v>localBest){localBest=v;localLag=lag;}
    }
    chunkLags.push(localLag);
    activeBinSum+=activeBins;
    validChunks++;
  }

  if(validChunks === 0) return null;

  for(let lag=-maxLag;lag<=maxLag;lag++){
    const idx=lag<0?chunkSize+lag:lag;
    avgCorr[idx]/=validChunks;
  }
  const peaks=[];
  for(let lag=-maxLag+1;lag<maxLag;lag++){
    const idx=lag<0?chunkSize+lag:lag;
    const prev=(lag-1)<0?chunkSize+lag-1:lag-1;
    const next=(lag+1)<0?chunkSize+lag+1:lag+1;
    const v=avgCorr[idx];
    if(v>=avgCorr[prev]&&v>avgCorr[next]) peaks.push({lag,v});
  }
  if(!peaks.length)return null;
  peaks.sort((a,b)=>b.v-a.v);
  const strongest=peaks[0];
  // Prefer the earliest plausible arrival among near-equal correlation peaks.
  // A late room reflection or one extra bass cycle must not beat the direct sound.
  const near=peaks.filter(p=>p.v>=strongest.v*.82).sort((a,b)=>Math.abs(a.lag)-Math.abs(b.lag));
  const chosen=near[0]||strongest;
  const idx=chosen.lag<0?chunkSize+chosen.lag:chosen.lag;
  const left=(chosen.lag-1)<0?chunkSize+chosen.lag-1:chosen.lag-1;
  const right=(chosen.lag+1)<0?chunkSize+chosen.lag+1:chosen.lag+1;
  const denom=avgCorr[left]-2*avgCorr[idx]+avgCorr[right];
  const frac=Math.abs(denom)>1e-12?.5*(avgCorr[left]-avgCorr[right])/denom:0;
  const lag=chosen.lag+Math.max(-.5,Math.min(.5,frac));
  const sorted=chunkLags.slice().sort((a,b)=>a-b);
  const median=sorted[Math.floor(sorted.length/2)];
  const consistent=chunkLags.filter(v=>Math.abs(v-median)<=Math.max(3,sr*.0005)).length/validChunks;
  const deviations=chunkLags.map(v=>Math.abs(v-median)/sr*1000).sort((a,b)=>a-b);
  const chunkSpreadMs=deviations[Math.min(deviations.length-1,Math.floor(deviations.length*.9))]||0;
  const rival=peaks.find(p=>Math.abs(p.lag-chosen.lag)>Math.max(4,sr*.001));
  const separation=rival?Math.max(0,Math.min(1,(chosen.v-rival.v)/(Math.abs(chosen.v)+1e-12))):1;
  const confidence=Math.max(0,Math.min(1,.65*consistent+.35*separation));
  const activeBins=activeBinSum/validChunks;
  const broadbandScore=Math.max(0,Math.min(1,(activeBins-6)/30));
  const finalConfidence=confidence*broadbandScore;
  const alternatives=peaks.filter(p=>p!==chosen&&p.v>=strongest.v*.65).slice(0,3).map(p=>p.lag/sr*1000);
  return {ms:lag/sr*1000,samples:lag,confidence:finalConfidence,reliable:finalConfidence>=.58&&consistent>=.55&&activeBins>=18,alternatives,maxDelayMs,activeBins,consistent,validChunks,chunkSpreadMs};
}

// Full-capture GCC-PHAT for non-stationary excitation (swept sine). A sweep is
// only a single tone inside any short window, so the per-chunk estimator above
// starves for broadband content and rejects it. Correlated across the entire
// capture, however, the sweep sweeps through the whole band and produces one of
// the sharpest cross-correlation peaks there is. We still run three overlapping
// wide windows for a real stability check that stays broadband on a sweep.
function computeSweepDelay(ref,mic,sr,options){
  options=options||{};
  const L=Math.min(ref.length,mic.length);
  const maxDelayMs=Math.max(2,Math.min(100,Number(options.maxDelayMs)||50));
  if(L<8192)return null;
  const maxFft=1<<19;
  const maxLag=Math.min(Math.floor(sr*maxDelayMs/1000),maxFft/2-2);
  if(maxLag<2)return null;
  // Keep enough zero padding for a linear (not circular) correlation at every
  // supported search range. Long 96 kHz captures are analysed as three wide
  // representative windows instead of silently overflowing the FFT buffers.
  const pad=Math.max(64,maxLag*2+2);
  const maxSeg=Math.max(8192,maxFft-pad);
  const mainSeg=Math.min(L,maxSeg);
  // Broad-band sweeps remain broadband in shorter windows, but a sub-only
  // sweep needs most of its duration to retain enough occupied bandwidth.
  const sideSeg=Math.min(mainSeg,Math.max(8192,Math.floor(L*.82)));
  const centerStart=Math.max(0,Math.floor((L-mainSeg)/2));
  const windows=L>maxSeg
    ? [[centerStart,centerStart+mainSeg],[0,mainSeg],[L-mainSeg,L]]
    : [[0,L],[0,sideSeg],[L-sideSeg,L]];
  const results=[];

  for(let wi=0;wi<windows.length;wi++){
    const ws=windows[wi][0],we=windows[wi][1],seg=we-ws;
    if(seg<4096){results.push(null);continue;}
    let N=1;while(N<seg+pad)N<<=1;
    if(N>maxFft){results.push(null);continue;}
    const xr=new Float64Array(N),xi=new Float64Array(N),yr=new Float64Array(N),yi=new Float64Array(N);
    // Light Tukey taper (10% each edge) so a sweep that does not start/stop
    // exactly at the capture boundary does not smear the spectrum.
    const taper=Math.max(1,Math.floor(seg*0.1));
    let eRef=0,eMic=0;
    for(let i=0;i<seg;i++){
      let w=1;
      if(i<taper)w=0.5*(1-Math.cos(Math.PI*i/taper));
      else if(i>=seg-taper)w=0.5*(1-Math.cos(Math.PI*(seg-1-i)/taper));
      const rv=ref[ws+i]*w,mv=mic[ws+i]*w;
      xr[i]=rv;yr[i]=mv;eRef+=rv*rv;eMic+=mv*mv;
    }
    if(eRef<1e-7||eMic<1e-7){results.push(null);continue;}
    fft(xr,xi,false);fft(yr,yi,false);
    let crossMax=0;
    for(let k=1;k<N/2;k++){
      const f=k*sr/N;if(f<25||f>16000)continue;
      const cr=yr[k]*xr[k]+yi[k]*xi[k],ci=yi[k]*xr[k]-yr[k]*xi[k];
      const m=Math.hypot(cr,ci);if(m>crossMax)crossMax=m;
    }
    let activeBins=0,activeLo=Infinity,activeHi=0;
    for(let k=0;k<N;k++){
      const signedK=k<=N/2?k:k-N,f=Math.abs(signedK)*sr/N;
      const cr=yr[k]*xr[k]+yi[k]*xi[k],ci=yi[k]*xr[k]-yr[k]*xi[k];
      const mag=Math.hypot(cr,ci)+1e-12;
      if(k>0&&k<N/2&&f>=25&&f<=16000&&mag>=crossMax*.05){activeBins++;activeLo=Math.min(activeLo,f);activeHi=Math.max(activeHi,f);}
      let w=0;
      if(f>=20&&f<=18000){
        const lo=Math.min(1,(f-20)/40),hi=Math.min(1,(18000-f)/3000);
        w=Math.max(0,Math.min(lo,hi));
      }
      xr[k]=w*cr/mag;xi[k]=w*ci/mag;
    }
    fft(xr,xi,true);
    let best=-Infinity,bestLag=0;
    for(let lag=-maxLag;lag<=maxLag;lag++){
      const idx=lag<0?N+lag:lag,v=xr[idx];
      if(v>best){best=v;bestLag=lag;}
    }
    const bandwidthHz=activeBins?Math.max(0,activeHi-activeLo):0;
    // A narrow-band sub sweep has a naturally wide correlation lobe. Do not
    // count the shoulders of that same lobe as rival arrivals.
    const resolutionMs=bandwidthHz>0?1000/bandwidthHz:Infinity;
    const guardMs=Math.min(12,Math.max(.6,resolutionMs*1.5));
    const guard=Math.max(4,Math.round(sr*guardMs/1000));
    let second=-Infinity;
    for(let lag=-maxLag;lag<=maxLag;lag++){
      if(Math.abs(lag-bestLag)<=guard)continue;
      const idx=lag<0?N+lag:lag;if(xr[idx]>second)second=xr[idx];
    }
    const li=(bestLag-1)<0?N+bestLag-1:bestLag-1;
    const cidx=bestLag<0?N+bestLag:bestLag;
    const ri=(bestLag+1)<0?N+bestLag+1:bestLag+1;
    const denom=xr[li]-2*xr[cidx]+xr[ri];
    const frac=Math.abs(denom)>1e-12?.5*(xr[li]-xr[ri])/denom:0;
    const lag=bestLag+Math.max(-.5,Math.min(.5,frac));
    const separation=best>0?Math.max(0,Math.min(1,(best-Math.max(0,second))/best)):0;
    const toleranceMs=Math.min(1,Math.max(.30,resolutionMs*.10));
    results.push({ms:lag/sr*1000,samples:lag,peak:best,separation,activeBins,bandwidthHz,resolutionMs,toleranceMs});
  }

  const full=results[0];
  if(!full)return null;
  const tol=full.toleranceMs;
  const checks=results.map(r=>({reliable:!!(r&&r.separation>=.30&&r.activeBins>=40&&r.bandwidthHz>=70&&Math.abs(r.ms-full.ms)<=Math.max(tol,r.toleranceMs))}));
  const validChecks=checks.filter(c=>c.reliable).length;
  const agreeMs=results.filter((r,i)=>checks[i].reliable).map(r=>r.ms);
  const spreadMs=agreeMs.length>1?Math.max.apply(null,agreeMs)-Math.min.apply(null,agreeMs):0;
  const reliable=!!(full.separation>=.40&&full.activeBins>=60&&full.bandwidthHz>=70&&validChecks>=2&&spreadMs<=tol);
  const confidence=Math.max(0,Math.min(1,full.separation*Math.min(1,full.activeBins/120)*Math.min(1,full.bandwidthHz/100)));
  return {
    ms:full.ms,samples:full.samples,confidence,reliable,stable:reliable,
    checks,validChecks,spreadMs,fullMs:full.ms,alternatives:[],maxDelayMs,
    activeBins:full.activeBins,bandwidthHz:full.bandwidthHz,resolutionMs:full.resolutionMs,method:'sweep'
  };
}

// One capture is divided into three independent time windows. A result is only
// accepted when at least two windows agree within 0.20ms and the full capture
// points to the same arrival. This prevents a reflection or one bass cycle from
// silently becoming the system delay. Non-stationary excitation (a sweep) is
// routed to computeSweepDelay, and any signal type gets a full-capture rescue
// pass when the per-chunk path cannot lock.
function computeStableDelay(ref,mic,sr,options){
  options=options||{};
  const L=Math.min(ref.length,mic.length),maxDelayMs=Math.max(2,Math.min(100,Number(options.maxDelayMs)||50));
  const signalType=options.signalType||'auto';

  // A swept sine goes straight to the full-capture correlator.
  let sweepResult=null;
  if(signalType==='sweep'){
    sweepResult=computeSweepDelay(ref,mic,sr,{maxDelayMs});
    if(sweepResult&&sweepResult.reliable)return sweepResult;
  }

  const full=computeDelay(ref,mic,sr,{maxDelayMs});
  const checks=[];
  const third=Math.floor(L/3);
  for(let i=0;i<3;i++){
    const start=i*third,end=i===2?L:(i+1)*third;
    checks.push(computeDelay(ref.subarray(start,end),mic.subarray(start,end),sr,{maxDelayMs}));
  }
  const valid=checks.filter(r=>r&&r.reliable).sort((a,b)=>a.ms-b.ms);

  let chunkResult;
  if(!valid.length){
    chunkResult=full?Object.assign({},full,{reliable:false,stable:false,checks,validChecks:0,spreadMs:Infinity}):null;
  }else{
    const medianMs=valid[Math.floor(valid.length/2)].ms;
    const spreadMs=valid.length>1?valid[valid.length-1].ms-valid[0].ms:Infinity;
    const fullAgrees=!!(full&&full.reliable&&Math.abs(full.ms-medianMs)<=.25);
    const stable=valid.length>=2&&spreadMs<=.20&&fullAgrees;
    const base=valid.reduce((best,r)=>Math.abs(r.ms-medianMs)<Math.abs(best.ms-medianMs)?r:best,valid[0]);
    const avgConfidence=valid.reduce((sum,r)=>sum+r.confidence,0)/valid.length;
    const confidence=Math.max(0,Math.min(1,avgConfidence*(stable?1:.55)));
    const alternatives=Array.from(new Set(valid.flatMap(r=>r.alternatives||[]).map(v=>Math.round(v*10)/10))).filter(v=>Math.abs(v-medianMs)>.5).slice(0,3);
    chunkResult=Object.assign({},base,{
      ms:medianMs,samples:medianMs*sr/1000,confidence,reliable:stable,stable,
      checks,validChecks:valid.length,spreadMs,fullMs:full?full.ms:null,alternatives,maxDelayMs
    });
  }

  if(chunkResult&&chunkResult.reliable)return chunkResult;

  // Do not apply the sweep correlator to arbitrary music or an unknown external
  // source: a plausible-looking full-capture peak is not proof of a sweep.
  // For an explicitly selected sweep, preserve its diagnostics even on failure.
  if(signalType==='sweep'&&sweepResult)return sweepResult;
  return chunkResult;
}

function measureBusy(){
  return measState==='measuring' || areaState==='measuring' || tfState==='measuring'
      || dlyState==='measuring' || phMeasuring || tfWorkflowVerifying || rt60State!=='idle';
}
function unfreezeForMeasure(){
  if(!frozen) return;
  frozen=false; snapCurve=null;
  const fz=document.getElementById('freezeBtn'); if(fz){ fz.classList.remove('on'); fz.textContent='הקפא'; }
}
function measurePosition(){
  if(!running){ alert('קודם הפעל את המיקרופון.'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  unfreezeForMeasure();
  const srcData = floatData;
  measAccum=new Float64Array(srcData.length); measFrames=0; measState='measuring';
  updateEqUI();
  setTimeout(()=>{
    const bins=measAccum.length, nyq=audioCtx.sampleRate/2, R6=Math.pow(2,1/6);
    const db=GEQ.map(fc=>10*Math.log10(binOverlapLinearPower(measAccum,fc/R6,fc*R6,nyq,measFrames)+1e-12));
    eqPositions.push({name:'מיקום '+(eqPositions.length+1), db}); measState='idle';
    computeAndShow(); updateEqUI(); renderEqList();
  },5000);
}
function renderEqList(){
  const box=document.getElementById('eqPosList'); if(!box) return;
  if(!eqPositions.length){ box.innerHTML=''; return; }
  box.innerHTML=eqPositions.map((p,i)=>
    '<div class="calRow"><input class="posName" data-i="'+i+'" value="'+escapeHtml(p.name||('מיקום '+(i+1)))+'">'+
    '<span class="del" data-del="'+i+'" title="מחק מיקום">🗑</span></div>').join('');
  box.querySelectorAll('.posName').forEach(inp=>inp.addEventListener('change',function(){
    const i=+this.dataset.i; if(eqPositions[i]) eqPositions[i].name=this.value; }));
  box.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',function(){
    const i=+this.dataset.del; eqPositions.splice(i,1);
    if(eqPositions.length) computeAndShow(); else { eqMarks=null; eqCurveData=null; document.getElementById('eqList').innerHTML=''; hideGeqDock(); }
    updateEqUI(); renderEqList();
  }));
}
function avgPositions(){
  if(!eqPositions.length) return null;
  const out=new Float32Array(GEQ.length);
  for(let k=0;k<GEQ.length;k++){ let p=0; for(const pos of eqPositions) p+=db2lin(pos.db[k]); out[k]=10*Math.log10(p/eqPositions.length+1e-12); }
  return out;
}
function bandDbFromBins(bd,fLo,fHi,nyq,bins){
  return binOverlapPowerDb(bd,fLo,fHi,nyq);
}
function computeAndShow(noModal){
  if(!eqPositions.length){ alert('מדוד לפחות מיקום אחד.'); return; }
  const band=avgPositions();
  if(!band) return;
  const resp=GEQ.map((fc,k)=> band[k] - (micCal?micCalAt(fc):0));
  {
    const inBand=resp.filter((v,k)=>GEQ[k]>=63&&GEQ[k]<=8000);
    if(Math.max(...inBand) < -62){
      const box=document.getElementById('eqList');
      if(box) box.innerHTML='<div class="sub" style="color:var(--warn)">⚠ לא זוהה אות מדידה.<br>'+
        '<span style="color:var(--dim)">ודא שרעש ורוד מנוגן דרך המערכת ושגיין המיקרופון פתוח, ומדוד שוב.</span></div>';
      hideGeqDock();
      lastEqCorr=null; eqMarks=null; eqCurveData=null;
      return;
    }
  }
  const rel=relByLevel(resp);
  const corr=buildCorr(resp, rel);
  eqCurveData={freqs:GEQ.slice(), corr:corr.slice()};
  showGeqDock('תיקון EQ · חד־ערוצי');
  drawGEQ(document.getElementById('eqCurveCanvas'), GEQ, corr);
  lastEqCorr=corr;
  renderEqResult();
  if(!noModal) showModal(eqPanel);
}
// Fit six real parametric bell filters simultaneously. This is deliberately not
// a peak-picker or a conversion of the 31 graphic-EQ sliders.
function paramFromCorr(corr){
  const samples=GEQ.map((f,k)=>({f,target:corr[k]})).filter(s=>s.target!=null&&Number.isFinite(s.target)&&s.f>=eqMinFreq&&s.f<=eqMaxFreq);
  if(!samples.length)return [];
  const centers=GEQ.filter(f=>f>=eqMinFreq&&f<=eqMaxFreq),qs=[0.5,0.7,1,1.4,2,2.8,4,5.6,8,10];
  const bell=(f,fc,q)=>1/(1+Math.pow(2*q*Math.sinh(Math.LN2*Math.log2(f/fc)),2));
  const shape=(fc,q)=>samples.map(s=>bell(s.f,fc,q));
  const gainFor=(residual,sh,fc)=>{
    let dot=0,pow=0;for(let i=0;i<sh.length;i++){dot+=residual[i]*sh[i];pow+=sh[i]*sh[i];}
    let g=pow>1e-9?dot/pow:0;const lo=fc<160?-6:-4,hi=cutOnly?0:(fc>500?1.5:3);
    return Math.max(lo,Math.min(hi,g));
  };
  const error=(residual,sh,g)=>{let e=0;for(let i=0;i<sh.length;i++){const v=residual[i]-g*sh[i];e+=v*v;}return e;};
  const filters=[],prediction=new Array(samples.length).fill(0);
  for(let band=0;band<6;band++){
    const residual=samples.map((s,i)=>s.target-prediction[i]);let base=residual.reduce((n,v)=>n+v*v,0),best=null;
    for(const fc of centers)for(const q of qs){
      const sh=shape(fc,q),g=gainFor(residual,sh,fc);if(Math.abs(g)<0.35)continue;
      const e=error(residual,sh,g);if(!best||e<best.e)best={f:fc,q,gain:g,sh,e};
    }
    if(!best||base-best.e<0.35)break;
    filters.push(best);for(let i=0;i<prediction.length;i++)prediction[i]+=best.gain*best.sh[i];
  }
  // Coordinate-descent refinement lets every band move after the other bands exist.
  for(let pass=0;pass<3;pass++)for(let bi=0;bi<filters.length;bi++){
    const old=filters[bi],residual=samples.map((s,i)=>s.target-(prediction[i]-old.gain*old.sh[i]));let best=old,bestE=Infinity;
    for(const fc of centers)for(const q of qs){
      const sh=shape(fc,q),g=gainFor(residual,sh,fc),e=error(residual,sh,g);
      if(e<bestE){bestE=e;best={f:fc,q,gain:g,sh,e};}
    }
    for(let i=0;i<prediction.length;i++)prediction[i]+=best.gain*best.sh[i]-old.gain*old.sh[i];filters[bi]=best;
  }
  return filters.filter(s=>Math.abs(s.gain)>=0.5).map(s=>({f:s.f,gain:s.gain,q:s.q,type:s.gain<0?'cut':'boost'})).sort((a,b)=>a.f-b.f).slice(0,6);
}

function renderEqResult(){
  if(!lastEqCorr){ return; }
  const head='<div class="sub" style="margin-bottom:6px; color:var(--text); font-weight:600;">יעד '+(targetMode==='house'?'House':'שטוח')+
    (micCal?' · כיול פעיל':' · ללא כיול')+' · '+eqPositions.length+' מיקומים:</div>';
  const box=document.getElementById('eqList');
  box.innerHTML = head + (eqMode==='graphic' ? corrGridHtml(lastEqCorr, null) : corrParamHtml(lastEqCorr));
}

const rtPanel=document.getElementById('rtPanel'), rtStatus=document.getElementById('rtStatus');
safeOn('rtClose', 'click',closeModals);
safeOn('rtRange', 'input',e=>{
  rtRange=parseFloat(e.target.value);
  document.getElementById('rtRangeVal').textContent=rtRange+'dB';
  if(rt60Samples.length) analyzeRT60();
});
safeOn('rtLevel', 'input',e=>{
  rtLevel=parseInt(e.target.value,10);
  document.getElementById('rtLevelVal').textContent=rtLevel+'dB';
});
safeOn('rtRunBtn', 'click',startRT60);
safeOn('rtBtn', 'click',()=>{
  if(!running||!audioCtx){ alert('קודם הפעל את המיקרופון.'); return; }
  showModal(rtPanel);
  { const c=document.getElementById('rtCanvas'); if(c) c.style.display='none'; }
  rtStatus.innerHTML='כוונן עוצמה, ואז לחץ "התחל מדידה".';
});
function startRT60(){
  if(!running||!audioCtx){ alert('קודם הפעל את המיקרופון.'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  unfreezeForMeasure();
  rt60State='arming';
  rtStatus.innerHTML='מכין… משמיע רעש ורוד';
  const prevGenOn = genOn;
  const restoreType=genType; genType='pink';
  if(!genOn){ genStart(); }
  const boost=rtLevel;
  if(genGain) genGain.gain.setTargetAtTime(Math.pow(10,boost/20),audioCtx.currentTime,0.1);
  const prevSmooth=analyser.smoothingTimeConstant; analyser.smoothingTimeConstant=0;

  rt60ArmTimer=setTimeout(()=>{
    rt60ArmTimer=null;if(rt60State!=='arming')return;
    rtStatus.innerHTML='מודד דעיכה…';
    rt60Samples=[]; rt60State='capture';
    const nyq=audioCtx.sampleRate/2;
    const bandEdges=RT_BANDS.map(fc=>{ const bins=floatData.length;
      let lo=Math.floor((fc/1.4142)/nyq*bins), hi=Math.ceil((fc*1.4142)/nyq*bins);
      return [Math.max(0,lo),Math.min(bins-1,hi)]; });
    if(rt60Timer) clearInterval(rt60Timer);
    rt60Timer=setInterval(()=>{
      if(rt60State!=='capture' || !analyser) return;
      analyser.getFloatTimeDomainData(timeData);
      let s2=0, N=Math.min(2048,timeData.length);
      for(let i=timeData.length-N;i<timeData.length;i++){ const v=timeData[i]; s2+=v*v; }
      analyser.getFloatFrequencyData(floatData);
      const bands=bandEdges.map(([lo,hi])=>{ let p=0; for(let i=lo;i<=hi;i++) p+=db2lin(floatData[i]); return 10*Math.log10(p+1e-12); });
      rt60Samples.push({t:performance.now(), db:20*Math.log10(Math.sqrt(s2/N)+1e-9), bands});
    },10);
    rt60CutTimer=setTimeout(()=>{
      rt60CutTimer=null;if(rt60State!=='capture')return;
      const t=audioCtx.currentTime;
      if(genGain){ try{ genGain.gain.cancelScheduledValues(t);
        genGain.gain.setValueAtTime(genGain.gain.value,t);
        genGain.gain.linearRampToValueAtTime(0,t+0.005);}catch(_){} }
      rt60CutT=performance.now();
      rt60FinishTimer=setTimeout(()=>{
        rt60FinishTimer=null;if(rt60State!=='capture')return;
        rt60State='idle'; 
        if(rt60Timer){ clearInterval(rt60Timer); rt60Timer=null; }
        analyser.smoothingTimeConstant=prevSmooth;
        if(!prevGenOn) genStop(); 
        genType=restoreType;
        analyzeRT60();
      },2500);
    },400);
  },1200);
}

const RT_BANDS=[125,250,500,1000,2000,4000];
function analyzeDecay(series, cutT, needRange){
  const pre=series.filter(x=>x.t<cutT);
  const steady = pre.length? pre.reduce((a,x)=>a+x.db,0)/pre.length : Math.max(...series.map(x=>x.db));
  const post=series.filter(x=>x.t>=cutT).map(x=>({t:(x.t-cutT)/1000, db:x.db}));
  if(post.length<10) return null;
  const tail=post.slice(-Math.max(5,Math.floor(post.length*0.25)));
  const noise=tail.reduce((a,x)=>a+x.db,0)/tail.length;
  const hi=steady-5, lo=noise+5;
  const reg=post.filter(x=>x.db<=hi && x.db>=lo);
  if(reg.length<5 || (hi-lo)<Math.min(8,needRange)) return {rt60:null, span:hi-lo, steady, noise, post};
  let n=reg.length, st=0,sd=0,std=0,stt=0;
  reg.forEach(p=>{ st+=p.t; sd+=p.db; std+=p.t*p.db; stt+=p.t*p.t; });
  const slope=(n*std - st*sd)/(n*stt - st*st);
  const intercept=(sd - slope*st)/n;
  const rt60=-60/slope;
  return { rt60:(slope<0 && rt60>0.05 && rt60<10)?rt60:null, span:hi-lo, steady, noise, post, slope, intercept };
}
function analyzeRT60(){
  const s=rt60Samples;
  if(s.length<20){ rtStatus.innerHTML='מדידה נכשלה — נדגמו רק '+s.length+' דגימות.<br><span style="font-size:11px;color:var(--dim)">ודא שהמיקרופון פעיל ונסה שוב.</span>'; return; }
  const bb=analyzeDecay(s.map(x=>({t:x.t,db:x.db})), rt60CutT, rtRange);
  if(!bb || bb.post.length<10){ rtStatus.innerHTML='מדידה נכשלה — לא נלכדה דעיכה.'; return; }
  let bandsHtml='';
  if(s[0].bands){
    bandsHtml='<div class="tfGrid" style="margin-top:8px">';
    RT_BANDS.forEach((fc,bi)=>{
      const series=s.map(x=>({t:x.t, db:x.bands[bi]}));
      const r=analyzeDecay(series, rt60CutT, rtRange);
      const fStr=fc>=1000?(fc/1000)+'k':fc+'';
      const val=(r&&r.rt60)?r.rt60.toFixed(2)+'ש\'':'—';
      const cls=(r&&r.rt60)?(r.rt60>0.8?'cut':(r.rt60<0.3?'off':'boost')):'off';
      bandsHtml+='<div class="tfItem '+cls+'"><span class="f">'+fStr+'Hz</span><span class="g">'+val+'</span></div>';
    });
    bandsHtml+='</div>';
  }
  if(bb.rt60){
    const approx=bb.span<rtRange;
    rtStatus.innerHTML='RT60 ≈ <b>'+bb.rt60.toFixed(2)+' ש\'</b> <span style="font-size:11px;color:var(--dim)">(רחב־פס · טווח '+bb.span.toFixed(0)+'dB)</span>'+
      (approx?'<br><span style="font-size:10px;color:var(--warn)">משוער — טווח דעיכה קטן</span>':'')+bandsHtml;
    drawRTPlot(bb.post, bb.steady, bb.slope, bb.intercept);
  } else {
    rtStatus.innerHTML='אין דעיכה רחב־פס למדוד ('+(bb.span>0?bb.span.toFixed(0):'0')+'dB).'+
      '<br><span style="font-size:11px;color:var(--dim)">רמת אות: '+bb.steady.toFixed(0)+'dB · רעש רקע: '+bb.noise.toFixed(0)+'dB.<br>'+
      (bb.steady-bb.noise<15?'העלה עוצמת PA (האות קרוב מדי לרעש הרקע).':'הורד "טווח דעיכה נדרש".')+'</span>'+bandsHtml;
    drawRTPlot(bb.post, bb.steady, null, 0);
  }
}
function drawRTPlot(post, steady, slope, intercept){
  const c=document.getElementById('rtCanvas'); if(!c) return;
  c.style.display='block';
  const x=c.getContext('2d');
  const W=c.width, H=c.height; x.clearRect(0,0,W,H);
  const tMax=Math.max(0.5, post.length?post[post.length-1].t:1);
  const dbMin=steady-65, dbMax=steady+3;
  const X=t=>t/tMax*W, Y=db=>H-(db-dbMin)/(dbMax-dbMin)*H;
  x.strokeStyle=sunMode?'#cbd5e1':'#2b3646'; x.fillStyle=sunMode?'#475569':'#8b97a5'; x.font='9px monospace';
  for(let d=0;d>=-60;d-=10){ const yy=Y(steady+d); x.globalAlpha=.5;
    x.beginPath();x.moveTo(0,yy);x.lineTo(W,yy);x.stroke(); x.globalAlpha=1; x.fillText(d+'dB',2,yy-2); }
  x.strokeStyle='#2f9bff'; x.lineWidth=1.5; x.beginPath();
  post.forEach((p,i)=>{ i?x.lineTo(X(p.t),Y(p.db)):x.moveTo(X(p.t),Y(p.db)); }); x.stroke();
  if(slope!=null){
    x.strokeStyle='#50e68c'; x.lineWidth=2; x.setLineDash([5,3]); x.beginPath();
    x.moveTo(X(0),Y(intercept)); x.lineTo(X(tMax),Y(intercept+slope*tMax)); x.stroke(); x.setLineDash([]);
  }
}
function setRtaResolution(value){
  const allowed=[3,6,12,24];
  const requested=parseInt(value,10);
  const bpo=allowed.reduce((best,n)=>Math.abs(n-requested)<Math.abs(best-requested)?n:best,6);
  const slider=document.getElementById('res');if(slider)slider.value=String(bpo);
  document.getElementById('resVal').textContent='1/'+bpo+' אוקטבה';
  buildBands(bpo);
  prefSet('rta_res', bpo);
  v3UpdateStatus();
  const ioSelect=document.getElementById('v52ResSelect');if(ioSelect)ioSelect.value=String(bpo);
  document.querySelectorAll('#v3ResMenu button').forEach(btn=>btn.classList.toggle('on',parseInt(btn.dataset.bpo,10)===bpo));
  return bpo;
}
safeOn('res', 'input',e=>{
  setRtaResolution(e.target.value);
});
safeOn('v3ResChip','click',e=>{
  e.stopPropagation();
  const menu=document.getElementById('v3ResMenu');if(!menu)return;
  const open=!menu.classList.contains('open');menu.classList.toggle('open',open);e.currentTarget.setAttribute('aria-expanded',open?'true':'false');
  menu.querySelectorAll('button').forEach(btn=>btn.classList.toggle('on',parseInt(btn.dataset.bpo,10)===curBpo));
});
document.querySelectorAll('#v3ResMenu button').forEach(btn=>btn.addEventListener('click',e=>{
  e.stopPropagation();setRtaResolution(btn.dataset.bpo);
  const menu=document.getElementById('v3ResMenu');if(menu)menu.classList.remove('open');
  const chip=document.getElementById('v3ResChip');if(chip)chip.setAttribute('aria-expanded','false');
  v3Toast('רזולוציית RTA: 1/'+curBpo+' אוקטבה');
}));
document.addEventListener('click',()=>{
  const menu=document.getElementById('v3ResMenu');if(menu)menu.classList.remove('open');
  const chip=document.getElementById('v3ResChip');if(chip)chip.setAttribute('aria-expanded','false');
});
function setFft(n){
  const supported=(window.GAL&&window.GAL.config&&window.GAL.config.supportedFft)||[8192,16384,32768];
  n=parseInt(n,10);
  fftSize=supported.includes(n)?n:16384;
  const hadAlignment=!!(phaseSub||phaseTop);
  configureTfFft(fftSize);
  if(hadAlignment)clearSubTopSnapshots('רזולוציית FFT השתנתה — מדוד שוב סאב וטופ.');
  if(tfDelayReady)syncTfWorkflowUi('<b>רזולוציית FFT השתנתה:</b> בצע שוב את אימות TF','warn');
  setTimeout(v3UpdateStatus,0);
  if(analyser){
    analyser.fftSize=fftSize; analyserRef.fftSize=fftSize;
    floatData=new Float32Array(analyser.frequencyBinCount);
    floatDataRef=new Float32Array(analyserRef.frequencyBinCount);
    timeData=new Float32Array(analyser.fftSize);
    timeDataRef=new Float32Array(analyserRef.fftSize);
    _pfx=null; _pfxRef=null; avgBuf.fill(NaN); _lastRtaSmoothTime=0;
  }
  setRtaResolution(curBpo);
}
document.querySelectorAll('#fftSeg button').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#fftSeg button').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); setFft(parseInt(this.dataset.n,10)); prefSet('rta_fft', this.dataset.n);
}));
safeOn('mRta', 'click',()=>{setMode('rta'); if(typeof v5SetTab==='function')v5SetTab('analysis');});
safeOn('mSpec', 'click',()=>{setMode('spec'); if(typeof v5SetTab==='function')v5SetTab('analysis');});
safeOn('tfOverlayHdr', 'click',()=>setTfOverlay(!tfOverlay));
function setAlign(on){
  alignOn=on;
  const bar=document.getElementById('alignBar'); if(bar) bar.classList.toggle('show',on);
  const stage=document.getElementById('stage');
  const b=document.getElementById('alignBtn'); if(b) b.classList.toggle('on',on);
  if(on) closeModals();
  // דחיפת הגרף: הקנבס מתכווץ לפי גובה הסרגל
  if(stage){
    const h = (on && bar) ? bar.offsetHeight : 0;   // offsetHeight מכריח חישוב layout
    stage.style.setProperty('--bar-h', h+'px');
    stage.classList.toggle('bar-open', on);
  }
  if(typeof resize==='function') resize();
}
safeOn('alignBtn','click',()=>setAlign(!alignOn));
safeOn('alignClose','click',()=>setAlign(false));
safeOn('startBtn', 'click',()=>start());
safeOn('stopBtn', 'click',resetSession);
function resetSession(){
  if(audioCtx && audioCtx.state==='suspended') audioCtx.resume();
  resetTfAutoDelay();
  const tr = stream && stream.getAudioTracks && stream.getAudioTracks()[0];
  if(running && (!tr || tr.readyState==='ended')){ stop(); start(); return; }
  peaks.fill(0); avgBuf.fill(0); snapCurve=null; frozen=false;
  abA=null; abB=null; abView='off';
  { const a=document.getElementById('abCapA'); if(a){ a.classList.remove('on'); a.textContent='לכוד לפני (A)'; } }
  { const b=document.getElementById('abCapB'); if(b){ b.classList.remove('on'); b.textContent='לכוד אחרי (B)'; } }
  refCurve=null;
  { const rc=document.getElementById('refCurveBtn'); if(rc){ rc.classList.remove('on'); rc.textContent='שמור כ״לפני״'; } }
  const fz=document.getElementById('freezeBtn'); fz.classList.remove('on'); fz.textContent='הקפא';
  eqPositions=[]; eqMarks=null; eqCurveData=null; lastEqCorr=null;
  { const pl=document.getElementById('eqPosList'); if(pl) pl.innerHTML=''; const el=document.getElementById('eqList'); if(el) el.innerHTML=''; }
  document.getElementById('eqList').innerHTML=''; hideGeqDock();
  updateEqUI();
  areas=[]; renderAreaList();
  document.getElementById('areaEqCanvas').style.display='none';
  document.getElementById('areaEqList').innerHTML='';
  tfResult=null; tfTraces=[]; renderTfTraceLegend(); document.getElementById('tfGeqList').innerHTML='';
  document.getElementById('tfCanvas').style.display='none';
  resetDelay();
  fbTrack.clear(); fbPanel.innerHTML='';
  leqSumP=0; leqN=0; splMax=-120; lvlPeak=-120;
  targetMode='flat'; document.querySelectorAll('.tgtSeg button').forEach(b=>b.classList.toggle('on', b.dataset.t==='flat'));
  weightMode='Z'; const wb=document.getElementById('wgtBtn'); wb.textContent='dBZ'; wb.classList.remove('on'); document.getElementById('wLbl').textContent='Z';
  if(viewMin!==FMIN||viewMax!==FMAX){ viewMin=FMIN; viewMax=FMAX; buildBands(curBpo); document.getElementById('zoomBtn').style.display='none'; }
  if(genOn) genStop();
  closeModals();
}

function setMode(m){
  mode=m;
  document.getElementById('mRta').classList.toggle('on',m==='rta');
  document.getElementById('mSpec').classList.toggle('on',m==='spec');
  document.getElementById('v53AnalysisToggle')?.classList.toggle('on',m==='rta');
  document.getElementById('v54WaterfallToggle')?.classList.toggle('on',m==='spec');
  if(specCtx){
    specCtx.fillStyle=sunMode ? '#f8fafc' : '#0d1117';
    specCtx.fillRect(0,0,specCanvas.width,specCanvas.height);
  }
}

function buildWeighting(nyquist,bins){
  weightA=new Float32Array(bins); weightC=new Float32Array(bins);
  for(let i=0;i<bins;i++){
    const f=i*nyquist/bins, f2=f*f;
    const ra=(12194**2*f2*f2)/((f2+20.6**2)*Math.sqrt((f2+107.7**2)*(f2+737.9**2))*(f2+12194**2));
    weightA[i]= f>0 ? 20*Math.log10(ra)+2.00 : -120;
    const rc=(12194**2*f2)/((f2+20.6**2)*(f2+12194**2));
    weightC[i]= f>0 ? 20*Math.log10(rc)+0.06 : -120;
  }
}

async function start(deviceId){
  errBox.style.display='none';
  // Compensation is valid only for the current physical routing.
  resetTfAutoDelay();
  resetDistanceCalibration();
  try{
    if(deviceId===undefined)deviceId=activeInId;
    const audio = {
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
      channelCount: { ideal: 2 }
    };
    if(deviceId && typeof deviceId === 'string') audio.deviceId = { exact: deviceId };
    activeInId = deviceId || '';
    
    stream = await navigator.mediaDevices.getUserMedia({ audio });
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    
    if(outSinkId && typeof audioCtx.setSinkId === 'function'){ 
      try{ await audioCtx.setSinkId(outSinkId); }catch(_){} 
    }
    if(audioCtx.state === 'suspended') await audioCtx.resume();
    try {
      await audioCtx.audioWorklet.addModule('recorder-worklet.js');
      workletReady=true;
    } catch(err) {
      workletReady=false;
      console.warn('AudioWorklet failed to load.', err);
    }

    source = audioCtx.createMediaStreamSource(stream);
    source.channelCount = 2;
    source.channelCountMode = 'explicit';

    const track = stream.getAudioTracks()[0];
    track.addEventListener('ended',()=>{
      if(!running) return;
      errBox.style.display='block';
      errBox.textContent='מקור הקלט נותק. חבר מחדש ולחץ "אפס סשן".';
    });
    const settings = track.getSettings ? track.getSettings() : {};
    chReceived = settings.channelCount || source.channelCount || 1;
    const isSafari=/^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);
    const ci = document.getElementById('chCount');
    if(ci){
      if(chReceived>=2){ ci.textContent='ערוצים: '+chReceived+' ✓ סטריאו'; ci.style.color='#39d98a'; }
      else { ci.innerHTML='ערוצים: 1 ⚠ מונו — אין ערוץ 2'+(!isSafari?' · לערוץ 2 השתמש ב-Safari':''); ci.style.color='var(--hot)'; }
    }

    analyser = audioCtx.createAnalyser();
    analyser.fftSize = fftSize;
    analyser.smoothingTimeConstant = 0;
    analyser.minDecibels = -100; 
    analyser.maxDecibels = -10;

    analyserRef = audioCtx.createAnalyser();
    analyserRef.fftSize = fftSize; 
    analyserRef.smoothingTimeConstant = 0;
    analyserRef.minDecibels = -100; 
    analyserRef.maxDecibels = -10;

    analyserMeter = audioCtx.createAnalyser();
    analyserMeter.fftSize = 2048;

    const splitter = audioCtx.createChannelSplitter(2);
    source.connect(splitter);

    splitter.connect(analyser, measChannel);
    splitter.connect(analyserRef, refChannel);
    source.connect(analyserMeter);

    floatData = new Float32Array(analyser.frequencyBinCount);
    floatDataRef = new Float32Array(analyserRef.frequencyBinCount);
    timeData = new Float32Array(analyser.fftSize);
    timeDataRef = new Float32Array(analyserRef.fftSize);
    timeDataMeter = new Float32Array(2048);
    
    buildWeighting(audioCtx.sampleRate / 2, analyser.frequencyBinCount);
    resize();
    peaks.fill(0); fbTrack.clear(); fbPanel.innerHTML = ''; lvlPeak = -120;
    leqSumP = 0; leqN = 0; splMax = -120;
    smoothedDbfs = -120;
    running = true; idle.style.display = 'none'; dot.classList.add('live'); v3UpdateStatus();
    meterEl.style.display = 'flex'; document.getElementById('stats').style.display = 'flex';
    document.getElementById('stopBtn').style.display = '';
    populateInputs();
    draw();
  } catch(e) {
    errBox.style.display = 'block';
    errBox.textContent = 'לא ניתן לגשת למיקרופון: ' + (e.message || e.name) + '. יש לאשר הרשאה ולהריץ מעל HTTPS.';
  }
}

let userPickedIn=false, userPickedOut=false;
async function populateInputs(){
  try{
    const devs=await navigator.mediaDevices.enumerateDevices();
    const ins=devs.filter(d=>d.kind==='audioinput');
    const sel=document.getElementById('inSel');
    sel.innerHTML='';
    { const o=document.createElement('option'); o.value=''; o.textContent='ברירת מחדל של המערכת'; sel.appendChild(o); }
    ins.forEach((d,i)=>{
      if(d.deviceId==='default'||d.deviceId==='') return;
      const o=document.createElement('option');
      o.value=d.deviceId; o.textContent=d.label||('מיקרופון '+(i+1));
      sel.appendChild(o);
    });
    sel.value = userPickedIn ? (activeInId||'') : '';

    const outs=devs.filter(d=>d.kind==='audiooutput');
    const osel=document.getElementById('outSel');
    osel.innerHTML='';
    { const o=document.createElement('option'); o.value=''; o.textContent='ברירת מחדל של המערכת'; osel.appendChild(o); }
    outs.forEach((d,i)=>{
      if(d.deviceId==='default'||d.deviceId==='') return;
      const o=document.createElement('option');
      o.value=d.deviceId; o.textContent=d.label||('פלט '+(i+1));
      osel.appendChild(o);
    });
    osel.value = userPickedOut ? (outSinkId||'') : '';
  }catch(e){}
}
let outSinkId=null;
async function applyOutput(deviceId){
  outSinkId=deviceId;
  try{
    if(audioCtx && typeof audioCtx.setSinkId==='function'){ await audioCtx.setSinkId(deviceId||''); return true; }
  }catch(e){}
  return false;
}
safeOn('outSel', 'change',async e=>{
  userPickedOut = e.target.value!=='';
  const ok=await applyOutput(e.target.value);
  if(!ok) alert('הדפדפן לא תומך בבחירת יציאת פלט. הגדר את הפלט ב־macOS: הגדרות → סאונד → פלט.');
});

async function switchInput(deviceId){
  if(!running) return;
  if(raf) cancelAnimationFrame(raf);
  if(stream) stream.getTracks().forEach(t=>t.stop());
  if(audioCtx) await audioCtx.close();
  await start(deviceId);
}

function stop(){
  running=false; if(raf) cancelAnimationFrame(raf);
  resetTfAutoDelay();
  resetDistanceCalibration();
  if(rt60Timer){ clearInterval(rt60Timer); rt60Timer=null; }
  if(rt60ArmTimer){clearTimeout(rt60ArmTimer);rt60ArmTimer=null;}if(rt60CutTimer){clearTimeout(rt60CutTimer);rt60CutTimer=null;}if(rt60FinishTimer){clearTimeout(rt60FinishTimer);rt60FinishTimer=null;}
  rt60State='idle'; measState='idle'; areaState='idle'; dlyState='idle';
  analyserRef=null; floatDataRef=null; tfState='idle'; eqCurveData=null;
  genSrc=null; genOsc=null; genGain=null; genOn=false;
  const gb=document.getElementById('genOnBtn'); if(gb){gb.classList.remove('on');gb.textContent='▶ הפעל אות';}
  if(stream) stream.getTracks().forEach(t=>t.stop());
  if(audioCtx) audioCtx.close();
  dot.classList.remove('live'); idle.style.display='flex';
  document.getElementById('stopBtn').style.display='none';
  meterEl.style.display='none'; document.getElementById('stats').style.display='none';
  peakHzEl.textContent='—'; fbPanel.innerHTML='';
  ctx.clearRect(0,0,cv.clientWidth,cv.clientHeight);
}

function norm(db){ return Math.max(0,Math.min(1,(db-floorDb)/(ceilDb-floorDb))); }
function binOverlapPowerDb(data,fLo,fHi,nyquist){
  const bins=data.length, binHz=nyquist/bins;
  const lo=Math.max(0,fLo), hi=Math.min(nyquist,fHi);
  if(!(hi>lo)) return -120;
  const first=Math.max(0,Math.floor(lo/binHz-0.5));
  const last=Math.min(bins-1,Math.ceil(hi/binHz-0.5));
  let power=0;
  for(let i=first;i<=last;i++){
    const binLo=Math.max(0,(i-0.5)*binHz), binHi=Math.min(nyquist,(i+0.5)*binHz);
    const overlap=Math.max(0,Math.min(hi,binHi)-Math.max(lo,binLo));
    if(overlap>0 && Number.isFinite(data[i])) power+=db2lin(data[i])*(overlap/binHz);
  }
  return 10*Math.log10(power+1e-12);
}
function binOverlapLinearPower(linearData,fLo,fHi,nyquist,divisor){
  const bins=linearData.length,binHz=nyquist/bins;
  const lo=Math.max(0,fLo),hi=Math.min(nyquist,fHi);
  if(!(hi>lo))return 0;
  const first=Math.max(0,Math.floor(lo/binHz-.5));
  const last=Math.min(bins-1,Math.ceil(hi/binHz-.5));
  let power=0;divisor=Math.max(1,divisor||1);
  for(let i=first;i<=last;i++){
    const binLo=Math.max(0,(i-.5)*binHz),binHi=Math.min(nyquist,(i+.5)*binHz);
    const overlap=Math.max(0,Math.min(hi,binHi)-Math.max(lo,binLo));
    if(overlap>0&&Number.isFinite(linearData[i]))power+=(linearData[i]/divisor)*(overlap/binHz);
  }
  return power;
}
function calibratedResponseDb(db,f){ return db-(micCal?micCalAt(f):0); }
function rtaTimeConstant(){
  const s=Math.max(0,Math.min(.98,parseFloat(document.getElementById('smooth')?.value)||0));
  const base=s<=0?0:(.02+.60*s*s);
  if(!avgOn) return base;
  const preset=Math.max(.5,Math.min(.995,avgAlpha));
  const extra=-1/30/Math.log(preset);
  return Math.max(base,extra);
}
function smoothBandDb(index,nextDb,alpha){
  const nextPower=db2lin(nextDb), previous=avgBuf[index];
  const power=Number.isFinite(previous)?previous*alpha+nextPower*(1-alpha):nextPower;
  avgBuf[index]=power;
  return 10*Math.log10(power+1e-12);
}
function heat(t){
  t=Math.max(0,Math.min(1,t));
  const r=Math.round(255*Math.max(0,Math.min(1,1.3*t-0.35)));
  const g=Math.round(255*Math.max(0,Math.min(1,1.1*t-0.05)));
  const b=Math.round(255*Math.max(0,Math.min(1,0.30+0.70*t)));
  return 'rgb('+r+','+g+','+b+')';
}
function fLabel(f){return f>=1000?(f%1000?(f/1000).toFixed(1):f/1000)+'k':''+f;}

function updateLevel(){
  if(!analyserMeter) return;
  analyserMeter.getFloatTimeDomainData(timeDataMeter);
  const dbfs = levelDb(timeDataMeter, 2048);

  if (dbfs > smoothedDbfs) {
    smoothedDbfs += (dbfs - smoothedDbfs) * 0.55;
  } else {
    smoothedDbfs += (dbfs - smoothedDbfs) * 0.035;
  }

  const now=performance.now();
  if(smoothedDbfs>lvlPeak || now-lvlPeakT>1500){ lvlPeak=smoothedDbfs; lvlPeakT=now; }
  const pct=v=>Math.max(0,Math.min(100,(v+60)/60*100));
  meterFill.style.width=pct(smoothedDbfs)+'%';
  meterPeak.style.insetInlineStart=pct(lvlPeak)+'%';
  if(meterUnit==='SPL') meterVal.textContent=(smoothedDbfs+calib).toFixed(0)+' dB SPL≈';
  else meterVal.textContent=smoothedDbfs.toFixed(1)+' dBFS';

  const w = weightMode==='A'?weightA : weightMode==='C'?weightC : null;
  let p=0;
  for(let i=1;i<floatData.length;i++){
    const wdb = w ? w[i] : 0;
    if(wdb<-100) continue;
    p += db2lin(floatData[i]+wdb);
  }
  const lvl = 10*Math.log10(p+1e-12) + calib;
  if(!frozen){ leqSumP += p; leqN++; if(lvl>splMax) splMax=lvl; }
  const leq = 10*Math.log10(leqSumP/Math.max(1,leqN)+1e-12) + calib;
  const unit = calib>0 ? ' dB'+weightMode : '';
  const fmt=x=>x.toFixed(1)+unit;
  document.getElementById('splNow').textContent=fmt(lvl);
  document.getElementById('splLeq').textContent=fmt(leq);
  document.getElementById('splMax').textContent=fmt(splMax);
}

let _lastDraw=0;
function draw(){
  raf=requestAnimationFrame(draw);
  const now=performance.now();
  if(now-_lastDraw < 32) return;
  _lastDraw=now;
  updateSignalTint();
  if(!frozen) analyser.getFloatFrequencyData(floatData);
  if(measState==='measuring' && measAccum){
    const srcData = floatData;
    for(let i=0;i<srcData.length;i++) measAccum[i]+=db2lin(srcData[i]);
    measFrames++;
  }
  if(areaState==='measuring' && areaAccum){
    const srcData = floatData;
    for(let i=0;i<srcData.length;i++) areaAccum[i]+=db2lin(srcData[i]);
    areaFrames++;
  }
  if(analyserRef && floatDataRef && (tfState==='measuring' || tfPanel.classList.contains('open'))){
    analyserRef.getFloatFrequencyData(floatDataRef);
    if(tfState==='measuring' && tfMic){
      const mic = tfSwap? floatDataRef : floatData;
      const ref = tfSwap? floatData : floatDataRef;
      for(let i=0;i<tfMic.length;i++){
        tfMic[i]+=db2lin(mic[i]);
        tfRef[i]+=db2lin(ref[i]);
      }
      tfFrames++;
    }
    if(tfPanel.classList.contains('open')) updateTfLevels();
  }
  if(analyserRef && floatDataRef && dlyPanel.classList.contains('open')){
    analyser.getFloatTimeDomainData(timeData);
    if(!timeDataRef || timeDataRef.length!==analyserRef.fftSize) timeDataRef=new Float32Array(analyserRef.fftSize);
    analyserRef.getFloatTimeDomainData(timeDataRef);
    setGain('dlyMic', levelDb(timeData,2048));
    setGain('dlyRef', levelDb(timeDataRef,2048));
  }
  if(eqPanel.classList.contains('open')){
    analyser.getFloatTimeDomainData(timeData);
    const targetData = timeData;
    setGainEl(document.getElementById('eqMicFill'), document.getElementById('eqMicGain'), levelDb(targetData,2048));
  }
  if(areaPanel.classList.contains('open')){
    analyser.getFloatTimeDomainData(timeData);
    setGainEl(document.getElementById('areaMicFill'), document.getElementById('areaMicGain'), levelDb(timeData,2048));
  }
  if(genPanel.classList.contains('open')){
    analyser.getFloatTimeDomainData(timeData);
    const micDb=levelDb(timeData,2048);
    setGainEl(document.getElementById('gainMicFill'), document.getElementById('gainMicGain'), micDb);
    const tip=document.getElementById('gainTip');
    if(tip){
      let msg, col='var(--dim)';
      if(!genOn) msg='נגן אות כדי לבדוק את הרמות.';
      else if(micDb>=-1){ msg='⚠ קליפ! הורד את גיין המיק\' במיקסר.'; col='var(--hot)'; }
      else if(micDb>=-8){ msg='חזק — אפשר להוריד מעט גיין מיק\'.'; col='var(--warn)'; }
      else if(micDb>=-40){ msg='✓ רמה טובה — אפשר למדוד.'; col='#39d98a'; }
      else { msg='חלש — הגבר גיין מיק\' במיקסר או העלה עוצמת PA.'; col='var(--warn)'; }
      tip.textContent=msg; tip.style.color=col;
    }
  }
  if(rtPanel.classList.contains('open')){
    analyser.getFloatTimeDomainData(timeData);
    setGainEl(document.getElementById('rtLvlFill'), document.getElementById('rtLvlGain'), levelDb(timeData,2048));
  }
  updateLevel();
  v52UpdateLiveMeters();
  const W=cv.clientWidth,H=cv.clientHeight;
  const nyquist=audioCtx.sampleRate/2, bins=floatData.length;
  const logMin=Math.log(ISO[0]), logMax=Math.log(ISO[BANDS-1]);
  const xForFreq=f=>((Math.log(f)-logMin)/(logMax-logMin))*W;

  if(mode==='rta'){
    drawRta(W,H,nyquist,bins,xForFreq);
    if(eqRangeWorkspaceOpen()){
      drawRtaEqRange(W,H,xForFreq);
      drawRtaEqCorrection(W,H,xForFreq);
    }
  }
  else drawSpec(W,H,nyquist,bins,xForFreq);

  fbFrameCounter++;
  if(fbOn && !frozen && fbFrameCounter % 4 === 0) detectFeedback(nyquist,bins);
}

function computeComplexTf(){
  if(!analyser || !analyserRef) return null;
  analyser.getFloatTimeDomainData(timeData);
  if(!timeDataRef || timeDataRef.length!==analyserRef.fftSize) timeDataRef=new Float32Array(analyserRef.fftSize);
  analyserRef.getFloatTimeDomainData(timeDataRef);

  const m = tfSwap ? timeDataRef : timeData;
  const r = tfSwap ? timeData : timeDataRef;

  const N = TF_FFT_N;
  for(let i=0; i<N; i++){
    tfXr[i] = r[i] * tfWin[i];         tfXi[i] = 0;
    tfYr[i] = m[i] * tfWin[i];        tfYi[i] = 0;
  }

  fft(tfXr, tfXi, false);
  fft(tfYr, tfYi, false);

  const halfN = N / 2;
  const alpha = tfSmoothA;

  for(let k=0; k<halfN; k++){
    const rx = tfXr[k], ix = tfXi[k];
    const ry = tfYr[k], iy = tfYi[k];

    const pxx = rx*rx + ix*ix;
    const pyy = ry*ry + iy*iy;
    const rawRe = ry*rx + iy*ix;
    const rawIm = iy*rx - ry*ix;
    const corrected=applyDelayPhaseToCross(rawRe,rawIm,k,N,tfDelaySamples);
    const pxyRe=corrected.re,pxyIm=corrected.im;

    tfPxx[k] = alpha * tfPxx[k] + (1 - alpha) * pxx;
    tfPyy[k] = alpha * tfPyy[k] + (1 - alpha) * pyy;
    tfPxyRe[k] = alpha * tfPxyRe[k] + (1 - alpha) * pxyRe;
    tfPxyIm[k] = alpha * tfPxyIm[k] + (1 - alpha) * pxyIm;
  }
}

function applyDelayPhaseToCross(re,im,k,n,delaySamples){
  if(!delaySamples)return {re,im};
  const phase=2*Math.PI*k*delaySamples/n,c=Math.cos(phase),s=Math.sin(phase);
  return {re:re*c-im*s,im:re*s+im*c};
}

function drawRtaEqRange(W,H,xForFreq){
  const meterH=(meterEl&&meterEl.style.display!=='none')?40:6,plotH=H-meterH-16;
  const xLo=xForFreq(eqMinFreq),xHi=xForFreq(eqMaxFreq);
  ctx.save();ctx.setLineDash([]);
  const handle=(x,label,side,color)=>{
    const active=eqRtaRangeDrag===side;
    ctx.globalAlpha=active?1:.72;ctx.strokeStyle=color;ctx.lineWidth=active?2.4:1.35;ctx.setLineDash(active?[]:[4,4]);
    ctx.beginPath();ctx.moveTo(x,31);ctx.lineTo(x,plotH);ctx.stroke();ctx.setLineDash([]);
    ctx.font='700 10px -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif';
    const bw=Math.max(68,ctx.measureText(label).width+16),bh=20,bx=side==='min'?Math.min(x+5,W-bw-4):Math.max(4,x-bw-5),by=7,r=7;
    ctx.beginPath();ctx.moveTo(bx+r,by);ctx.lineTo(bx+bw-r,by);ctx.quadraticCurveTo(bx+bw,by,bx+bw,by+r);ctx.lineTo(bx+bw,by+bh-r);ctx.quadraticCurveTo(bx+bw,by+bh,bx+bw-r,by+bh);ctx.lineTo(bx+r,by+bh);ctx.quadraticCurveTo(bx,by+bh,bx,by+bh-r);ctx.lineTo(bx,by+r);ctx.quadraticCurveTo(bx,by,bx+r,by);ctx.closePath();
    ctx.fillStyle=sunMode?'rgba(255,255,255,.94)':'rgba(8,19,28,.92)';ctx.fill();ctx.strokeStyle=color;ctx.lineWidth=1;ctx.stroke();
    ctx.fillStyle=sunMode?'#1e293b':'#dce8f0';ctx.textAlign='center';ctx.fillText(label,bx+bw/2,by+13.5);
    ctx.beginPath();ctx.arc(x,31,active?4.5:3.2,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();ctx.globalAlpha=1;
  };
  handle(xLo,'HPF · '+fLabel(eqMinFreq)+' Hz','min','#38bdf8');
  handle(xHi,'LPF · '+fLabel(eqMaxFreq)+' Hz','max','#f59e0b');
  ctx.restore();
}

function drawRtaEqCorrection(W,H,xForFreq){
  if(!eqCorrectionVisible||!eqCurveData||!eqCurveData.freqs||!eqCurveData.corr)return;
  const meterH=(meterEl&&meterEl.style.display!=='none')?40:6,plotH=H-meterH-16;
  const ribbonH=Math.min(82,Math.max(58,plotH*.18)),top=plotH-ribbonH-5,mid=top+ribbonH/2,scale=(ribbonH*.38)/6;
  const pts=[];for(let i=0;i<eqCurveData.freqs.length;i++){const f=eqCurveData.freqs[i],v=eqCurveData.corr[i];if(v!=null&&Number.isFinite(v))pts.push({x:xForFreq(f),y:mid-v*scale,v});}
  if(!pts.length)return;
  ctx.save();ctx.fillStyle=sunMode?'rgba(255,255,255,.88)':'rgba(5,14,21,.82)';ctx.fillRect(0,top,W,ribbonH);
  ctx.strokeStyle=sunMode?'rgba(71,85,105,.35)':'rgba(148,163,184,.35)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,mid);ctx.lineTo(W,mid);ctx.stroke();
  ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle='#55b9f3';ctx.lineWidth=2.5;ctx.lineJoin='round';ctx.stroke();
  pts.forEach(p=>{if(Math.abs(p.v)<.5)return;ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fillStyle=p.v<0?'#ff5a78':'#50e68c';ctx.fill();});
  ctx.font='800 10px sans-serif';ctx.textAlign='left';ctx.fillStyle=sunMode?'#334155':'#d8e5ee';ctx.fillText('תיקון EQ מוצע  ·  ±6dB',10,top+14);
  ctx.textAlign='right';ctx.fillStyle='#50e68c';ctx.fillText('+6',W-8,top+12);ctx.fillStyle='#ff5a78';ctx.fillText('−6',W-8,top+ribbonH-6);
  ctx.restore();
}

function drawRta(W,H,nyquist,bins,xForFreq){
  ctx.clearRect(0,0,W,H);
  if(sunMode){
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0,0,W,H);
  }
  const now=performance.now();
  const dt=_lastRtaSmoothTime?Math.max(.001,Math.min(.25,(now-_lastRtaSmoothTime)/1000)):1/30;
  _lastRtaSmoothTime=now;
  const tau=rtaTimeConstant();
  const smoothAlpha=tau>0?Math.exp(-dt/tau):0;
  const meterH = (meterEl && meterEl.style.display!=='none') ? 40 : 6;
  const plotH = H - meterH - 16;
  const labelY = H - meterH - 4;
  ctx.strokeStyle=sunMode ? '#cbd5e1' : '#2b3646'; 
  ctx.fillStyle=sunMode ? '#475569' : '#aeb9c7'; 
  ctx.font='11px monospace'; ctx.textAlign='center';
  const lo=ISO[0], hi=ISO[BANDS-1];
  [20,31.5,50,100,200,500,1000,2000,5000,10000,20000].filter(f=>f>=lo&&f<=hi).forEach(f=>{
    const x=xForFreq(f);
    ctx.globalAlpha=.6; ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,plotH);ctx.stroke(); ctx.globalAlpha=1;
    ctx.fillText(fLabel(f)+'Hz',x,labelY);
  });
  [0.25,0.5,0.75].forEach(p=>{ctx.globalAlpha=.3;ctx.strokeStyle=sunMode?'#cbd5e1':'#2b3646';ctx.beginPath();ctx.moveTo(0,plotH*p);ctx.lineTo(W,plotH*p);ctx.stroke();ctx.globalAlpha=1;});

  const bw=W/BANDS, gap=Math.max(0.5,bw*0.12);
  const tfRequested = (tfOverlay || (typeof tfPanel!=='undefined' && tfPanel.classList.contains('open')) || alignOn) && floatDataRef && analyserRef;
  const tfOpen = tfRequested && tfHasReferenceSignal();
  
  const qBar = document.getElementById('tfQuickBar');
  if(qBar) qBar.classList.toggle('show', tfRequested && !alignOn);

  let peakBand=-1,peakVal=0;
  const abCompare = (abView==='both' || abView==='delta') && (abA || abB);

  for(let b=0;b<BANDS;b++){
    const fc=ISO[b];
    const rawDb=calibratedResponseDb(binOverlapPowerDb(floatData,fc/R,fc*R,nyquist),fc);
    const displayDb=smoothBandDb(b,rawDb,smoothAlpha);
    lastBandDb[b]=displayDb;
    let v=norm(displayDb);
    lastV[b]=v;
    if(v>peakVal){peakVal=v;peakBand=b;}
    
    if(!tfRequested && !abCompare){
      const x=b*bw+gap/2, barW=bw-gap;
      const barH=v*plotH, y=plotH-barH;
      let col= v<0.85?'rgba('+accentRgb[0]+','+accentRgb[1]+','+accentRgb[2]+','+(0.4+v).toFixed(2)+')' : 'var(--hot)';
      ctx.fillStyle=col; ctx.fillRect(x,y,barW,barH);
      if(peakHold){
        if(v>=peaks[b]) peaks[b]=v; else peaks[b]=Math.max(0,peaks[b]-0.005);
        const py=plotH-peaks[b]*plotH;
        ctx.fillStyle=sunMode?'#0f172a':'rgba(255,255,255,.85)'; ctx.fillRect(x,py-2,barW,2);
      }
    }
  }
  
  if(tfRequested){
    const alignView = alignOn;
    if(!frozen) analyserRef.getFloatFrequencyData(floatDataRef);
    for(let b=0;b<BANDS;b++){
      const rv=norm(binOverlapPowerDb(floatDataRef,ISO[b]/R,ISO[b]*R,nyquist));
      const a=Math.exp(-dt/.10);
      lastRefV[b]=lastRefV[b]*a+rv*(1-a);
    }
    
    if(tfOpen)computeComplexTf();
    if(!alignView)tfDrawDualLiveView(W,plotH);

    if(tfOpen && showTfCoh && !alignView){
      ctx.beginPath();
      for(let px = 0; px <= W; px += 2){
        const f = freqForX(px);
        const k = Math.min(TF_FFT_N/2 - 1, Math.round(f / nyquist * (TF_FFT_N/2)));
        const pxx = tfPxx[k], pyy = tfPyy[k];
        const pxySq = tfPxyRe[k]*tfPxyRe[k] + tfPxyIm[k]*tfPxyIm[k];
        const coh = Math.max(0, Math.min(1, pxySq / (pxx * pyy + 1e-12)));
        const y = plotH - coh * plotH;
        px === 0 ? ctx.moveTo(px, y) : ctx.lineTo(px, y);
      }
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.75)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 2]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    if(tfOpen && showTfPhase && !alignView){
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.9)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let penDown=false, prevY=0;
      for(let px = 0; px <= W; px += 2){
        const f = freqForX(px);
        const k = Math.min(TF_FFT_N/2 - 1, Math.round(f / nyquist * (TF_FFT_N/2)));
        const pxx = tfPxx[k], pyy = tfPyy[k];
        const pxySq = tfPxyRe[k]*tfPxyRe[k] + tfPxyIm[k]*tfPxyIm[k];
        const coh = Math.max(0, Math.min(1, pxySq / (pxx * pyy + 1e-12)));
        if(coh < tfCohGate){ penDown=false; continue; }   // שער קוהרנטיות: מסתיר פאזה לא-אמינה
        const phaseRad = Math.atan2(tfPxyIm[k], tfPxyRe[k]);
        const phaseNorm = 0.5 - (phaseRad / (2 * Math.PI));
        const y = plotH * Math.max(0, Math.min(1, phaseNorm));
        if(penDown && Math.abs(y - prevY) > plotH*0.5){ penDown=false; } // שבירה ב-wrap ±180°
        penDown ? ctx.lineTo(px, y) : ctx.moveTo(px, y);
        penDown=true; prevY=y;
      }
      ctx.stroke();
    }

    // ---- יישור חיתוך סאב/טופ: פאזה לא-עטופה + סמן + Δφ ----
    if(alignView || (showXover && (phaseSub || phaseTop))){
      const N2 = TF_FFT_N/2;
      const toDeg=r=>r*180/Math.PI;
      const wrap=d=>{ while(d>180)d-=360; while(d<-180)d+=360; return d; };
      // ביטול עטיפה (unwrap) של צילום פאזה, מגודר בקוהרנטיות
      const unwrapSnap=(snap)=>{
        if(!snap) return null;
        const u=new Float32Array(N2); let cum=0, prev=0, have=false;
        for(let k=0;k<N2;k++){
          if(snap.coh[k] < tfCohGate){ u[k]=NaN; have=false; continue; }
          const p=snap.ph[k];
          if(have){ let d=p-prev; while(d>Math.PI)d-=2*Math.PI; while(d<-Math.PI)d+=2*Math.PI; cum+=d; }
          else cum=p;
          u[k]=cum; prev=p; have=true;
        }
        return u;
      };
      const uSub = alignView ? unwrapSnap(phaseSub) : null;
      const uTop = alignView ? unwrapSnap(phaseTop) : null;

      // קביעת טווח Y אוטומטי (רק ב-align עם unwrap)
      let yMinDeg=-180, yMaxDeg=180;
      if(alignView && (uSub || uTop)){
        let mn=1e9, mx=-1e9;
        [uSub,uTop].forEach(u=>{ if(!u) return; for(let k=0;k<N2;k++){ const v=u[k]; if(!isNaN(v)){ const d=toDeg(v); if(d<mn)mn=d; if(d>mx)mx=d; } } });
        if(mn<mx){ const pad=Math.max(30,(mx-mn)*0.15); yMinDeg=mn-pad; yMaxDeg=mx+pad; }
      }
      // ---- פריסה: תגובה (dB) למעלה, פאזה (°) למטה ----
      const magH = alignView ? plotH*0.5 : 0;
      const phBase = magH + (alignView?8:0);
      const phH = plotH - phBase;
      const degToY = deg => phBase + phH*(1-(deg-yMinDeg)/(yMaxDeg-yMinDeg));

      // קנה מידה אוטומטי למגניטודה מתוך תגובת הסאב/טופ
      let magMin=-60, magMax=0;
      if(alignView){
        let mn=1e9, mx=-1e9;
        [phaseSub,phaseTop].forEach(s=>{ if(!s||!s.mag) return; for(let k=0;k<N2;k++){ if(s.coh[k]>=tfCohGate){ const m=s.mag[k]; if(m<mn)mn=m; if(m>mx)mx=m; } } });
        if(mn<mx){ const pad=Math.max(6,(mx-mn)*0.12); magMin=mn-pad; magMax=mx+pad; }
      }
      const magToY = db => Math.max(0,Math.min(magH, magH*(1-(db-magMin)/(magMax-magMin))));

      if(alignView){
        // רשת מגניטודה + תוויות dB
        ctx.strokeStyle=sunMode?'rgba(0,0,0,.10)':'rgba(255,255,255,.08)'; ctx.lineWidth=1;
        ctx.fillStyle=sunMode?'#475569':'#64748b'; ctx.font='10px monospace';
        const mstep=(magMax-magMin)>40?12:6;
        for(let d=Math.ceil(magMin/mstep)*mstep; d<=magMax; d+=mstep){
          const y=magToY(d); if(y<0||y>magH) continue;
          ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
          const pd=ctx.direction; ctx.direction='ltr'; ctx.textAlign='left';
          ctx.fillText(d.toFixed(0)+'dB', 4, y-2);
          ctx.direction=pd; ctx.textAlign='start';
        }
        // קו מפריד בין תגובה לפאזה
        ctx.strokeStyle=sunMode?'rgba(0,0,0,.25)':'rgba(255,255,255,.22)'; ctx.lineWidth=1;
        ctx.beginPath(); ctx.moveTo(0,magH); ctx.lineTo(W,magH); ctx.stroke();
        // תוויות אזור
        ctx.fillStyle=sunMode?'#94a3b8':'#94a3b8'; ctx.font='10px monospace';
        const pd2=ctx.direction; ctx.direction='rtl'; ctx.textAlign='right';
        ctx.fillText('תגובה', W-6, 12);
        ctx.fillText('פאזה', W-6, phBase+12);
        ctx.direction=pd2; ctx.textAlign='start';
        // רשת פאזה + תוויות מעלות (באזור הפאזה)
        ctx.strokeStyle=sunMode?'rgba(0,0,0,.12)':'rgba(255,255,255,.10)'; ctx.lineWidth=1;
        ctx.fillStyle=sunMode?'#475569':'#64748b'; ctx.font='10px monospace';
        const step = (yMaxDeg-yMinDeg)>540?180:90;
        for(let d=Math.ceil(yMinDeg/step)*step; d<=yMaxDeg; d+=step){
          const y=degToY(d); if(y<phBase-1||y>plotH+1) continue;
          ctx.globalAlpha = d===0?0.5:1;
          ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); ctx.globalAlpha=1;
          const pd=ctx.direction; ctx.direction='ltr'; ctx.textAlign='left';
          ctx.fillText(d+'°', 4, y-2);
          ctx.direction=pd; ctx.textAlign='start';
        }
      }

      // מגניטודה — קווים דקים (למעלה)
      const drawMag=(snap,color)=>{
        if(!alignView || !snap || !snap.mag) return;
        ctx.strokeStyle=color; ctx.lineWidth=1.5; ctx.globalAlpha=0.85; ctx.beginPath();
        let pen=false;
        for(let px=0;px<=W;px+=2){
          const f=freqForX(px), k=Math.min(N2-1, Math.round(f/nyquist*N2));
          if(snap.coh[k] < tfCohGate){ pen=false; continue; }
          const y=magToY(snap.mag[k]);
          pen?ctx.lineTo(px,y):ctx.moveTo(px,y); pen=true;
        }
        ctx.stroke(); ctx.globalAlpha=1;
      };
      drawMag(phaseSub, '#38bdf8');
      drawMag(phaseTop, '#e879f9');

      // פאזה — קווים עבים (למטה)
      const drawSnap=(snap,unw,color)=>{
        if(!snap) return;
        ctx.strokeStyle=color; ctx.lineWidth=2.5; ctx.beginPath();
        let pen=false, prevY=0;
        for(let px=0;px<=W;px+=2){
          const f=freqForX(px);
          const k=Math.min(N2-1, Math.round(f/nyquist*N2));
          if(snap.coh[k] < tfCohGate){ pen=false; continue; }
          let y;
          if(alignView){ const v=unw[k]; if(isNaN(v)){ pen=false; continue; } y=degToY(toDeg(v)); }
          else { y=plotH*Math.max(0,Math.min(1, 0.5 - snap.ph[k]/(2*Math.PI))); }
          if(pen && Math.abs(y-prevY)>phH*0.5) pen=false;
          pen?ctx.lineTo(px,y):ctx.moveTo(px,y);
          pen=true; prevY=y;
        }
        ctx.stroke();
      };
      drawSnap(phaseSub, uSub, '#38bdf8');  // סאב = תכלת
      drawSnap(phaseTop, uTop, '#e879f9');  // טופ = ורוד

      // סמן תדר החיתוך
      const mx=xForFreq(xoverF);
      ctx.strokeStyle='rgba(255,255,255,.55)'; ctx.setLineDash([5,4]); ctx.lineWidth=1;
      ctx.beginPath(); ctx.moveTo(mx,0); ctx.lineTo(mx,plotH); ctx.stroke(); ctx.setLineDash([]);

      const k=Math.min(N2-1, Math.round(xoverF/nyquist*N2));
      const subOk = phaseSub && phaseSub.coh[k]>=tfCohGate;
      const topOk = phaseTop && phaseTop.coh[k]>=tfCohGate;

      const boxW=228;
      const bx=Math.min(W-boxW-8, Math.max(10, mx+8)), by=10;
      ctx.fillStyle=sunMode?'rgba(255,255,255,.92)':'rgba(10,15,25,.85)';
      ctx.fillRect(bx,by,boxW,86);
      ctx.strokeStyle='rgba(148,163,184,.5)'; ctx.lineWidth=1; ctx.strokeRect(bx,by,boxW,86);
      ctx.font='12px monospace';
      const prevDir=ctx.direction; ctx.direction='rtl'; ctx.textAlign='right';
      const rx=bx+boxW-10;
      ctx.fillStyle=sunMode?'#0f172a':'#e5e7eb'; ctx.fillText('תדר חיתוך: '+xoverF+' Hz', rx, by+18);
      ctx.fillStyle='#38bdf8'; ctx.fillText('סאב: '+(subOk?toDeg(phaseSub.ph[k]).toFixed(0)+'°':'— קוה׳ נמוכה'), rx, by+36);
      ctx.fillStyle='#e879f9'; ctx.fillText('טופ: '+(topOk?toDeg(phaseTop.ph[k]).toFixed(0)+'°':'— קוה׳ נמוכה'), rx, by+54);
      if(subOk && topOk){
        const d=wrap(toDeg(phaseTop.ph[k]-phaseSub.ph[k])); const ad=Math.abs(d);
        const col = ad<30?'#22c55e':'#f59e0b';
        const verdict = ad<30?'מיושר ✓':'המלצה למטה';
        ctx.fillStyle=col; ctx.fillText('Δφ: '+(d>0?'+':'')+d.toFixed(0)+'°  '+verdict, rx, by+76);
      } else {
        ctx.fillStyle=sunMode?'#64748b':'#94a3b8'; ctx.fillText('לכוד סאב וטופ למדידת Δφ', rx, by+76);
      }
      ctx.direction=prevDir; ctx.textAlign='start';
    }
    
    ctx.font='11px monospace'; ctx.textAlign='start';
    if(showTfCoh){ ctx.fillStyle='rgba(239, 68, 68, 0.9)'; ctx.fillText('- - COHERENCE', 10, 64); }
    if(showTfPhase){ ctx.fillStyle='rgba(34, 197, 94, 0.9)'; ctx.fillText('— PHASE', 10, showTfCoh?78:64); }
  }
  
  if(refCurve && refCurve.v && refCurve.bands===BANDS){
    ctx.strokeStyle='#b57bff'; ctx.lineWidth=2; ctx.setLineDash([5,4]); ctx.beginPath();
    for(let b=0;b<BANDS;b++){ const x=b*bw+bw/2, yy=plotH-refCurve.v[b]*plotH; b===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy); }
    ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle='#b57bff'; ctx.font='11px monospace'; ctx.textAlign='start';
    ctx.fillText('- - לפני', 10, tfOpen?(showTfCoh&&showTfPhase?70:showTfCoh||showTfPhase?56:42):14);
  }

  if(!tfOpen){
    tfTraces.filter(t=>t.type==='rta'&&t.visible!==false&&t.bands===BANDS).forEach(t=>{
      ctx.strokeStyle=t.color;ctx.lineWidth=1.7;ctx.globalAlpha=.78;ctx.beginPath();
      t.values.forEach((v,b)=>{const x=b*bw+bw/2,yy=plotH-v*plotH;b===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy);});
      ctx.stroke();ctx.globalAlpha=1;
    });
    if(tfRequested && !alignOn){
      ctx.save();ctx.font='600 10px monospace';ctx.textAlign='right';
      const message='Reference low · MIC 1 + REF 2 remain live';
      const w=ctx.measureText(message).width+16;
      ctx.fillStyle=sunMode?'rgba(255,255,255,.92)':'rgba(10,20,28,.88)';ctx.fillRect(W-w-8,8,w,24);
      ctx.strokeStyle=sunMode?'#cbd5e1':'#385064';ctx.strokeRect(W-w-8,8,w,24);
      ctx.fillStyle=sunMode?'#475569':'#b9c7d3';ctx.fillText(message,W-16,24);ctx.restore();
    }
  }

  // ---- השוואת A/B (לפני/אחרי כיוון) ----
  if(abA || abB){
    const graph=(snap,line,fill,doFill)=>{
      if(!snap || !snap.f || !snap.f.length) return;
      if(doFill){
        ctx.beginPath();
        ctx.moveTo(xForFreq(snap.f[0]), plotH);
        for(let i=0;i<snap.f.length;i++){ const x=xForFreq(snap.f[i]), yy=plotH-norm(snap.db[i])*plotH; ctx.lineTo(x,yy); }
        ctx.lineTo(xForFreq(snap.f[snap.f.length-1]), plotH);
        ctx.closePath(); ctx.fillStyle=fill; ctx.fill();
      }
      ctx.beginPath();
      for(let i=0;i<snap.f.length;i++){ const x=xForFreq(snap.f[i]), yy=plotH-norm(snap.db[i])*plotH; i===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy); }
      ctx.strokeStyle=line; ctx.lineWidth=2.5; ctx.lineJoin='round'; ctx.stroke();
    };
    ctx.font='12px monospace'; ctx.textAlign='start';
    let ly = tfOpen ? 92 : 20;
    if(abView!=='off'){
      const bothOn = (abView==='both');
      if((abView==='A'||abView==='both') && abA){ graph(abA,'#f59e0b','rgba(245,158,11,0.18)',bothOn); ctx.fillStyle='#f59e0b'; ctx.fillText('■ לפני הכיוון (A)',10,ly); ly+=16; }
      if((abView==='B'||abView==='both') && abB){ graph(abB,'#22c55e','rgba(34,197,94,0.18)',bothOn); ctx.fillStyle='#22c55e'; ctx.fillText('■ אחרי הכיוון (B)',10,ly); ly+=16; }
      if(abView==='delta' && abA && abB){
        const midY=plotH/2;
        ctx.setLineDash([4,4]); ctx.strokeStyle=sunMode?'rgba(0,0,0,.25)':'rgba(255,255,255,.28)';
        ctx.beginPath(); ctx.moveTo(0,midY); ctx.lineTo(W,midY); ctx.stroke(); ctx.setLineDash([]);
        ctx.strokeStyle='#39d98a'; ctx.lineWidth=2.5; ctx.beginPath();
        const n=Math.min(abA.f.length, abB.f.length);
        for(let i=0;i<n;i++){
          const diff=abB.db[i]-abA.db[i];
          const x=xForFreq(abA.f[i]), yy=midY-(diff*(plotH/40));
          i===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy);
        }
        ctx.stroke();
        ctx.fillStyle='#39d98a'; ctx.fillText('Δ אחרי−לפני · קו אמצע=0 · טווח ±20dB',10,ly); ly+=16;
      }
    }
    if(abA && !abB){
      ctx.fillStyle=sunMode?'#b45309':'#fbbf24';
      ctx.fillText('לפני (A) נלכד ✓ — כוונן את המערכת ואז לחץ ״לכוד אחרי (B)״', 10, ly);
    }
  }
  if(snapCurve && snapCurve.length===BANDS){
    ctx.strokeStyle='#ffb020'; ctx.lineWidth=2; ctx.beginPath();
    for(let b=0;b<BANDS;b++){
      const x=b*bw+bw/2, yy=plotH-snapCurve[b]*plotH;
      b===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy);
    }
    ctx.stroke();
    ctx.fillStyle='#ffb020'; ctx.font='10px monospace'; ctx.textAlign='start';
    ctx.fillText('הקפאה', 8, 12);
    const peaks=[];
    for(let b=1;b<BANDS-1;b++){
      const v=snapCurve[b];
      if(v>snapCurve[b-1] && v>=snapCurve[b+1] && v>0.35) peaks.push({b,v});
    }
    peaks.sort((a,z)=>z.v-a.v);
    peaks.slice(0,6).forEach(p=>{
      const b=p.b, x=b*bw+bw/2, yy=plotH-p.v*plotH;
      const fc=ISO[b]; let lo=Math.floor((fc/R)/nyquist*bins), hi=Math.ceil((fc*R)/nyquist*bins);
      lo=Math.max(1,lo); hi=Math.min(bins-1,hi); let bMax=-999, bi=lo;
      for(let i=lo;i<=hi;i++){ if(floatData[i]>bMax){bMax=floatData[i];bi=i;} }
      const hz=bi*nyquist/bins;
      const lbl=hz>=1000?(hz/1000).toFixed(2)+'k':Math.round(hz)+'';
      ctx.fillStyle='#ffb020'; ctx.beginPath(); ctx.arc(x,yy,3,0,6.28); ctx.fill();
      ctx.font='10px monospace'; ctx.textAlign='center';
      const tw=ctx.measureText(lbl).width+6;
      ctx.fillStyle=sunMode?'#f1f5f9':'rgba(13,17,23,.9)'; ctx.fillRect(x-tw/2, yy-16, tw, 13);
      ctx.fillStyle='#b45309'; ctx.fillText(lbl, x, yy-6);
    });
  }
  if(dragging && Math.abs(dragX1-dragX0)>4){
    const xa=Math.min(dragX0,dragX1), xb=Math.max(dragX0,dragX1);
    ctx.fillStyle='rgba(47,155,255,.15)'; ctx.fillRect(xa,0,xb-xa,plotH);
    ctx.strokeStyle='rgba(47,155,255,.8)'; ctx.lineWidth=1;
    ctx.strokeRect(xa,0,xb-xa,plotH);
  }
  // Target uses each graph's own vertical scale: normalized level in RTA and
  // relative dB (0 dB centre) in TF.
  if(targetVisible && targetMode!=='off' && !alignOn && !tfRequested){
    ctx.strokeStyle='rgba(80,230,140,.8)'; ctx.setLineDash([6,5]); ctx.lineWidth=2; ctx.beginPath();
    for(let b=0;b<BANDS;b++){
      const x=b*bw+bw/2;
      const yy=tfOpen
        ? tfMagY(targetDb(ISO[b]),plotH)
        : plotH-Math.max(0.05, Math.min(0.95, 0.55 + targetDb(ISO[b])*0.03))*plotH;
      b===0?ctx.moveTo(x,yy):ctx.lineTo(x,yy);
    }
    ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle='rgba(80,230,140,.9)'; ctx.font='10px monospace'; ctx.textAlign='end';
    ctx.fillText(tfOpen?(targetMode==='house'?'Target House · TF':'Target 0dB · TF'):(targetMode==='house'?'יעד House':'יעד שטוח'), W-8, 12);
  }
  if(cursorX!=null && cursorX>=0 && cursorX<=W){
    const cf=freqForX(cursorX);
    const bi=Math.max(0,Math.min(BANDS-1,Math.floor(cursorX/bw)));
    ctx.strokeStyle=sunMode?'rgba(0,0,0,.55)':'rgba(255,255,255,.55)'; ctx.setLineDash([3,3]); ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(cursorX,0);ctx.lineTo(cursorX,plotH);ctx.stroke(); ctx.setLineDash([]);
    const fl=cf>=1000?(cf/1000).toFixed(2)+'kHz':Math.round(cf)+'Hz';
    const lvl=(lastBandDb[bi]!=null&&lastBandDb[bi]>-119)?('  '+Math.round(lastBandDb[bi])+'dB'):'';
    const label=fl+lvl;
    ctx.font='12px monospace'; ctx.textAlign='left';
    const tw=ctx.measureText(label).width+12;
    let tx=Math.max(2,Math.min(W-tw-2, cursorX-tw/2));
    ctx.fillStyle=sunMode?'#ffffff':'rgba(13,17,23,.92)'; ctx.fillRect(tx,plotH-22,tw,18);
    ctx.strokeStyle='rgba(47,155,255,.7)'; ctx.strokeRect(tx,plotH-22,tw,18);
    ctx.fillStyle=sunMode?'#0f172a':'#e6ecf3'; ctx.fillText(label,tx+6,plotH-9);
  }
  const visAreas=areas.filter(a=>a.show);
  if(visAreas.length){
    visAreas.forEach(a=>{
      ctx.strokeStyle=a.color; ctx.lineWidth=2; ctx.beginPath(); let started=false;
      for(let k=0;k<GEQ.length;k++){
        const f=GEQ[k]; if(f<ISO[0]||f>ISO[BANDS-1]) continue;
        const x=xForFreq(f), yy=plotH-norm(a.db[k])*plotH;
        started?ctx.lineTo(x,yy):ctx.moveTo(x,yy); started=true;
      }
      ctx.stroke();
    });
    ctx.textAlign='start'; ctx.font='11px monospace';
    visAreas.forEach((a,i)=>{
      const y=30+i*16;
      ctx.fillStyle=a.color; ctx.fillRect(8,y-8,16,3);
      ctx.fillStyle=sunMode?'#0f172a':'#e6ecf3'; ctx.fillText(a.name,28,y-2);
    });
  }
  if(fbOn && fbTrack.size){
    const flagged=[];
    for(const [,rec] of fbTrack){ if(rec.hold>=FB_CONFIRM && rec.swing<FB_MAXSWING) flagged.push(rec); }
    flagged.sort((a,b)=>b.db-a.db);
    ctx.textAlign='center';
    flagged.slice(0,4).forEach(rec=>{
      const x=xForFreq(rec.hz); if(x<0||x>W) return;
      const y=plotH-norm(rec.db)*plotH;
      ctx.fillStyle='rgba(255,59,107,.95)';
      ctx.beginPath(); ctx.arc(x,y-8,4,0,6.283); ctx.fill();
      ctx.strokeStyle='rgba(255,59,107,.9)'; ctx.lineWidth=1;
      ctx.beginPath(); ctx.moveTo(x,y-4); ctx.lineTo(x,y); ctx.stroke();
      const lbl=(rec.hz>=1000?(rec.hz/1000).toFixed(2)+'k':rec.hz+'Hz')+' −'+rec.cut+'dB';
      ctx.font='10px monospace';
      const tw=ctx.measureText(lbl).width+8;
      let tx=Math.max(2,Math.min(W-tw-2, x-tw/2));
      ctx.fillStyle=sunMode?'#fef2f2':'rgba(40,10,18,.92)'; ctx.fillRect(tx,y-26,tw,13);
      ctx.strokeStyle='rgba(255,59,107,.7)'; ctx.strokeRect(tx,y-26,tw,13);
      ctx.fillStyle='#dc2626'; ctx.fillText(lbl, tx+tw/2, y-16);
    });
  }
  let exactHz=0;
  if(peakBand>=0 && peakVal>0.05){
    const fc=ISO[peakBand];
    let lo=Math.floor((fc/R)/nyquist*bins), hi=Math.ceil((fc*R)/nyquist*bins);
    lo=Math.max(1,lo); hi=Math.min(bins-1,hi);
    let bMax=-999, bi=lo;
    for(let i=lo;i<=hi;i++){ if(floatData[i]>bMax){ bMax=floatData[i]; bi=i; } }
    let idx=bi;
    if(bi>0&&bi<bins-1){ const a=floatData[bi-1],b=floatData[bi],c=floatData[bi+1], d=a-2*b+c;
      if(d!==0) idx=bi+0.5*(a-c)/d; }
    exactHz=idx*nyquist/bins;
  }
  peakHzEl.textContent = exactHz>0
    ? (exactHz>=1000?(exactHz/1000).toFixed(3)+' kHz':Math.round(exactHz)+' Hz') : '—';
}

function drawSpec(W,H,nyquist,bins,xForFreq){
  specCtx.drawImage(specCanvas,0,-1);
  const y=specCanvas.height-1;
  for(let px=0;px<specCanvas.width;px++){
    const x0=Math.max(0,px-.5)/specCanvas.width, x1=Math.min(specCanvas.width,px+.5)/specCanvas.width;
    const fLo=Math.exp(x0*(Math.log(ISO[BANDS-1])-Math.log(ISO[0]))+Math.log(ISO[0]));
    const fHi=Math.exp(x1*(Math.log(ISO[BANDS-1])-Math.log(ISO[0]))+Math.log(ISO[0]));
    const fc=Math.sqrt(fLo*fHi);
    const db=calibratedResponseDb(binOverlapPowerDb(floatData,fLo,fHi,nyquist),fc);
    specCtx.fillStyle=heat(norm(db));
    specCtx.fillRect(px,y,1,1);
  }
  const meterH = (meterEl && meterEl.style.display!=='none') ? 40 : 6;
  const specH = H - meterH;
  ctx.clearRect(0,0,W,H);
  ctx.drawImage(specCanvas,0,0,W,specH);
  ctx.fillStyle=sunMode?'#0f172a':'#c2cbd6'; ctx.font='11px monospace'; ctx.textAlign='center';
  const lo=ISO[0], hi=ISO[BANDS-1];
  [20,31.5,50,100,200,500,1000,2000,5000,10000,20000].filter(f=>f>=lo&&f<=hi).forEach(f=>{
    const x=xForFreq(f);
    ctx.strokeStyle=sunMode?'rgba(0,0,0,.14)':'rgba(255,255,255,.14)';ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,specH);ctx.stroke();
    ctx.fillText(fLabel(f)+'Hz',x,12);
  });
  let pk=-Infinity,pkf=0;
  for(let i=1;i<bins;i++){ if(floatData[i]>pk){pk=floatData[i]; pkf=i*nyquist/bins;} }
  peakHzEl.textContent= pk>floorDb ? (pkf>=1000?(pkf/1000).toFixed(1)+' kHz':Math.round(pkf)+' Hz') : '—';
}

const FB_MINDB=-50;
const FB_MINQ=6;
const FB_CONFIRM=18;
const FB_MAXSWING=2.5;
function detectFeedback(nyquist,bins){
  const PROM=fbProm;
  const win=24;
  const seen=new Set();
  const iLo=Math.max(2,Math.floor(120/nyquist*bins));
  const iHi=Math.min(bins-2,Math.floor(10000/nyquist*bins));
  for(let i=iLo;i<=iHi;i++){
    const d=floatData[i];
    if(d<FB_MINDB) continue;
    if(!(d>floatData[i-1]&&d>=floatData[i+1])) continue;
    let sum=0,n=0;
    for(let j=i-win;j<=i+win;j++){ if(Math.abs(j-i)>2&&j>=0&&j<bins){sum+=floatData[j];n++;} }
    const avg=sum/Math.max(1,n);
    const prom=d-avg;
    if(prom<PROM) continue;
    let li=i, ri=i;
    while(li>1 && floatData[li]>d-3) li--;
    while(ri<bins-1 && floatData[ri]>d-3) ri++;
    const bw3=Math.max(1,(ri-li))*nyquist/bins;
    const hz=Math.round(i*nyquist/bins);
    const q=Math.max(2,Math.min(30, hz/bw3));
    if(q<FB_MINQ) continue;
    const cut=Math.max(3,Math.min(12, Math.round(prom*0.7)));
    const key=Math.round(hz/ (hz<300?4:hz<2000?10:40));
    seen.add(key);
    const tol = hz<300?5:hz<2000?14:50;
    const rec=fbTrack.get(key);
    if(rec){
      if(Math.abs(hz-rec.hz)<=tol) rec.hold=Math.min(FB_CONFIRM+30, rec.hold+1);
      else rec.hold=Math.max(0, rec.hold-3);
      rec.swing = rec.swing*0.8 + Math.abs(d-rec.db)*0.2;
      rec.db=d; rec.hz=hz; rec.cut=cut; rec.q=q;
    } else {
      fbTrack.set(key,{hold:1, swing:0, db:d, hz:hz, cut:cut, q:q});
    }
  }
  for(const [k,rec] of fbTrack){ if(!seen.has(k)){ rec.hold-=3; if(rec.hold<=0) fbTrack.delete(k);} }
}

loadCalStore();
document.getElementById('ver').textContent='v179';

let accentRgb=[62,166,255];
function applyAccent(hex){
  document.documentElement.style.setProperty('--accent',hex);
  document.documentElement.style.setProperty('--amber',hex);
  const m=/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if(m) accentRgb=[parseInt(m[1],16),parseInt(m[2],16),parseInt(m[3],16)];
  try{ localStorage.setItem('rta_accent',hex); }catch(_){}
}
function lsGet(k){ try{ return localStorage.getItem(k); }catch(_){ return null; } }
function prefSet(k,v){ try{ localStorage.setItem(k, v); }catch(_){} }

safeOn('refCurveBtn', 'click',function(){
  if(refCurve){ refCurve=null; this.classList.remove('on'); this.textContent='שמור כ״לפני״'; return; }
  if(!running || !lastV.length){ alert('הפעל מיקרופון ונגן אות לפני שמירת עקומת ייחוס.'); return; }
  refCurve={ v:lastV.slice(), bands:BANDS };
  this.classList.add('on'); this.textContent='נקה ״לפני״';
});

// ---- A/B: לפני/אחרי כיוון ----
function abSnapshot(){ return { f: ISO.slice(), db: lastBandDb.slice() }; }
function syncAbSeg(){ document.querySelectorAll('#abViewSeg button').forEach(x=>x.classList.toggle('on', x.dataset.v===abView)); }
function abHasData(){ return lastBandDb.length && lastBandDb.some(v=>v>-119); }
safeOn('abCapA','click',function(){
  if(!abHasData()){ alert('אין עדיין מדידה ללכוד.\nהפעל את המיקרופון, נגן אות (למשל פינק נויז), ואז לחץ שוב.'); return; }
  abA=abSnapshot(); this.classList.add('on'); this.textContent='✓ לפני (A)';
  abView = abB ? 'both' : 'A'; syncAbSeg();
});
safeOn('abCapB','click',function(){
  if(!abHasData()){ alert('אין עדיין מדידה ללכוד.\nהפעל את המיקרופון, נגן אות, ואז לחץ שוב.'); return; }
  abB=abSnapshot(); this.classList.add('on'); this.textContent='✓ אחרי (B)';
  abView = abA ? 'both' : 'B'; syncAbSeg();
});
safeOn('abClear','click',function(){
  abA=null; abB=null; abView='off';
  const a=document.getElementById('abCapA'); if(a){ a.classList.remove('on'); a.textContent='לכוד לפני (A)'; }
  const b=document.getElementById('abCapB'); if(b){ b.classList.remove('on'); b.textContent='לכוד אחרי (B)'; }
  syncAbSeg();
});
document.querySelectorAll('#abViewSeg button').forEach(b=>b.addEventListener('click',function(){ abView=this.dataset.v; syncAbSeg(); }));
safeOn('tfSmooth','input',function(e){
  tfSmoothA = Math.max(0.70, Math.min(0.98, parseInt(e.target.value,10)/100));
  const t = document.getElementById('tfSmoothVal');
  if(t) t.textContent = tfSmoothA>=0.955?'מקסימלית':tfSmoothA>=0.90?'גבוהה':tfSmoothA>=0.85?'בינונית':'מהירה';
});
safeOn('tfCohGate','input',function(e){
  tfCohGate = Math.max(0, Math.min(0.9, parseInt(e.target.value,10)/100));
  const t = document.getElementById('tfCohGateVal');
  if(t) t.textContent = tfCohGate.toFixed(2);
  if(tfDelayReady){
    tfWorkflowVerified=false;
    syncTfWorkflowUi('<b>סף הקוהרנטיות השתנה:</b> בצע שוב את שלב 2','warn');
  }
});

// ---- יישור חיתוך סאב/טופ ----
function optimizeSubTopAlignment(sub,top,sr,crossoverHz,coherenceGate,options){
  options=options||{};
  if(!sub||!top||!sub.ph||!top.ph||!sub.mag||!top.mag||!sub.coh||!top.coh)return {reliable:false,reason:'חסרות מדידות סאב או טופ'};
  sr=Math.max(8000,Number(sr)||48000);
  crossoverHz=Math.max(20,Math.min(sr/3,Number(crossoverHz)||90));
  coherenceGate=Math.max(0,Math.min(.95,Number(coherenceGate)||.4));
  const n=Math.min(sub.ph.length,top.ph.length,sub.mag.length,top.mag.length,sub.coh.length,top.coh.length);
  const fftN=Math.max(2,Number(sub.fftN)||Number(top.fftN)||n*2);
  const ratio=Math.pow(2,1/3),fLo=crossoverHz/ratio,fHi=crossoverHz*ratio;
  const points=[];let bandBins=0,cohSum=0,balanceSum=0;
  for(let k=1;k<n;k++){
    const f=k*sr/fftN;if(f<fLo||f>fHi)continue;bandBins++;
    const cs=Number(sub.coh[k]),ct=Number(top.coh[k]),ms=Number(sub.mag[k]),mt=Number(top.mag[k]);
    if(!Number.isFinite(cs)||!Number.isFinite(ct)||cs<coherenceGate||ct<coherenceGate||!Number.isFinite(ms)||!Number.isFinite(mt))continue;
    const a=Math.pow(10,ms/20),b=Math.pow(10,mt/20);if(!(a>0)||!(b>0))continue;
    const balance=Math.min(a,b)/Math.max(a,b);
    if(balance<.08)continue;
    const coh=Math.sqrt(Math.max(0,cs*ct)),weight=coh*Math.sqrt(balance);
    points.push({f,a,b,ps:Number(sub.ph[k]),pt:Number(top.ph[k]),weight,coh,balance});
    cohSum+=coh;balanceSum+=balance;
  }
  const coverage=bandBins?points.length/bandBins:0;
  const meanCoh=points.length?cohSum/points.length:0,meanBalance=points.length?balanceSum/points.length:0;
  const minPoints=Math.max(3,Math.min(5,Math.ceil(bandBins*.5)));
  if(points.length<minPoints)return {reliable:false,reason:'אין מספיק נקודות אמינות סביב החיתוך',points:points.length,coverage,meanCoh,meanBalance,band:{lo:fLo,hi:fHi}};
  const score=(tauMs,polarity)=>{
    let sum=0,weights=0;
    for(const p of points){
      const relative=p.pt-p.ps-2*Math.PI*p.f*tauMs/1000+(polarity<0?Math.PI:0);
      const combined=Math.sqrt(Math.max(1e-24,p.a*p.a+p.b*p.b+2*p.a*p.b*Math.cos(relative)));
      const efficiency=20*Math.log10(Math.max(1e-12,combined/(p.a+p.b)));
      sum+=p.weight*efficiency;weights+=p.weight;
    }
    return weights?sum/weights:-120;
  };
  const maxDelayMs=Math.max(.5,Math.min(20,Number(options.maxDelayMs)||20));
  const stepMs=Math.max(.01,Math.min(.1,Number(options.stepMs)||.02));
  const steps=Math.ceil(maxDelayMs/stepMs);
  let peakScore=-Infinity;
  for(const polarity of [1,-1])for(let i=-steps;i<=steps;i++)peakScore=Math.max(peakScore,score(i*stepMs,polarity));
  // Several delays one cycle apart can look similar. Among candidates within
  // 0.002dB of the optimum, prefer the smallest physical change and normal
  // polarity, so the recommendation cannot jump to an unnecessary full cycle.
  let chosen=null;
  for(const polarity of [1,-1])for(let i=-steps;i<=steps;i++){
    const tauMs=i*stepMs,s=score(tauMs,polarity);if(s<peakScore-.002)continue;
    const rank=Math.abs(tauMs)+(polarity<0?.005:0);
    if(!chosen||rank<chosen.rank||(rank===chosen.rank&&s>chosen.score))chosen={tauMs,polarity,score:s,rank};
  }
  const baselineScore=score(0,1),improvement=Math.max(0,chosen.score-baselineScore);
  const nearest=points.reduce((best,p)=>Math.abs(p.f-crossoverHz)<Math.abs(best.f-crossoverHz)?p:best,points[0]);
  const wrapDeg=rad=>{let d=rad*180/Math.PI;while(d>180)d-=360;while(d<-180)d+=360;return d;};
  const beforeDeg=wrapDeg(nearest.pt-nearest.ps);
  const afterDeg=wrapDeg(nearest.pt-nearest.ps-2*Math.PI*nearest.f*chosen.tauMs/1000+(chosen.polarity<0?Math.PI:0));
  const balanceConfidence=Math.min(1,meanBalance/.5);
  const confidence=Math.max(0,Math.min(1,meanCoh*(.45+.55*Math.min(1,coverage))*balanceConfidence));
  const reliable=coverage>=.32&&meanCoh>=coherenceGate&&confidence>=.42;
  const noChange=chosen.polarity>0&&Math.abs(chosen.tauMs)<.08&&(improvement<.3||Math.abs(afterDeg)<30);
  return {
    reliable,reason:reliable?'':'הקוהרנטיות או איזון העוצמות באזור החיתוך אינם מספיקים',
    delayTarget:chosen.tauMs>.04?'top':chosen.tauMs<-.04?'sub':null,
    delayMs:Math.abs(chosen.tauMs),polarityInverted:chosen.polarity<0,noChange,
    improvementDb:improvement,currentScore:baselineScore,optimizedScore:chosen.score,
    beforeDeg,afterDeg,confidence,coverage,meanCoh,meanBalance,points:points.length,
    band:{lo:fLo,hi:fHi},crossoverHz
  };
}

function scheduleAlignBarResize(){
  setTimeout(()=>{
    const bar=document.getElementById('alignBar'),stage=document.getElementById('stage');
    if(!alignOn||!bar||!stage)return;
    stage.style.setProperty('--bar-h',bar.offsetHeight+'px');
    if(typeof resize==='function')resize();
  },0);
}
function updateAlignmentRecommendation(){
  const el=document.getElementById('phRecommendation');if(!el)return;
  el.classList.remove('ready','warn');
  if(!phaseSub||!phaseTop){
    alignRecommendation=null;
    if(!tfDelayReady) el.innerHTML='<strong>שלב 1:</strong><span>השאר טופ בלבד ובצע סנכרון TF</span>';
    else if(!phaseSub) el.innerHTML='<strong>שלב 2:</strong><span>השתק טופ, לחץ מדוד סאב ובחר רעש ורוד פנימי או מקור חיצוני</span>';
    else el.innerHTML='<strong>שלב 3:</strong><span>השתק סאב, לחץ מדוד טופ ובחר את אותו מקור אות</span>';
    scheduleAlignBarResize();
    return;
  }
  const sr=(phaseSub.sr||phaseTop.sr||(audioCtx&&audioCtx.sampleRate)||48000);
  const rec=optimizeSubTopAlignment(phaseSub,phaseTop,sr,xoverF,tfCohGate,{maxDelayMs:20,stepMs:.02});
  alignRecommendation=rec;
  const range=Math.round(rec.band.lo)+'–'+Math.round(rec.band.hi)+'Hz';
  if(!rec.reliable){
    el.classList.add('warn');
    el.innerHTML='<strong>אין המלצה אמינה</strong><span>'+rec.reason+'</span><span class="phRecMeta">'+range+' · '+Math.round((rec.meanCoh||0)*100)+'% קוהרנטיות</span>';
    scheduleAlignBarResize();
    return;
  }
  const confidence=Math.round(rec.confidence*100),improvement=rec.improvementDb>12?'>12':rec.improvementDb.toFixed(1);
  if(rec.noChange){
    el.classList.add('ready');
    el.innerHTML='<strong>✓ הסאב והטופ כבר מיושרים</strong><span>אין צורך לשנות דיליי או פולריות</span><span class="phRecMeta">'+range+' · Δφ צפוי '+rec.afterDeg.toFixed(0)+'° · אמינות '+confidence+'%</span>';
    scheduleAlignBarResize();
    return;
  }
  const actions=[];
  actions.push(rec.polarityInverted?'הפוך פולריות בסאב':'השאר פולריות רגילה');
  if(rec.delayTarget)actions.push('הוסף '+rec.delayMs.toFixed(2)+'ms ל'+(rec.delayTarget==='sub'?'סאב':'טופ'));
  else actions.push('ללא תוספת דיליי');
  el.classList.add('ready');
  el.innerHTML='<strong>'+actions.join(' · ')+'</strong><span>שיפור צפוי '+improvement+'dB · אחרי השינוי מדוד מחדש כל מקור ששונה</span><span class="phRecMeta">'+range+' · Δφ '+rec.beforeDeg.toFixed(0)+'°→'+rec.afterDeg.toFixed(0)+'° · אמינות '+confidence+'%</span>';
  scheduleAlignBarResize();
}

function tfPhaseSnapshot(){
  const n=TF_FFT_N/2, ph=new Float32Array(n), coh=new Float32Array(n), mag=new Float32Array(n);
  for(let k=0;k<n;k++){
    ph[k]=Math.atan2(tfPxyIm[k], tfPxyRe[k]);
    const pxySq=tfPxyRe[k]*tfPxyRe[k]+tfPxyIm[k]*tfPxyIm[k];
    coh[k]=Math.max(0,Math.min(1, pxySq/(tfPxx[k]*tfPyy[k]+1e-12)));
    mag[k]=20*Math.log10(Math.hypot(tfPxyRe[k],tfPxyIm[k])/(tfPxx[k]+1e-12)+1e-12);
  }
  return {ph,coh,mag,sr:audioCtx?audioCtx.sampleRate:48000,fftN:TF_FFT_N};
}
let phMeasuring=false,phMeasureTimer=null;
function syncSubTopWorkflowUi(){
  const sync=document.getElementById('phSyncBtn');
  const sub=document.getElementById('phSubBtn');
  const top=document.getElementById('phTopBtn');
  if(sync){
    sync.classList.toggle('on',tfDelayReady);
    sync.textContent=tfDelayReady?'✓ 1 · TF '+tfDelayMs.toFixed(2)+'ms':'1 · סנכרון TF';
    sync.disabled=phMeasuring;
  }
  if(sub){
    if(!phaseSub)sub.textContent='2 · מדוד סאב';
    sub.disabled=phMeasuring||!tfDelayReady;
  }
  if(top){
    if(!phaseTop)top.textContent='3 · מדוד טופ';
    top.disabled=phMeasuring||!tfDelayReady||!phaseSub;
  }
}
function clearSubTopSnapshots(message){
  if(phMeasureTimer){clearInterval(phMeasureTimer);phMeasureTimer=null;}
  phMeasuring=false;phaseSub=null;phaseTop=null;showXover=false;alignRecommendation=null;
  const s=document.getElementById('phSubBtn');if(s)s.classList.remove('on');
  const t=document.getElementById('phTopBtn');if(t)t.classList.remove('on');
  const st=document.getElementById('phStatus');if(st){st.textContent=message||'מדוד סאב ואז טופ — בכל שלב בחר רעש ורוד פנימי או מקור חיצוני.';st.style.color='var(--dim)';}
  syncSubTopWorkflowUi();
  updateAlignmentRecommendation();
}
function capturePhase(which){
  if(!analyser || !analyserRef){ alert('פאזה דורשת מדידת מיק/רפרנס פעילה (רפרנס בערוץ 2).'); return; }
  if(measureBusy()){ alert('מדידה אחרת פעילה — המתן לסיומה.'); return; }
  if(!tfDelayReady){ alert('תחילה בצע את שלב 1 — סנכרון TF.'); return; }
  if(which==='top'&&!phaseSub){ alert('תחילה בצע את שלב 2 — מדידת הסאב לבדו.'); return; }
  phMeasuring=true;
  const btn=document.getElementById(which==='sub'?'phSubBtn':'phTopBtn');
  const other=document.getElementById(which==='sub'?'phTopBtn':'phSubBtn');
  const st=document.getElementById('phStatus');
  const label=which==='sub'?'סאב':'טופ';
  if(which==='sub')phaseSub=null;else phaseTop=null;
  alignRecommendation=null;
  if(btn)btn.classList.remove('on');
  syncSubTopWorkflowUi();
  updateAlignmentRecommendation();
  // אפס צוברים לחלון מדידה נקי
  tfPxx.fill(0); tfPyy.fill(0); tfPxyRe.fill(0); tfPxyIm.fill(0);
  let t=3;
  const tick=()=>{ if(btn) btn.textContent='מודד… '+t; if(st){ st.textContent='מודד '+label+'… '+t+' שניות'; st.style.color='var(--accent)'; } };
  tick();
  phMeasureTimer=setInterval(()=>{
    t--;
    if(t>0){ tick(); return; }
    clearInterval(phMeasureTimer);phMeasureTimer=null;
    const snap=tfPhaseSnapshot();
    if(which==='sub') phaseSub=snap; else phaseTop=snap;
    showXover=true;
    const N2=TF_FFT_N/2, nyq=(typeof audioCtx!=='undefined'&&audioCtx)?audioCtx.sampleRate/2:24000;
    const k=Math.min(N2-1, Math.round(xoverF/nyq*N2));
    const c=snap.coh[k];
    if(btn){ btn.classList.add('on'); btn.textContent='✓ '+(which==='sub'?'2':'3')+' · '+label+' נלכד'; }
    if(st){
      if(c>=0.5){ st.textContent='✓ '+label+' נלכד · קוהרנטיות '+c.toFixed(2)+' — אמין'; st.style.color='#22c55e'; }
      else { st.textContent='⚠ '+label+' נלכד · קוהרנטיות '+c.toFixed(2)+' נמוכה — קרב מיק׳/העלה רמה ומדוד שוב'; st.style.color='#f59e0b'; }
    }
    phMeasuring=false;
    syncSubTopWorkflowUi();
    updateAlignmentRecommendation();
  },1000);
}
safeOn('phSubBtn','click',()=>pickSource(()=>capturePhase('sub'),3200,{title:'אות למדידת הסאב לבדו',allowed:['pink','external']}));
safeOn('phTopBtn','click',()=>pickSource(()=>capturePhase('top'),3200,{title:'אות למדידת הטופ לבדו',allowed:['pink','external']}));
safeOn('phClearBtn','click',function(){
  clearSubTopSnapshots();
});
safeOn('xoverF','input',function(e){
  xoverF=parseInt(e.target.value,10);
  const t=document.getElementById('xoverFVal'); if(t) t.textContent=xoverF+' Hz';
  updateAlignmentRecommendation();
});

const SAVE_KEY='rta_saves';
let saves=[];
function loadSaves(){ try{ const r=lsGet(SAVE_KEY); saves=r?JSON.parse(r):[]; }catch(_){ saves=[]; } }
function persistSaves(){ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(saves)); }catch(_){ alert('לא ניתן לשמור (אחסון מלא או חסום).'); } }
function snapshotState(name){
  return {
    id:'s'+Date.now(), name:name, date:new Date().toISOString().slice(0,10),
    target:targetMode,
    positions:eqPositions.map(p=>({name:p.name, db:Array.from(p.db)})),
    areas:areas.map(a=>({name:a.name, color:a.color, db:Array.from(a.db), show:a.show})),
    speakers:dlySpeakers.map(s=>({name:s.name, ms:s.ms})),
    anchor:dlyAnchor,
    calName: micCal ? (micCalList.find(c=>c.id===activeCalId)||{}).name||null : null
  };
}
function renderSaveList(){
  const box=document.getElementById('saveList'); if(!box) return;
  if(!saves.length){ box.innerHTML='<div class="sub">אין מדידות שמורות עדיין.</div>'; return; }
  box.innerHTML=saves.map(s=>{
    const bits=[];
    if(s.positions&&s.positions.length) bits.push(s.positions.length+' מיקומים');
    if(s.areas&&s.areas.length) bits.push(s.areas.length+' אזורים');
    if(s.speakers&&s.speakers.some(x=>x.ms!=null)) bits.push('דיליי');
    return '<div class="saveRow"><span class="nm" title="'+escapeHtml(s.name)+'">'+escapeHtml(s.name)+
      '</span><span class="meta">'+s.date+(bits.length?' · '+bits.join(' · '):'')+'</span>'+
      '<button data-load="'+s.id+'">טען</button><button data-rm="'+s.id+'">מחק</button></div>';
  }).join('');
  box.querySelectorAll('[data-load]').forEach(b=>b.addEventListener('click',()=>loadSave(b.dataset.load)));
  box.querySelectorAll('[data-rm]').forEach(b=>b.addEventListener('click',()=>{
    const s=saves.find(x=>x.id===b.dataset.rm);
    if(!confirm('למחוק את "'+(s?s.name:'')+'"?')) return;
    saves=saves.filter(x=>x.id!==b.dataset.rm); persistSaves(); renderSaveList();
  }));
}
function loadSave(id){
  const s=saves.find(x=>x.id===id); if(!s) return;
  if(measureBusy()){ alert('מדידה פעילה — המתן לסיומה.'); return; }
  if((eqPositions.length||areas.length) && !confirm('לטעון "'+s.name+'"? המדידות הנוכחיות יוחלפו.')) return;
  eqPositions=(s.positions||[]).map(p=>{
    if(p.db) return {name:p.name, db:Float32Array.from(p.db)};
    if(p.data && audioCtx){
      const bd=p.data, bins=bd.length, nyq=audioCtx.sampleRate/2, R6=Math.pow(2,1/6);
      const db=GEQ.map(fc=>bandDbFromBins(bd, fc/R6, fc*R6, nyq, bins));
      return {name:p.name, db:Float32Array.from(db)};
    }
    return {name:p.name, db:new Float32Array(GEQ.length).fill(-120)};
  });
  areas=(s.areas||[]).map(a=>({name:a.name, color:a.color, db:Float32Array.from(a.db), show:a.show!==false}));
  if(s.speakers&&s.speakers.length){ dlySpeakers=s.speakers.map(x=>({name:x.name, ms:x.ms})); dlyAnchor=s.anchor||0; }
  if(s.target) setTarget(s.target);
  renderEqList(); renderDlySpk(); updateEqUI();
  if(eqPositions.length) computeAndShow();
  if(areas.length){ renderAreaList(); suggestAreaEQ(); }
  closeModals();
  if(s.calName && (!micCal || (micCalList.find(c=>c.id===activeCalId)||{}).name!==s.calName))
    alert('שים לב: המדידה נשמרה עם כיול "'+s.calName+'". ודא שאותו כיול פעיל.');
}
safeOn('saveBtn', 'click',()=>{ renderSaveList(); showModal(savePanel); });
safeOn('saveClose', 'click',closeModals);
safeOn('saveNowBtn', 'click',()=>{
  const inp=document.getElementById('saveName');
  const name=(inp.value||'').trim();
  if(!name){ alert('תן שם למדידה.'); inp.focus(); return; }
  if(!eqPositions.length && !areas.length && !dlySpeakers.some(s=>s.ms!=null)){
    alert('אין מה לשמור — בצע מדידה קודם.'); return; }
  saves.unshift(snapshotState(name));
  if(saves.length>40) saves=saves.slice(0,40);
  persistSaves(); renderSaveList(); inp.value='';
});
loadSaves();


function v3Toast(msg){
  const el=document.getElementById('shortcutToast'); if(!el) return;
  el.textContent=msg; el.classList.add('show');
  clearTimeout(_v3ToastTimer);
  _v3ToastTimer=setTimeout(()=>el.classList.remove('show'),1200);
}
function v3UpdateStatus(){
  const a=document.getElementById('v3AudioChip');
  const c=document.getElementById('v3CalChip');
  const r=document.getElementById('v3ResChip');
  if(a){
    if(running && audioCtx){
      const sr=Math.round(audioCtx.sampleRate/100)/10;
      a.textContent='Audio: '+sr+'k · '+fftSize;
      a.className='v3Chip live';
    }else{
      a.textContent='Audio: כבוי';
      a.className='v3Chip';
    }
  }
  if(c){
    if(meterUnit==='dBFS'){
      c.textContent='CAL: dBFS';
      c.className='v3Chip ok';
    }else if(calib!==0 || micCal){
      const micName=micCal ? ((micCalList.find(x=>x.id===activeCalId)||{}).name||'Mic') : null;
      c.textContent=micName ? 'CAL: '+micName : 'CAL: '+(calib>=0?'+':'')+calib+'dB';
      c.className='v3Chip ok';
    }else{
      c.textContent='CAL: SPL לא מכויל';
      c.className='v3Chip warn';
    }
  }
  if(r){
    r.textContent='RTA 1/'+curBpo+' ▾';
    r.className='v3Chip';
  }
}
function v3ToggleButton(id){
  const el=document.getElementById(id); if(el) el.click();
}
document.addEventListener('keydown',e=>{
  const t=e.target;
  if(t && (t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT'||t.isContentEditable)) return;
  if(e.ctrlKey||e.metaKey||e.altKey) return;
  const k=e.key.toLowerCase();
  if(k===' '){ e.preventDefault(); v3ToggleButton('freezeBtn'); v3Toast(frozen?'תצוגה מוקפאת':'תצוגה חיה'); }
  else if(k==='p'){ v3ToggleButton('peakBtn'); v3Toast(peakHold?'Peak Hold פעיל':'Peak Hold כבוי'); }
  else if(k==='a'){ v3ToggleButton('avgBtn'); v3Toast(avgOn?'מיצוע פעיל':'מיצוע כבוי'); }
  else if(k==='r'){ const el=document.getElementById('resetPeakBtn'); if(el) el.click(); }
  else if(k==='f'){ const z=document.getElementById('zoomBtn'); if(z && z.style.display!=='none') z.click(); }
  else if(k==='g'){ v3ToggleButton('genBtn'); v3Toast('Generator'); }
  else if(k==='s'){ v3ToggleButton('saveBtn'); }
});

(function initPrefs(){
  const applyInput=(id,key)=>{ const v=lsGet(key); if(v==null) return; const el=document.getElementById(id); if(!el) return; el.value=v; el.dispatchEvent(new Event('input')); };
  applyInput('res','rta_res');
  applyInput('smooth','rta_smooth');
  applyInput('floor','rta_floor');
  applyInput('cal','rta_cal');
  applyInput('fbSens','rta_fbSens');
  const fft=lsGet('rta_fft');
  if(fft){ const btn=document.querySelector('#fftSeg button[data-n="'+fft+'"]'); if(btn) btn.click(); }
  const tgt=lsGet('rta_target');
  if(tgt) setTarget(tgt);
  const wgt=lsGet('rta_wgt');
  if(wgt && wgt!=='Z'){ weightMode=wgt; const wb=document.getElementById('wgtBtn');
    wb.textContent='dB'+wgt; wb.classList.add('on'); document.getElementById('wLbl').textContent=wgt; }
  const sm = lsGet('rta_sunmode');
  if(sm === '1'){ sunMode = true; document.body.classList.add('sun-mode'); const sb = document.getElementById('sunBtn'); if(sb) sb.classList.add('on'); }
  const aa=parseFloat(lsGet('rta_avg_alpha'));
  if(Number.isFinite(aa)){
    avgAlpha=Math.max(0.5,Math.min(0.995,aa));
    document.querySelectorAll('#avgSpeedSeg button').forEach(b=>b.classList.toggle('on', Math.abs(parseFloat(b.dataset.a)-avgAlpha)<0.001));
  }
  setEqCorrectionRange(parseFloat(lsGet('rta_eq_min')),parseFloat(lsGet('rta_eq_max')),false);
  try{localStorage.removeItem('rta_tf_delay');}catch(_){}
  resetTfAutoDelay();
  const ver=document.getElementById('ver'); if(ver) ver.textContent='V5.5.1';
  v3UpdateStatus();
})();
(function initAccent(){
  const saved=lsGet('rta_accent');
  if(saved){ applyAccent(saved);
    document.querySelectorAll('#swatches .sw').forEach(b=>b.classList.toggle('on', b.dataset.c===saved)); }
})();
document.querySelectorAll('#swatches .sw').forEach(b=>b.addEventListener('click',function(){
  document.querySelectorAll('#swatches .sw').forEach(x=>x.classList.remove('on'));
  this.classList.add('on'); applyAccent(this.dataset.c);
}));

const sigTint=document.getElementById('sigTint');
let _lastTint='';
function updateSignalTint(){
  if(!genOn){ if(_lastTint!==''){ sigTint.classList.remove('on'); _lastTint=''; } return; }
  let rgb=null;
  if(genType==='white') rgb='rgba(235,242,250,.16)';
  else if(genType==='pink') rgb='rgba(255,120,180,.16)';
  else if(genType==='sweep'){
    const now=audioCtx?audioCtx.currentTime:0, t=((now-(sweepStartT||now))%genSweepDur)/genSweepDur;
    const hue=250-250*Math.max(0,Math.min(1,t));
    rgb='hsla('+Math.round(hue)+',90%,60%,.16)';
  }
  if(rgb){ if(rgb!==_lastTint){ sigTint.style.boxShadow='inset 0 0 140px 30px '+rgb; _lastTint=rgb; } sigTint.classList.add('on'); }
  else if(_lastTint!==''){ sigTint.classList.remove('on'); _lastTint=''; }
}

/* ===== V5 Pro Workspace ===== */
let v5WorkspaceMode='rta';


function v5SyncTargetToggle(){
  const b=document.getElementById('v5TargetToggle'); if(!b)return;
  b.classList.toggle('on',targetVisible);
  b.textContent=targetVisible?'Target ✓':'Target';
  b.title=targetVisible?'הסתר את עקומת היעד':'הצג את עקומת היעד';
}

function v5SetTab(mode){
  v5WorkspaceMode=mode;
  document.querySelectorAll('#v5ModeTabs [data-v5mode]').forEach(b=>b.classList.toggle('on',b.dataset.v5mode===mode));
  const ag=document.getElementById('v53AnalysisGroup');if(ag)ag.classList.toggle('on',mode==='analysis');
}
function v54SetSideRail(open){
  const isOpen=!!open;
  document.body.classList.toggle('v54-rail-collapsed',!isOpen);
  prefSet('v54_side_rail_open',isOpen?'1':'0');
  const button=document.getElementById('v54SideToggle');
  if(button){
    button.textContent=isOpen?'‹':'›';
    button.title=isOpen?'הסתר סרגל צד':'הצג סרגל צד';
    button.setAttribute('aria-label',button.title);
  }
  setTimeout(resize,0);
}
function v54SetAnalysisView(view,event){
  if(event){event.preventDefault();event.stopImmediatePropagation();}
  closeModals();setAlign(false);setTfOverlay(false);setMode(view);v5SetTab('analysis');
  document.getElementById('v53AnalysisToggle')?.classList.toggle('on',view==='rta');
  document.getElementById('v54WaterfallToggle')?.classList.toggle('on',view==='spec');
}
function v5OpenTf(extra){
  setMode('rta');
  setTfOverlay(true);
  showModal(tfPanel);
  if(extra==='phase'){
    tfShowPhase=true;
    const p=document.getElementById('tfPhaseToggleBtn'); if(p)p.classList.add('on');
    const q=document.getElementById('qbPhase'); if(q)q.classList.add('on');
  }
  if(extra==='coh'){
    tfShowCoh=true;
    const p=document.getElementById('tfCohToggleBtn'); if(p)p.classList.add('on');
    const q=document.getElementById('qbCoh'); if(q)q.classList.add('on');
  }
}
function v5SyncRail(){
  const pk=document.getElementById('peakHz');
  const out=document.getElementById('v5PeakValue');
  if(pk&&out) out.textContent=pk.textContent||'—';

  const spl=document.getElementById('splNow');
  const splSide=document.getElementById('v5SplSide');
  if(spl&&splSide) splSide.textContent='SPL '+(spl.textContent||'—');

  const calState=document.getElementById('v5CalState');
  const calVal=document.getElementById('v5CalValue');
  if(calState&&calVal){
    if(micCal){
      const active=(micCalList.find(x=>x.id===activeCalId)||{}).name||'Mic CAL';
      calState.textContent='CALIBRATED';
      calState.style.color='#45d47b';
      calVal.textContent=active.length>18?active.slice(0,18)+'…':active;
    }else if(meterUnit==='dBFS'){
      calState.textContent='DIGITAL LEVEL';
      calState.style.color='var(--accent)';
      calVal.textContent='dBFS';
    }else{
      calState.textContent='SPL NOT CALIBRATED';
      calState.style.color='var(--warn)';
      calVal.textContent=(calib>=0?'+':'')+calib.toFixed(1)+' dB';
    }
  }

  const mic=document.getElementById('v5MicStatus');
  const inp=document.getElementById('v5InputStatus');
  const lat=document.getElementById('v5LatencyStatus');
  if(mic){
    mic.textContent=running?'● Mic: On':'● Mic: Off';
    mic.classList.toggle('live',running);
  }
  if(inp) inp.textContent=analyserRef?'Input: 2ch':'Input: 1ch';
  if(lat) lat.textContent=audioCtx?('Audio: '+Math.round(audioCtx.sampleRate/1000)+'k / '+fftSize):'Audio: —';
}
function v5RenderTraceRail(){
  const box=document.getElementById('v5TraceList'); if(!box)return;
  if(!tfTraces.length){
    box.innerHTML='<div class="v5Minor" style="padding:8px 4px">No captured traces</div>';
    return;
  }
  box.innerHTML=tfTraces.map((t,i)=>
    '<div class="v5TraceRow" data-trace="'+i+'">'+
      '<span class="v5TraceNum">'+(i+1)+'</span>'+
      '<span class="v5TraceName" title="לחץ פעמיים לשינוי שם" style="color:'+t.color+'">'+escapeHtml(t.name)+'</span>'+
      '<button class="v5TraceAction'+(t.visible===false?' off':'')+'" data-trace-eye="'+i+'" title="הצג/הסתר">◉</button>'+
      '<button class="v5TraceAction" data-trace-del="'+i+'" title="מחק">×</button>'+
    '</div>').join('');
  box.querySelectorAll('[data-trace-eye]').forEach(b=>b.addEventListener('click',()=>{const t=tfTraces[+b.dataset.traceEye];if(!t)return;t.visible=t.visible===false;renderTfTraceLegend();}));
  box.querySelectorAll('[data-trace-del]').forEach(b=>b.addEventListener('click',()=>{tfTraces.splice(+b.dataset.traceDel,1);renderTfTraceLegend();v3Toast('Trace נמחק');}));
  box.querySelectorAll('.v5TraceName').forEach((n,i)=>n.addEventListener('dblclick',()=>{const t=tfTraces[i];if(!t)return;const name=prompt('שם חדש ל-Trace',t.name);if(name&&name.trim()){t.name=name.trim().slice(0,40);renderTfTraceLegend();}}));
}
function v5InitWorkspace(){
  const tv=lsGet('rta_target_visible');
  if(tv!==null) targetVisible=(tv!=='0');
  const railPref=lsGet('v54_side_rail_open');
  if(railPref==='0') v54SetSideRail(false);
  v5SyncTargetToggle();
  document.querySelectorAll('#v5ModeTabs [data-v5mode]').forEach(b=>b.addEventListener('click',()=>{
    const m=b.dataset.v5mode; v5SetTab(m);
    if(m==='analysis'){ closeModals(); setAlign(false); setTfOverlay(false); setMode(mode==='spec'?'spec':'rta'); }
    else if(m==='tf'){ setAlign(false); v5OpenTf(); }
    else if(m==='delay'){ setAlign(false); showModal(dlyPanel); }
    else if(m==='rt60'){ setAlign(false); showModal(rtPanel); }
    else if(m==='spleq'){ setAlign(false); showModal(eqPanel); updateEqUI(); }
    else if(m==='align'){ closeModals(); setTfOverlay(false); setMode('rta'); setAlign(true); }
  }));

  safeOn('v5TargetToggle','click',()=>{
    targetVisible=!targetVisible;
    prefSet('rta_target_visible', targetVisible?'1':'0');
    v5SyncTargetToggle();
    v3Toast(targetVisible?'עקומת יעד מוצגת על הגרף':'עקומת יעד מוסתרת');
  });
  safeOn('v54SideToggle','click',()=>v54SetSideRail(document.body.classList.contains('v54-rail-collapsed')));

  safeOn('v5AddTrace','click',captureWorkspaceTrace);
  safeOn('v5ResetSession','click',()=>{
    if(confirm('לאפס את הסשן? הפעולה תנקה מדידות, Traces ותוצאות EQ.')){resetSession();v3Toast('הסשן אופס');}
  });

  // Header TF button now opens the working TF dock instead of only overlaying lines.
  const oldTf=document.getElementById('tfOverlayHdr');
  if(oldTf){
    oldTf.addEventListener('click',e=>{
      e.stopImmediatePropagation(); e.preventDefault();
      v5SetTab('tf'); v5OpenTf();
    },true);
  }

  // Mirror the important live values into the persistent rail.
  const watchIds=['peakHz','splNow','calVal'];
  watchIds.forEach(id=>{
    const el=document.getElementById(id);
    if(el) new MutationObserver(v5SyncRail).observe(el,{subtree:true,characterData:true,childList:true});
  });
  v5RenderTraceRail();
  v5SyncRail();
  setInterval(v5SyncRail,900);
}
setTimeout(v5InitWorkspace,0);


/* ===== V5.2 Clean Bottom Bar + I/O Dock ===== */
let v52IoOpen=false;
let v52MeasDbfs=-120, v52RefDbfs=-120;
let v52MeasPeakDbfs=-120, v52RefPeakDbfs=-120, v52PeakAt=0;

function v52SetIo(open){
  v52IoOpen=!!open;
  const dock=document.getElementById('v52IODock');
  const stage=document.getElementById('stage');
  const btn=document.getElementById('v52IoBtn');
  if(dock) dock.classList.toggle('open',v52IoOpen);
  if(stage){
    stage.classList.toggle('v52-io-open',v52IoOpen);
    requestAnimationFrame(()=>{
      if(v52IoOpen && dock) stage.style.setProperty('--v52-io-h',Math.ceil(dock.getBoundingClientRect().height)+'px');
      else stage.style.removeProperty('--v52-io-h');
      if(typeof resize==='function')resize();
    });
  }
  if(btn) btn.classList.toggle('on',v52IoOpen);
  if(v52IoOpen){
    if(genPanel.classList.contains('open'))v53SetGeneratorDock(false);
    closeModals();
    setAlign(false);
    v52RefreshDevices();
  }
}

async function v52RefreshDevices(){
  const sel=document.getElementById('v52DeviceSelect'); if(!sel || !navigator.mediaDevices?.enumerateDevices)return;
  try{
    const devs=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput');
    const cur=sel.value;
    sel.innerHTML='';
    if(!devs.length){
      const o=document.createElement('option');o.textContent='Default browser input';o.value='';sel.appendChild(o);
    }else{
      devs.forEach((d,i)=>{
        const o=document.createElement('option');
        o.value=d.deviceId;o.textContent=d.label||('Audio Input '+(i+1));sel.appendChild(o);
      });
      if([...sel.options].some(o=>o.value===cur))sel.value=cur;
    }
  }catch(e){}
}

function v52DbToPct(db){
  if(!Number.isFinite(db))return 0;
  return Math.max(0,Math.min(100,(db+72)/72*100));
}
function v52UpdateLiveMeters(){
  if(!running) return;
  const now=performance.now();
  const meas=Number.isFinite(smoothedDbfs)?smoothedDbfs:-120;
  let ref=-120;
  if(analyserRef){
    if(!timeDataRef || timeDataRef.length!==analyserRef.fftSize) timeDataRef=new Float32Array(analyserRef.fftSize);
    analyserRef.getFloatTimeDomainData(timeDataRef);
    ref=levelDb(timeDataRef,timeDataRef.length);
  }
  const smooth=(old,next)=>next>old ? old+(next-old)*.62 : old+(next-old)*.055;
  v52MeasDbfs=smooth(v52MeasDbfs,meas);
  v52RefDbfs=smooth(v52RefDbfs,ref);
  if(v52MeasDbfs>v52MeasPeakDbfs || now-v52PeakAt>1400) v52MeasPeakDbfs=v52MeasDbfs;
  if(v52RefDbfs>v52RefPeakDbfs || now-v52PeakAt>1400) v52RefPeakDbfs=v52RefDbfs;
  if(now-v52PeakAt>1400) v52PeakAt=now;
  const paint=(fill,peak,value,quick,db,peakDb)=>{
    if(fill){fill.style.width=v52DbToPct(db)+'%';fill.classList.toggle('clip',db>-1);}
    if(peak)peak.style.left=v52DbToPct(peakDb)+'%';
    if(value)value.textContent=db.toFixed(1)+' dBFS';
    if(quick)quick.textContent=db.toFixed(1)+' dB';
  };
  paint(document.getElementById('v52MeasMeter'),document.getElementById('v52MeasPeak'),document.getElementById('v52MeasDb'),document.getElementById('v52MeasQuick'),v52MeasDbfs,v52MeasPeakDbfs);
  paint(document.getElementById('v52RefMeter'),document.getElementById('v52RefPeak'),document.getElementById('v52RefDb'),document.getElementById('v52RefQuick'),v52RefDbfs,v52RefPeakDbfs);
  const ml=document.getElementById('v52MeasLed'), rl=document.getElementById('v52RefLed');
  if(ml){ml.classList.toggle('live',true);ml.classList.toggle('clip',v52MeasDbfs>-1);}
  if(rl){rl.classList.toggle('live',!!analyserRef);rl.classList.toggle('clip',v52RefDbfs>-1);}
}
function v52UpdateUi(){
  if(running) v52UpdateLiveMeters();

  const sr=audioCtx?audioCtx.sampleRate:0;
  const srq=document.getElementById('v52SrQuick'); if(srq)srq.textContent=sr?(Math.round(sr/100)/10+' kHz'):'— kHz';
  const srf=document.getElementById('v52SampleRate'); if(srf)srf.value=sr?(sr+' Hz'):'—';
  const fq=document.getElementById('v52FftQuick'); if(fq)fq.textContent='FFT '+fftSize;

  const calq=document.getElementById('v52CalQuick');
  if(calq)calq.textContent=micCal?'CAL ✓':(meterUnit==='dBFS'?'dBFS':'CAL '+(calib>=0?'+':'')+calib.toFixed(1));
  const mc=document.getElementById('v52MicCalState');
  if(mc){
    const active=(micCalList.find(x=>x.id===activeCalId)||{}).name;
    mc.textContent=micCal?(active||'Loaded'):'None';
    mc.style.color=micCal?'#6fd994':'';
  }
  const sc=document.getElementById('v52SplCalState'); if(sc)sc.textContent=(calib>=0?'+':'')+calib.toFixed(1)+' dB';
  const so=document.getElementById('v53SplOffset');if(so&&document.activeElement!==so)so.value=String(calib);
  const us=document.getElementById('v52UnitState'); if(us)us.textContent=meterUnit;
  const as=document.getElementById('v52AudioState'); if(as){as.textContent=running?'Running':'Stopped';as.style.color=running?'#6fd994':'';}

  const fs=document.getElementById('v52FftSelect'); if(fs && document.activeElement!==fs)fs.value=String(fftSize);
  const rs=document.getElementById('v52ResSelect'); if(rs && document.activeElement!==rs)rs.value=String(curBpo);

  const fr=document.getElementById('v52FreezeBtn'); if(fr)fr.classList.toggle('on',frozen);
}

function v52Init(){
  const micArea=document.getElementById('v53MicCalArea');
  if(micArea&&calPanel)micArea.appendChild(calPanel);
  safeOn('v52IOClose','click',()=>v52SetIo(false));
  safeOn('v52FreezeBtn','click',()=>{const b=document.getElementById('freezeBtn');if(b)b.click();setTimeout(v52UpdateUi,0);});
  safeOn('v52CaptureBtn','click',()=>{const b=document.getElementById('saveBtn');if(b)b.click();});
  window.v53ToggleMicCal=function(){
    if(!micArea)return;
    const open=!micArea.classList.contains('open');
    micArea.classList.toggle('open',open);
    const button=document.getElementById('v52OpenMicCal');if(button)button.classList.toggle('on',open);
    if(open){renderCalList();requestAnimationFrame(()=>{micArea.scrollIntoView({block:'nearest',behavior:'smooth'});const d=document.getElementById('v52IODock'),s=document.getElementById('stage');if(d&&s)s.style.setProperty('--v52-io-h',Math.ceil(d.getBoundingClientRect().height)+'px');resize();});}
    else {requestAnimationFrame(()=>resize());}
  };
  const calClose=document.getElementById('calClose');if(calClose)calClose.addEventListener('click',e=>{e.stopImmediatePropagation();if(micArea)micArea.classList.remove('open');resize();},true);
  safeOn('v52OpenOldIo','click',()=>{
    const card=document.getElementById('v53AdvancedIo')?.closest('.v52IOCard');
    if(card)card.classList.toggle('advanced-open');
  });
  safeOn('v52UnitToggle','click',()=>{
    const next=meterUnit==='dBFS'?'SPL':'dBFS';
    const b=[...document.querySelectorAll('#unitSeg button')].find(x=>x.dataset.u===next);
    if(b)b.click();
    v52UpdateUi();
  });
  safeOn('v52FftSelect','change',e=>{
    const n=parseInt(e.target.value,10);
    const old=document.getElementById('fft');
    if(old){old.value=String(n);old.dispatchEvent(new Event('change',{bubbles:true}));}
    else setFft(n);
    v52UpdateUi();
  });
  safeOn('v52ResSelect','change',e=>{
    const old=document.getElementById('res');
    if(old){old.value=e.target.value;old.dispatchEvent(new Event('input',{bubbles:true}));}
    v52UpdateUi();
  });
  safeOn('v52DeviceSelect','change',async e=>{activeInId=e.target.value||'';userPickedIn=!!activeInId;if(running)await switchInput(activeInId);else v3Toast('המקור יופעל בלחיצה על הפעל מיקרופון');});
  safeOn('v52MeasSelect','change',async e=>{measChannel=parseInt(e.target.value,10)||0;if(measChannel===refChannel){refChannel=measChannel?0:1;document.getElementById('v52RefSelect').value=String(refChannel);}if(running)await switchInput(activeInId);});
  safeOn('v52RefSelect','change',async e=>{refChannel=parseInt(e.target.value,10)||0;if(refChannel===measChannel){measChannel=refChannel?0:1;document.getElementById('v52MeasSelect').value=String(measChannel);}if(running)await switchInput(activeInId);});
  safeOn('v53SplOffset','input',e=>{calib=parseFloat(e.target.value)||0;const old=document.getElementById('cal');if(old){old.value=String(calib);old.dispatchEvent(new Event('input',{bubbles:true}));}prefSet('rta_cal',calib);v52UpdateUi();});
  safeOn('v53OutputSelect','change',async e=>{const ok=await applyOutput(e.target.value);if(!ok)v3Toast('בחירת פלט אינה נתמכת בדפדפן הזה');});
  safeOn('v53ExportPng','click',()=>document.getElementById('pngBtn')?.click());
  safeOn('v53ExportCsv','click',()=>document.getElementById('csvBtn')?.click());

  if(navigator.mediaDevices?.addEventListener)navigator.mediaDevices.addEventListener('devicechange',v52RefreshDevices);
  v52RefreshDevices();
  populateInputs().then(()=>{
    const old=document.getElementById('outSel'),out=document.getElementById('v53OutputSelect');
    if(old&&out)out.innerHTML=old.innerHTML;
  });
  v52UpdateUi();
  setInterval(v52UpdateUi,500);
}
setTimeout(v52Init,0);

const HELP={
  mRta:'תצוגת ספקטרום — עוצמה לפי תדר, בזמן אמת.',
  mSpec:'ווטרפול — הספקטרום לאורך זמן.',
  sunBtn:'מצב אור שמש: רקע בהיר וניגודיות גבוהה לעבודה בשטח.',
  swatches:'צבע האפליקציה — משנה גם את צבע הברים בגרף.',
  helpBtn:'מצב עזרה: רחף על כל כפתור לקבל הסבר.',
  guideBtn:'מדריך מסודר לכל מדידה ולסדר העבודה המומלץ בשטח.',
  genBtn:'גנרטור אותות: רעש ורוד/לבן, סינוס או סוויפ.\nלמדידה ולכיוונון המערכת.',
  eqBtn:'מדידת תגובה: חד־ערוצי (מיק\' מול יעד)\nאו דו־ערוצי (מיק\'+רפרנס = TF).',
  calBtn:'כיולי מיקרופון: טען קובץ כיול (REW)\nלתיקון צביעת המיקרופון.',
  dlyBtn:'מדידת דיליי: זמן ההשהיה בין רמקולים.\nיישור סאב/טופ עם רמקול עוגן.',
  rtBtn:'RT60: מדידת זמן הדהוד החדר,\nלפי רצועות אוקטבה. דורש חדר אמיתי.',
  wgtBtn:'שקלול המד: dBZ (טכני), dBA (חוק/אוזן),\ndBC (עם בס). לחיצה מחליפה.',
  leqBtn:'אפס Leq: מתחיל מדידת ממוצע עוצמה\nמחדש מהרגע הזה.',
  tfTraceBtn:'לוכד את עקומת ה-TF הנוכחית ומשאיר אותה על הגרף להשוואה למדידה הבאה.',
  tfAutoDelayBtn:'סנכרון TF: מודד שלוש פעמים את הפרש הזמן בין Reference למיקרופון ומיישר את הפאזה. אינו מכוון דיליי בין רמקולים.',
  resetPeakBtn:'איפוס מיידי של כל סימוני ה-Peak Hold.',
  avgSpeedSeg:'קובע כמה מהר המיצוע מגיב לשינויים. מהיר = תגובה זריזה, איטי = תצוגה יציבה.',
  peakBtn:'Peak Hold: משאיר את השיאים על המסך.',
  avgBtn:'מיצוע: מייצב את התצוגה לאורך זמן.',
  meterModeSeg:'מדים: RMS (ממוצע חלק) או Peak (שיאים).\nמשפיע על כל המדים.',
  fftSeg:'FFT: דיוק מול מהירות. מדויק = בס טוב יותר,\nמהיר = ביצועים טובים יותר.',
  freezeBtn:'הקפא: שומר עקומה להשוואה,\nעם סימון תדרי הפיקים.',
  fbBtn:'גלאי פידבק: מזהה תדרים שמתחילים\nלשרוק, עם המלצת חיתוך.',
  stopBtn:'אפס סשן: מנקה מדידות והגדרות\nבלי לכבות את המיקרופון.',
  pngBtn:'ייצוא תמונת מסך (PNG).',
  csvBtn:'ייצוא הנתונים כקובץ CSV.',
  inSel:'מקור קלט: בחר מיקרופון / כרטיס קול.',
  outSel:'יציאת פלט: לאן יוצא אות הגנרטור.',
  genOnBtn:'מפעיל/עוצר את אות הגנרטור.',
  floor:'רצפת רעש: הסף התחתון של התצוגה.',
  cal:'כיול SPL: התאם למד ייחוס\nכדי לקבל dB SPL אמיתי.',
  autoCalBtn:'כיול אוטומטי מול פיסטונפון 1kHz.',
  genLvl:'עוצמת אות הגנרטור. התחל נמוך!',
  genFreq:'תדר הסינוס (סליידר).',
  genFreqNum:'הקלד תדר סינוס מדויק.',
  genSweep:'משך מחזור הסוויפ.',
  smooth:'החלקה: מרכך קפיצות בתצוגה.',
  res:'רזולוציה: פסים לאוקטבה (1/3 עד 1/24).',
  respModeSeg:'חד־ערוצי (מיק\' מול יעד) או\nדו־ערוצי (מיק\'+רפרנס = TF אמיתי).',
  eqModeSeg:'תצוגת התיקון: גרפיק (31 פסים)\nאו פרמטרי (תדר/גיין/Q).',
  tfModeSeg:'תצוגת התיקון: גרפיק או פרמטרי.',
  tgtSeg:'עקומת יעד: שטוח (ניטרלי) או\nHouse (בס מעט מוגבר, טרבל יורד).',
  eqMeasBtn:'מדוד מיקום חדש (5ש\'). מדוד כמה\nמיקומים — התיקון הוא הממוצע.',
  eqResetBtn:'נקה את כל המיקומים.',
  areaMeasBtn:'מדוד אזור חדש (עד 4). להשוואת\nצדדים שונים של המעגל.',
  areaEqBtn:'חשב תיקון EQ ממוצע לכל האזורים.',
  dlyMeasBtn:'מודד שלוש פעמים את זמן הנתיב הכולל. להשוואת רמקולים השתמש רק ב־Δ מול העוגן.',
  dlyLoopbackBtn:'בדיקת חיבור: אותו אות בשתי הכניסות צריך להחזיר תוצאה קרובה ל־0ms.',
  dlyUnitSeg:'בחר תצוגת זמן ב־ms או מרחק משוער במטרים. מטרים דורשים כיול מול מרחק ידוע.',
  dlyKnownDistance:'המרחק המדוד בפועל בין מרכז הרמקול למיקרופון בזמן כיול המרחק.',
  dlyDistanceCalBtn:'הצב את המיקרופון במרחק הידוע ולחץ כאן. הכיול מפחית את זמן המערכת ונפסל אם המרחק שהוזן אינו אפשרי לפי זמן ההגעה שנמדד.',
  dlyCountSeg:'מספר רמקולים ליישור (2/4/6).',
  dlyReset:'נקה את מדידות הדיליי.',
  phSyncBtn:'שלב 1: השאר טופ בלבד. הסנכרון מודד ומפצה את הפרש הנתיבים בין המיקרופון ל־Reference.',
  phSubBtn:'שלב 2: פותח בחירת רעש ורוד פנימי או מקור חיצוני ולוכד שלוש שניות של הסאב לבדו. הטופ חייב להיות מושתק.',
  phTopBtn:'שלב 3: פותח את אותה בחירת אות ולוכד שלוש שניות של הטופ לבדו. הסאב חייב להיות מושתק.',
  xoverF:'תדר החיתוך בפועל. האופטימייזר בודק שליש אוקטבה סביב הערך הזה.',
  phRecommendation:'המלצת יישור המחושבת מטווח החיתוך: רמקול לדיליי, ערך ms, פולריות, שיפור צפוי ואמינות.',
  rtRunBtn:'התחל מדידת RT60 (מנגן רעש ופוסק).',
  rtLevel:'עוצמת המדידה. כוונן לפני שמתחיל.',
  rtRange:'טווח דעיכה נדרש. נמוך יותר = קל\nלמדוד בחדר שקט, פחות מדויק.',
  tfOverlayHdr:'הצג/הסתר את עקומות המיק\' והרפרנס\nיחד על הגרף הראשי.',
  tfOverlayBtn:'משאיר את עקומות המיק\' והרפרנס על הגרף\nהראשי גם כשהפאנל סגור.',
  tfAutoDelayBtn:'סנכרון TF בלבד: מפצה את הפרש נתיבי MIC ו־Reference. מבצעים פעם אחת אחרי שינוי חיבור או מיקום מיקרופון.',
  tfVerifyBtn:'שלב 2: פותח בחירת מקור, מפעיל אות פנימי אם נבחר, אוסף שתי שניות ומאמת פאזה וקוהרנטיות לפני Trace או EQ.',
  tfPhaseToggleBtn:'מציג/מסתיר את גרף הפאזה (ירוק).',
  tfCohToggleBtn:'מציג/מסתיר את גרף הקוהרנטיות (אדום מקווקו).',
  saveBtn:'מדידות שמורות: שמור וטען מדידות\nלפי מקום ותאריך.',
  exportJsonBtn:'ייצוא כל הסשן לקובץ JSON להעברה בין מכשירים.',
  importJsonBtn:'ייבוא קובץ JSON של סשן שמור.',
  refCurveBtn:'שומר את התגובה הנוכחית כעקומת ״לפני״\nכדי להשוות אחרי שינוי EQ.',
  cutOnlySeg:'חיתוך בלבד: EQ מוריד תדרים בלבד,\nבלי הגברות — חוסך הדרוּם ומגן על הדרייברים.',
  geqShowBtn:'הצג/הסתר את תצוגת תיקון ה-EQ\n(בנק הפיידרים מתחת לגרף).',
  combBtn:'בדיקת ביטולי פאזה (comb): מזהה אדוות\nתקופתיות בגרף ומעריך את הפרש הזמן שגורם להן.',
  v3ResChip:'רזולוציית RTA: בחר 1/3, 1/6, 1/12 או 1/24 אוקטבה.',
  v5TargetToggle:'Target: מציג או מסתיר את עקומת היעד על הגרף.',
  v5AddTrace:'Capture Trace: שומר צילום של העקומה הנוכחית להשוואה.',
  v5EqWorkspace:'מציג או מסתיר לחלוטין את תצוגת ה-EQ. החץ שבתוך הפאנל מיועד רק לקיפול התוכן.',
  v5ResetSession:'מאפס מדידות, Traces ותוצאות EQ לאחר בקשת אישור.',
  v54SideToggle:'פותח או סוגר את סרגל המדידות בצד שמאל.',
  v52IoBtn:'I/O: בחירת כרטיס קול, ערוצים, רזולוציה וכיול.',
  v52AutoDelayBtn:'סנכרון TF: מפצה את הפרש הזמן בין MIC 1 ל־REF 2 עבור גרפי TF ופאזה בלבד. הוא אינו דיליי שמוסיפים לרמקול.',
  v52GenBtn:'פותח את הגנרטור בתחתית בלי לכסות את הגרף.',
  v52FreezeBtn:'מקפיא או מחזיר לפעולה את התצוגה החיה.',
  v52CaptureBtn:'פותח את אזור השמירה והלכידות.',
  geqDockToggle:'מכווץ או מרחיב את תצוגת תיקוני ה-EQ.',
  geqCutMode:'בחר תיקון מלא או חיתוך בלבד. הבחירה חלה על SPL, אזורים ו-TF.',
  tfSwapBtn:'מחליף בין ערוץ המיקרופון לערוץ הרפרנס.',
  tfMeasBtn:'מודד את התגובה במשך 6 שניות ומחשב תיקוני EQ.',
  tfCsvBtn:'מוריד את תוצאת מדידת TF כקובץ CSV.',
  tfTraceClearBtn:'מוחק את כל ה-Traces שנלכדו.',
  v52OpenMicCal:'פותח את רשימת קובצי כיול המיקרופון.',
  v52UnitToggle:'מחליף את המד בין dB SPL לבין dBFS.',
  v52OpenOldIo:'פותח הגדרות I/O מתקדמות ופעולות ייצוא.'
};
let helpMode=false;
const helpTip=document.createElement('div'); helpTip.id='helpTip'; document.body.appendChild(helpTip);
safeOn('helpBtn', 'click',function(){
  helpMode=!helpMode; this.classList.toggle('on',helpMode); document.body.classList.toggle('help-on',helpMode);
  if(!helpMode) helpTip.style.display='none';
});
function helpTextFor(target){
  let txt=null;
  const idEl=target.closest && target.closest('[id]'); if(idEl) txt=HELP[idEl.id];
  if(!txt && target.closest){
    const cEl=target.closest('.tgtSeg'); if(cEl) txt=HELP.tgtSeg;
    const cut=target.closest('#geqCutMode');if(cut)txt=HELP.geqCutMode;
    const mode=target.closest('[data-v5mode]');if(!txt&&mode){const names={analysis:'RTA ו-Waterfall: ניתוח ספקטרום חי.',tf:'TF: השוואה חיה בין המיקרופון לרפרנס ומדידת תגובה.',delay:'Delay Finder: מדידת הפרש זמן בין ערוצים ורמקולים.',rt60:'RT60: מדידת זמן הדהוד החדר.',spleq:'SPL / EQ: מדידת תגובה חד-ערוצית והמלצות EQ.',align:'Sub / Top: יישור פאזה ודיליי באזור החיתוך.'};txt=names[mode.dataset.v5mode];}
  }
  if(!txt && idEl){const labelled=idEl.getAttribute('aria-label')||idEl.getAttribute('title');if(labelled)txt=labelled;}
  if(!txt && target.closest){const control=target.closest('button,select,input,[role="button"]');if(control){const name=(control.getAttribute('aria-label')||control.getAttribute('title')||control.textContent||'').trim().replace(/\s+/g,' ');if(name)txt=name+' — שליטה זמינה במצב זה.';}}
  return txt;
}
function showHelpTip(txt,cx,cy){
  if(!txt){ helpTip.style.display='none'; return; }
  helpTip.textContent=txt; helpTip.style.whiteSpace='pre-line'; helpTip.style.display='block';
  const x=Math.max(8,Math.min(cx+14, innerWidth-helpTip.offsetWidth-10));
  const y=Math.max(8,Math.min(cy+16, innerHeight-helpTip.offsetHeight-10));
  helpTip.style.left=x+'px'; helpTip.style.top=y+'px';
}
document.addEventListener('mousemove',e=>{
  if(!helpMode) return;
  showHelpTip(helpTextFor(e.target), e.clientX, e.clientY);
});
document.addEventListener('focusin',e=>{
  if(!helpMode) return;
  const txt=helpTextFor(e.target); if(!txt){ helpTip.style.display='none'; return; }
  const r=e.target.getBoundingClientRect();
  showHelpTip(txt, r.left, r.bottom);
});
document.addEventListener('pointerdown',e=>{
  if(!helpMode || e.pointerType==='mouse') return;
  if(e.target.closest && (e.target.closest('#helpBtn') || e.target.closest('#sunBtn'))) return;
  const txt=helpTextFor(e.target);
  if(txt){ e.preventDefault(); e.stopPropagation(); showHelpTip(txt, e.clientX, e.clientY); }
}, true);

(function plexus(){
  const g=document.getElementById('pcbTraces'); if(!g) return;
  const NS='http://www.w3.org/2000/svg', W=600,H=200, N=42, LINK=54;
  let s=90210; const rnd=()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; };
  const nodes=[], dots=[];
  const linePath=document.createElementNS(NS,'path');
  linePath.setAttribute('stroke','#5ab0ff'); linePath.setAttribute('stroke-width','0.4');
  linePath.setAttribute('fill','none'); linePath.setAttribute('opacity','0.5'); g.appendChild(linePath);
  for(let i=0;i<N;i++){
    const n={x:rnd()*W,y:rnd()*H,vx:(rnd()-0.5)*0.12,vy:(rnd()-0.5)*0.12,r:0.5+rnd()*1.6};
    nodes.push(n);
    const c=document.createElementNS(NS,'circle'); c.setAttribute('r',n.r.toFixed(1));
    c.setAttribute('fill','#9fd4ff'); c.setAttribute('opacity',(0.4+rnd()*0.5).toFixed(2));
    g.appendChild(c); dots.push(c);
  }
  let last=0;
  function frame(t){
    requestAnimationFrame(frame);
    if(t-last<70) return;
    if(document.hidden) return;
    last=t;
    let d='';
    for(const n of nodes){ n.x+=n.vx; n.y+=n.vy; if(n.x<0||n.x>W)n.vx*=-1; if(n.y<0||n.y>H)n.vy*=-1; }
    for(let i=0;i<N;i++){ dots[i].setAttribute('cx',nodes[i].x.toFixed(1)); dots[i].setAttribute('cy',nodes[i].y.toFixed(1)); }
    for(let i=0;i<N;i++) for(let j=i+1;j<N;j++){
      const dx=nodes[i].x-nodes[j].x, dy=nodes[i].y-nodes[j].y, d2=dx*dx+dy*dy;
      if(d2<LINK*LINK) d+='M'+nodes[i].x.toFixed(1)+' '+nodes[i].y.toFixed(1)+'L'+nodes[j].x.toFixed(1)+' '+nodes[j].y.toFixed(1);
    }
    linePath.setAttribute('d', d);
  }
  requestAnimationFrame(frame);
})();

function reviveAudio(){ if(running && audioCtx && audioCtx.state==='suspended') audioCtx.resume(); }
if(navigator.mediaDevices && navigator.mediaDevices.addEventListener){
  navigator.mediaDevices.addEventListener('devicechange',()=>{ if(running) populateInputs(); });
}
document.addEventListener('visibilitychange',()=>{ if(!document.hidden) reviveAudio(); });
window.addEventListener('focus',reviveAudio);
resize();
if('ResizeObserver' in window){
  const _ro=new ResizeObserver(()=>{ resize(); });
  _ro.observe(document.getElementById('stage'));
}
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('sw.js').then(reg=>{
      reg.addEventListener('updatefound',()=>{
        const sw=reg.installing; if(!sw) return;
        sw.addEventListener('statechange',()=>{
          if(sw.state==='installed' && navigator.serviceWorker.controller){
            const el=document.getElementById('ver');
            if(el){ el.textContent+=' · גרסה חדשה זמינה — רענן'; el.style.color='var(--warn)'; }
          }
        });
      });
    }).catch(()=>{});
  });
}
